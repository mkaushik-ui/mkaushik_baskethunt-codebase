/**
 * Heading Tool - Core Writing Component Suite (T3).
 * Supports H2 through H6 levels, inline formatting, level selector switches,
 * and live slug anchor calculations.
 */
(function (global) {
  'use strict';

  class KcHeadingTool {
    static get toolbox() {
      return {
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 4v16M18 4v16M6 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
        title: 'Heading'
      };
    }

    static get isReadOnlySupported() {
      return true;
    }

    static get conversionConfig() {
      return {
        export: 'text',
        import: 'text'
      };
    }

    static get sanitize() {
      return {
        level: false,
        text: {
          br: true,
          strong: true,
          b: true,
          em: true,
          i: true,
          code: true
        }
      };
    }

    static get LEVELS() {
      return [2, 3, 4, 5, 6];
    }

    static get DEFAULT_LEVEL() {
      return 2;
    }

    constructor({ data, config, api, readOnly }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};
      this.levels = this.config.levels || KcHeadingTool.LEVELS;
      this.defaultLevel = this.config.defaultLevel || KcHeadingTool.DEFAULT_LEVEL;

      this.data = {
        level: this.levels.includes(Number(data.level)) ? Number(data.level) : this.defaultLevel,
        text: data && typeof data.text === 'string' ? data.text : ''
      };

      this.nodes = {
        wrapper: null,
        heading: null,
        levelSelector: null
      };
    }

    render() {
      const wrapper = document.createElement('div');
      wrapper.className = 'kc-tool kc-tool-heading cdx-block';

      const heading = document.createElement('h' + this.data.level);
      heading.className = 'kc-heading-input';
      heading.contentEditable = this.readOnly ? 'false' : 'true';
      heading.dataset.placeholder = this.config.placeholder || 'Heading ' + this.data.level + '…';
      heading.innerHTML = this.data.text;

      heading.addEventListener('input', () => {
        this.data.text = heading.innerHTML;
      });

      wrapper.appendChild(heading);
      this.nodes.wrapper = wrapper;
      this.nodes.heading = heading;

      return wrapper;
    }

    renderSettings() {
      const container = document.createElement('div');
      container.className = 'cdx-settings-1-column';

      this.levels.forEach((lvl) => {
        const button = document.createElement('div');
        button.className = this.api.styles.settingsButton || 'cdx-settings-button';
        button.innerHTML = 'H' + lvl;
        button.classList.toggle(this.api.styles.settingsButtonActive || 'cdx-settings-button--active', lvl === this.data.level);

        button.addEventListener('click', () => {
          this.setLevel(lvl);
          const buttons = container.querySelectorAll('.cdx-settings-button, .' + (this.api.styles.settingsButton || ''));
          buttons.forEach((b) => b.classList.remove(this.api.styles.settingsButtonActive || 'cdx-settings-button--active'));
          button.classList.add(this.api.styles.settingsButtonActive || 'cdx-settings-button--active');
        });

        container.appendChild(button);
      });

      return container;
    }

    setLevel(lvl) {
      this.data.level = lvl;
      if (!this.nodes.heading) return;

      const newHeading = document.createElement('h' + lvl);
      newHeading.className = 'kc-heading-input';
      newHeading.contentEditable = this.readOnly ? 'false' : 'true';
      newHeading.dataset.placeholder = this.config.placeholder || 'Heading ' + lvl + '…';
      newHeading.innerHTML = this.nodes.heading.innerHTML;

      newHeading.addEventListener('input', () => {
        this.data.text = newHeading.innerHTML;
      });

      this.nodes.wrapper.replaceChild(newHeading, this.nodes.heading);
      this.nodes.heading = newHeading;
    }

    merge(data) {
      if (!data || typeof data.text !== 'string') return;
      this.data.text += data.text;
      if (this.nodes.heading) {
        this.nodes.heading.innerHTML = this.data.text;
      }
    }

    validate(savedData) {
      if (!savedData || typeof savedData.text !== 'string') return false;
      return true;
    }

    save(blockContent) {
      const heading = blockContent ? blockContent.querySelector('.kc-heading-input') : this.nodes.heading;
      return {
        level: this.data.level,
        text: heading ? heading.innerHTML : (this.data.text || '')
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('heading', KcHeadingTool, { label: 'Heading', group: 'basic' });
  }
  global.KcHeadingTool = KcHeadingTool;
})(window);
