/**
 * Paragraph Tool - Core Writing Component Suite (T3).
 * Provides immediate typing, clean contenteditable container, Enter/Backspace support,
 * and inline text formatting support.
 */
(function (global) {
  'use strict';

  class KcParagraphTool {
    static get toolbox() {
      return {
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M13 4v16M17 4v16M19 4H9.5a4.5 4.5 0 0 0 0 9H13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        title: 'Paragraph'
      };
    }

    static get isReadOnlySupported() {
      return true;
    }

    static get enableLineBreaks() {
      return true;
    }

    static get conversionConfig() {
      return {
        export: 'text',
        import: 'text'
      };
    }

    static get sanitize() {
      return {
        text: {
          br: true,
          strong: true,
          b: true,
          em: true,
          i: true,
          u: true,
          s: true,
          del: true,
          strike: true,
          code: true,
          mark: true,
          a: {
            href: true,
            target: '_blank',
            rel: 'noopener noreferrer'
          }
        }
      };
    }

    constructor({ data, config, api, readOnly }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};
      this.data = {
        text: data && typeof data.text === 'string' ? data.text : ''
      };
      this.element = null;
      this._placeholder = this.config.placeholder || 'Type your text here…';
    }

    render() {
      const holder = document.createElement('div');
      holder.classList.add('kc-tool-paragraph', 'ce-paragraph', 'cdx-block');
      holder.contentEditable = this.readOnly ? 'false' : 'true';
      holder.dataset.placeholder = this._placeholder;
      holder.innerHTML = this.data.text;

      holder.addEventListener('input', () => {
        this.data.text = holder.innerHTML;
      });

      holder.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
          // Default block splitting handled by Editor.js core
        }
      });

      this.element = holder;
      return holder;
    }

    merge(data) {
      if (!data || typeof data.text !== 'string') return;
      this.data.text += data.text;
      if (this.element) {
        this.element.innerHTML = this.data.text;
      }
    }

    validate(savedData) {
      if (!savedData || typeof savedData.text !== 'string') {
        return false;
      }
      return true;
    }

    save(blockContent) {
      return {
        text: blockContent ? blockContent.innerHTML : (this.data.text || '')
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('paragraph', KcParagraphTool, { label: 'Paragraph', group: 'basic' });
  }
  global.KcParagraphTool = KcParagraphTool;
})(window);
