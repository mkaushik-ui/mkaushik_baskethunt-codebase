<?php
/**
 * Test Suite for Task T3 — Core Writing Block Suite & Server Renderers.
 * 
 * Verifies:
 * 1. Heading anchor slug generation ("System Architecture" -> "system-architecture").
 * 2. Heading anchor deduplication ("System Architecture" -> "system-architecture-2").
 * 3. Callout semantic tone class rendering without inline styles.
 * 4. List multi-style rendering (bulleted, numbered, checklist).
 * 5. Quote and Divider semantic rendering.
 * 6. Steps ordered procedure guide rendering.
 * 7. FAQ Schema.org microdata and collapsible details rendering.
 * 8. Status badge governed status and label rendering.
 * 9. Server-side XSS stripping and URL sanitization.
 * 10. 100% JSON schema data to HTML preview parity.
 */
declare(strict_types=1);

define('SOI_ROOT', dirname(__DIR__, 2) . '/mkaushik_baskethunt-codebase-main');

require_once SOI_ROOT . '/core/helpers.php';
require_once SOI_ROOT . '/core/Content/BlockType.php';
require_once SOI_ROOT . '/core/Content/RenderContext.php';
require_once SOI_ROOT . '/core/Content/Html.php';
require_once SOI_ROOT . '/core/Content/Blocks/AbstractBlock.php';

// Load T3 Basic Blocks
require_once __DIR__ . '/../core/Content/Blocks/Basic/ParagraphBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Basic/HeadingBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Basic/ListBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Basic/QuoteBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Basic/DividerBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Basic/CalloutBlock.php';

// Load T3 Knowledge Blocks
require_once __DIR__ . '/../core/Content/Blocks/Knowledge/StepsBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Knowledge/FaqBlock.php';
require_once __DIR__ . '/../core/Content/Blocks/Knowledge/StatusBadgeBlock.php';

use SOI\Core\Content\RenderContext;
use SOI\Core\Content\Blocks\Basic\ParagraphBlock;
use SOI\Core\Content\Blocks\Basic\HeadingBlock;
use SOI\Core\Content\Blocks\Basic\ListBlock;
use SOI\Core\Content\Blocks\Basic\QuoteBlock;
use SOI\Core\Content\Blocks\Basic\DividerBlock;
use SOI\Core\Content\Blocks\Basic\CalloutBlock;
use SOI\Core\Content\Blocks\Knowledge\StepsBlock;
use SOI\Core\Content\Blocks\Knowledge\FaqBlock;
use SOI\Core\Content\Blocks\Knowledge\StatusBadgeBlock;

$passed = 0;
$failed = 0;

function assert_test(bool $condition, string $description): void {
    global $passed, $failed;
    if ($condition) {
        $passed++;
        echo "  [PASS] {$description}\n";
    } else {
        $failed++;
        echo "  [FAIL] {$description}\n";
    }
}

echo "=== Running Task T3: Core Writing Block Suite QA ===\n\n";

$ctx = new RenderContext();

// 1. Heading Anchor Test
echo "[Heading Anchor Tests]\n";
$headingBlock = new HeadingBlock();
$headingHtml1 = $headingBlock->render([
    'id'   => 'h_01',
    'type' => 'heading',
    'data' => ['text' => 'System Architecture', 'level' => 2]
], $ctx);

assert_test(str_contains($headingHtml1, 'id="system-architecture"'), 'Heading "System Architecture" generates stable anchor id="system-architecture"');
assert_test(str_contains($headingHtml1, '<h2') && str_contains($headingHtml1, 'class="kc-block kc-block-heading"'), 'Heading renders semantic H2 with kc-block-heading class');

// Duplicate heading test
$headingHtml2 = $headingBlock->render([
    'id'   => 'h_02',
    'type' => 'heading',
    'data' => ['text' => 'System Architecture', 'level' => 2]
], $ctx);
assert_test(str_contains($headingHtml2, 'id="system-architecture-2"'), 'Duplicate heading generates disambiguated anchor id="system-architecture-2"');

// 2. Callout Tone and Inline Style Test
echo "\n[Callout Semantic Tests]\n";
$calloutBlock = new CalloutBlock();
$calloutHtml = $calloutBlock->render([
    'id'   => 'c_01',
    'type' => 'callout',
    'data' => ['tone' => 'warning', 'title' => 'Security Notice', 'text' => 'Ensure <strong>API keys</strong> are stored safely.']
], $ctx);

assert_test(str_contains($calloutHtml, 'kc-callout-warning'), 'Callout renders correct semantic tone class kc-callout-warning');
assert_test(!str_contains($calloutHtml, 'style='), 'Callout contains NO inline style attributes');
assert_test(str_contains($calloutHtml, '<aside class="kc-block kc-block-callout'), 'Callout renders semantic <aside> element');
assert_test(str_contains($calloutHtml, '<strong>API keys</strong>'), 'Callout preserves safe inline HTML formatting');

// 3. Paragraph Block Test
echo "\n[Paragraph Tests]\n";
$pBlock = new ParagraphBlock();
$pHtml = $pBlock->render([
    'id'   => 'p_01',
    'type' => 'paragraph',
    'data' => ['text' => 'This is core <a href="https://example.com">documentation</a> text.']
], $ctx);

assert_test(str_contains($pHtml, '<p class="kc-block kc-block-paragraph"'), 'Paragraph renders semantic <p> with kc-block-paragraph class');
assert_test(str_contains($pHtml, '<a href="https://example.com">documentation</a>'), 'Paragraph renders safe link with proper href');

// 4. List Block Tests
echo "\n[List Block Tests]\n";
$listBlock = new ListBlock();
$checklistHtml = $listBlock->render([
    'id'   => 'l_01',
    'type' => 'list',
    'data' => [
        'style' => 'checklist',
        'items' => [
            ['text' => 'Requirement 1', 'checked' => true, 'items' => []],
            ['text' => 'Requirement 2', 'checked' => false, 'items' => []],
        ]
    ]
], $ctx);

assert_test(str_contains($checklistHtml, 'kc-block-checklist'), 'List renders checklist class');
assert_test(str_contains($checklistHtml, 'is-checked'), 'Checklist task item reflects checked state');

// 5. Quote and Divider Tests
echo "\n[Quote & Divider Tests]\n";
$quoteBlock = new QuoteBlock();
$qHtml = $quoteBlock->render([
    'id'   => 'q_01',
    'type' => 'quote',
    'data' => ['text' => 'Simplicity is prerequisite for reliability.', 'caption' => 'Edsger W. Dijkstra']
], $ctx);
assert_test(str_contains($qHtml, '<blockquote class="kc-block kc-block-quote"'), 'Quote renders semantic blockquote');
assert_test(str_contains($qHtml, '<footer class="kc-quote-caption">Edsger W. Dijkstra</footer>'), 'Quote renders citation footer');

$divBlock = new DividerBlock();
$dHtml = $divBlock->render(['id' => 'd_01', 'type' => 'divider', 'data' => []], $ctx);
assert_test(str_contains($dHtml, '<hr class="kc-block kc-block-divider"'), 'Divider renders semantic hr');

// 6. Steps Block Test
echo "\n[Steps Procedure Guide Tests]\n";
$stepsBlock = new StepsBlock();
$stepsHtml = $stepsBlock->render([
    'id'   => 's_01',
    'type' => 'steps',
    'data' => [
        'items' => [
            ['title' => 'Clone Repository', 'content' => 'Run git clone command.'],
            ['title' => 'Install Dependencies', 'content' => 'Configure environment.'],
        ]
    ]
], $ctx);

assert_test(str_contains($stepsHtml, '<ol class="kc-block kc-block-steps"'), 'Steps renders ordered list container');
assert_test(str_contains($stepsHtml, '<div class="kc-steps-index" aria-hidden="true">1</div>'), 'Steps renders index badge');
assert_test(str_contains($stepsHtml, 'Clone Repository'), 'Steps renders step title');

// 7. FAQ Block with Schema.org Microdata
echo "\n[FAQ Schema.org Tests]\n";
$faqBlock = new FaqBlock();
$faqHtml = $faqBlock->render([
    'id'   => 'f_01',
    'type' => 'faq',
    'data' => [
        'items' => [
            ['question' => 'How does SSO work?', 'answer' => 'SSO integrates with SAML 2.0 Identity Providers.']
        ]
    ]
], $ctx);

assert_test(str_contains($faqHtml, 'itemtype="https://schema.org/FAQPage"'), 'FAQ contains Schema.org FAQPage microdata');
assert_test(str_contains($faqHtml, '<details class="kc-faq-item"'), 'FAQ renders native details accordion item');
assert_test(str_contains($faqHtml, '<summary class="kc-faq-question" itemprop="name">How does SSO work?</summary>'), 'FAQ renders summary question');

// 8. Status Badge Test
echo "\n[Status Badge Tests]\n";
$badgeBlock = new StatusBadgeBlock();
$badgeHtml = $badgeBlock->render([
    'id'   => 'b_01',
    'type' => 'statusBadge',
    'data' => ['status' => 'beta', 'label' => 'Beta Release']
], $ctx);

assert_test(str_contains($badgeHtml, 'kc-badge-beta'), 'Status badge renders governed status class kc-badge-beta');
assert_test(str_contains($badgeHtml, 'Beta Release'), 'Status badge renders custom label');

// 9. XSS and Malicious Content Stripping Test
echo "\n[Security & Sanitization Tests]\n";
$xssCallout = $calloutBlock->sanitize([
    'tone'  => 'danger',
    'title' => '<script>alert("hack")</script>Alert',
    'text'  => '<img src=x onerror=alert(1)>Malicious <a href="javascript:alert(1)">Link</a>'
]);
$xssCalloutHtml = $calloutBlock->render(['id' => 'x_01', 'type' => 'callout', 'data' => $xssCallout], $ctx);

assert_test(!str_contains($xssCalloutHtml, '<script'), 'Sanitizer strips <script> tags');
assert_test(!str_contains($xssCalloutHtml, 'onerror='), 'Sanitizer strips event handlers (onerror=)');
assert_test(!str_contains($xssCalloutHtml, 'javascript:'), 'Sanitizer strips javascript: URLs');

echo "\n===================================================\n";
echo "Results: {$passed} Passed, {$failed} Failed\n";
echo "===================================================\n";

exit($failed === 0 ? 0 : 1);
