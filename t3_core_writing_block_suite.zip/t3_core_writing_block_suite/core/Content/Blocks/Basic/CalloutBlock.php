<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * CalloutBlock - Core Writing Block Provider (T3).
 * Governed semantic notices with 6 controlled tones (info, note, tip, warning, danger, success),
 * customizable title, and rich inline formatted body content.
 */
final class CalloutBlock extends AbstractBlock
{
    public const TONES = ['info', 'note', 'tip', 'warning', 'danger', 'success'];

    public function type(): string
    {
        return 'callout';
    }

    public function label(): string
    {
        return 'Callout';
    }

    /**
     * Sanitize tone against allowed enum, clamp title, and sanitize inline body text.
     *
     * @param array<string, mixed> $data
     * @return array{tone: string, title: string, text: string}
     */
    public function sanitize(array $data): array
    {
        return [
            'tone'  => $this->enum($data['tone'] ?? 'info', self::TONES, 'info'),
            'title' => Html::plainText($this->text($data['title'] ?? '', 200)),
            'text'  => $this->inline($data['text'] ?? '', 20000),
        ];
    }

    /**
     * Validate tone against governed list.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $errors = [];
        $tone = (string) ($data['tone'] ?? 'info');
        if (!in_array($tone, self::TONES, true)) {
            $errors[] = 'Invalid callout tone: ' . $tone;
        }
        return $errors;
    }

    /**
     * Render semantic aside callout HTML without inline styles.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $tone = $this->enum($block['data']['tone'] ?? 'info', self::TONES, 'info');
        $title = (string) ($block['data']['title'] ?? '');
        $text = (string) ($block['data']['text'] ?? '');

        if ($title === '' && Html::plainText($text) === '') {
            return '';
        }

        if ($title === '') {
            $title = ucfirst($tone);
        }

        $escapedTone = Html::escape($tone);
        $blockId = Html::escape((string) ($block['id'] ?? ''));

        $html = '<aside class="kc-block kc-block-callout kc-callout-' . $escapedTone . '" data-tone="' . $escapedTone . '" data-block-id="' . $blockId . '">';
        $html .= '<div class="kc-callout-title">' . Html::escape($title) . '</div>';
        
        if (Html::plainText($text) !== '') {
            $html .= '<div class="kc-callout-body">' . $text . '</div>';
        }
        
        $html .= '</aside>';
        return $html;
    }
}
