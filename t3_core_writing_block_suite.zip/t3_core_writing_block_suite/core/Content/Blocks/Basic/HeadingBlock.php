<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * HeadingBlock - Core Writing Block Provider (T3).
 * Supports H2 through H6 levels with automatic stable slug anchor generation
 * for deep linking, Table of Contents extraction, and anchor deduplication.
 */
final class HeadingBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'heading';
    }

    public function label(): string
    {
        return 'Heading';
    }

    /**
     * Sanitize incoming heading data.
     *
     * @param array<string, mixed> $data
     * @return array{text: string, level: int}
     */
    public function sanitize(array $data): array
    {
        $level = (int) ($data['level'] ?? 2);
        if ($level < 2 || $level > 6) {
            $level = 2;
        }

        return [
            'text'  => $this->inline($data['text'] ?? '', 5000),
            'level' => $level,
        ];
    }

    /**
     * Validate heading properties.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $errors = [];
        $level = (int) ($data['level'] ?? 2);
        if ($level < 2 || $level > 6) {
            $errors[] = 'Heading level must be between 2 and 6.';
        }
        return $errors;
    }

    /**
     * Render semantic heading tag with persistent anchor ID.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $text = (string) ($block['data']['text'] ?? '');
        $plain = Html::plainText($text);
        if ($plain === '') {
            return '';
        }

        $level = (int) ($block['data']['level'] ?? 2);
        $level = max(2, min(6, $level));

        // Generate persistent stable anchor slug
        $anchor = $ctx->headingAnchor($plain);
        
        // Log heading for Table of Contents / Outline
        $ctx->headings[] = [
            'id'    => $anchor,
            'level' => $level,
            'text'  => $plain,
        ];

        $tag = 'h' . $level;
        $blockId = Html::escape((string) ($block['id'] ?? ''));
        $escapedAnchor = Html::escape($anchor);

        return '<' . $tag . ' class="kc-block kc-block-heading" id="' . $escapedAnchor . '" data-block-id="' . $blockId . '">'
            . $text
            . '</' . $tag . '>';
    }

    /**
     * Outline title for navigator.
     *
     * @param array<string, mixed> $data
     * @return string|null
     */
    public function outlineTitle(array $data): ?string
    {
        $text = Html::plainText((string) ($data['text'] ?? ''));
        return $text !== '' ? $text : null;
    }
}
