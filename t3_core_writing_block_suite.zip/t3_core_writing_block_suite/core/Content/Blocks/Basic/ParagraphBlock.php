<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * ParagraphBlock - Core Writing Block Provider (T3).
 * Handles immediate typing, safe inline formatting (bold, italic, code, links),
 * and clean semantic paragraph rendering with empty-tag suppression.
 */
final class ParagraphBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'paragraph';
    }

    public function label(): string
    {
        return 'Paragraph';
    }

    /**
     * Sanitize incoming paragraph data.
     *
     * @param array<string, mixed> $data
     * @return array{text: string}
     */
    public function sanitize(array $data): array
    {
        return [
            'text' => $this->inline($data['text'] ?? '', 50000),
        ];
    }

    /**
     * Render semantic paragraph HTML.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $text = (string) ($block['data']['text'] ?? '');
        $plain = trim(Html::plainText($text));
        
        // Suppress empty paragraphs unless containing an inline image
        if ($plain === '' && !str_contains($text, '<img')) {
            return '';
        }

        $blockId = Html::escape((string) ($block['id'] ?? ''));
        return '<p class="kc-block kc-block-paragraph" data-block-id="' . $blockId . '">' . $text . '</p>';
    }
}
