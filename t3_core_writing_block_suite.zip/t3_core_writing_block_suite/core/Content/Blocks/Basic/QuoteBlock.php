<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * QuoteBlock - Core Writing Block Provider (T3).
 * Renders pull quotes with quotation text and an optional citation footer.
 */
final class QuoteBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'quote';
    }

    public function label(): string
    {
        return 'Quote';
    }

    /**
     * Sanitize quote text and caption citation.
     *
     * @param array<string, mixed> $data
     * @return array{text: string, caption: string}
     */
    public function sanitize(array $data): array
    {
        return [
            'text'    => $this->inline($data['text'] ?? '', 20000),
            'caption' => $this->inline($data['caption'] ?? '', 2000),
        ];
    }

    /**
     * Render semantic blockquote HTML.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $text = (string) ($block['data']['text'] ?? '');
        if (Html::plainText($text) === '') {
            return '';
        }

        $caption = (string) ($block['data']['caption'] ?? '');
        $blockId = Html::escape((string) ($block['id'] ?? ''));

        $html = '<blockquote class="kc-block kc-block-quote" data-block-id="' . $blockId . '">';
        $html .= '<div class="kc-quote-text">' . $text . '</div>';
        
        if (Html::plainText($caption) !== '') {
            $html .= '<footer class="kc-quote-caption">' . $caption . '</footer>';
        }
        
        $html .= '</blockquote>';
        return $html;
    }
}
