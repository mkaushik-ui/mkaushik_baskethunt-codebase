<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * DividerBlock - Core Writing Block Provider (T3).
 * Stateless horizontal rule separator.
 */
final class DividerBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'divider';
    }

    public function label(): string
    {
        return 'Divider';
    }

    /**
     * Stateless sanitize.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sanitize(array $data): array
    {
        return [];
    }

    /**
     * Render semantic HR separator.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $blockId = Html::escape((string) ($block['id'] ?? ''));
        return '<hr class="kc-block kc-block-divider" data-block-id="' . $blockId . '">';
    }
}
