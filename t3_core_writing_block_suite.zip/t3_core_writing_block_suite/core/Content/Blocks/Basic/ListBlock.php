<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * ListBlock - Core Writing Block Provider (T3).
 * Supports bulleted (unordered), numbered (ordered), and task checklist styles
 * with multi-level indentation and deep recursion protection.
 */
final class ListBlock extends AbstractBlock
{
    private const MAX_ITEMS = 500;
    private const MAX_DEPTH = 4;

    public function type(): string
    {
        return 'list';
    }

    public function label(): string
    {
        return 'List';
    }

    /**
     * Sanitize list style and nested items.
     *
     * @param array<string, mixed> $data
     * @return array{style: string, items: list<array<string, mixed>>}
     */
    public function sanitize(array $data): array
    {
        $style = $this->enum($data['style'] ?? 'unordered', ['unordered', 'ordered', 'checklist'], 'unordered');
        return [
            'style' => $style,
            'items' => $this->sanitizeItems($data['items'] ?? [], 0),
        ];
    }

    /**
     * Render semantic list HTML.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $style = (string) ($block['data']['style'] ?? 'unordered');
        $items = $block['data']['items'] ?? [];
        if (!is_array($items) || $items === []) {
            return '';
        }

        $blockId = (string) ($block['id'] ?? '');
        return $this->renderItems($items, $style, $blockId, 0);
    }

    /**
     * Recursively sanitize list items.
     *
     * @param mixed $items
     * @param int $depth
     * @return list<array<string, mixed>>
     */
    private function sanitizeItems(mixed $items, int $depth): array
    {
        if (!is_array($items) || $depth > self::MAX_DEPTH) {
            return [];
        }

        $out = [];
        foreach (array_slice(array_values($items), 0, self::MAX_ITEMS) as $item) {
            if (is_string($item) || is_numeric($item)) {
                $out[] = [
                    'text'    => $this->inline((string) $item, 10000),
                    'checked' => false,
                    'items'   => [],
                ];
                continue;
            }

            if (!is_array($item)) {
                continue;
            }

            $text = $item['text'] ?? $item['content'] ?? '';
            $checked = !empty($item['checked']) || !empty($item['meta']['checked']);
            
            $out[] = [
                'text'    => $this->inline((string) $text, 10000),
                'checked' => $checked,
                'items'   => $this->sanitizeItems($item['items'] ?? [], $depth + 1),
            ];
        }

        return $out;
    }

    /**
     * Recursively render list items into HTML.
     *
     * @param list<array<string, mixed>> $items
     * @param string $style
     * @param string $blockId
     * @param int $depth
     * @return string
     */
    private function renderItems(array $items, string $style, string $blockId, int $depth): string
    {
        if ($items === [] || $depth > self::MAX_DEPTH) {
            return '';
        }

        $escapedBlockId = Html::escape($blockId);

        if ($style === 'checklist') {
            $html = '<ul class="kc-block kc-block-list kc-block-checklist" data-block-id="' . $escapedBlockId . '">';
            foreach ($items as $item) {
                $checked = !empty($item['checked']);
                $html .= '<li class="kc-checklist-item' . ($checked ? ' is-checked' : '') . '">';
                $html .= '<span class="kc-checklist-box" aria-hidden="true">' . ($checked ? '✓' : '') . '</span>';
                $html .= '<span class="kc-checklist-text">' . (string) ($item['text'] ?? '') . '</span>';
                
                $nested = $item['items'] ?? [];
                if (is_array($nested) && $nested !== []) {
                    $html .= $this->renderItems($nested, $style, $blockId, $depth + 1);
                }
                $html .= '</li>';
            }
            return $html . '</ul>';
        }

        $tag = $style === 'ordered' ? 'ol' : 'ul';
        $html = '<' . $tag . ' class="kc-block kc-block-list kc-block-list-' . Html::escape($style) . '" data-block-id="' . $escapedBlockId . '">';
        foreach ($items as $item) {
            $html .= '<li>' . (string) ($item['text'] ?? '');
            
            $nested = $item['items'] ?? [];
            if (is_array($nested) && $nested !== []) {
                $html .= $this->renderItems($nested, $style, $blockId, $depth + 1);
            }
            $html .= '</li>';
        }
        return $html . '</' . $tag . '>';
    }
}
