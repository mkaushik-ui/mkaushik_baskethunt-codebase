<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Knowledge;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * FaqBlock - Static Knowledge Block Provider (T3).
 * Renders structured FAQ questions and answers with native HTML5 collapsible details
 * and embedded Schema.org FAQPage structured data microdata for search engines.
 */
final class FaqBlock extends AbstractBlock
{
    private const MAX_FAQS = 40;

    public function type(): string
    {
        return 'faq';
    }

    public function label(): string
    {
        return 'FAQ';
    }

    /**
     * Sanitize list of FAQ question/answer items.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{question: string, answer: string}>}
     */
    public function sanitize(array $data): array
    {
        return [
            'items' => self::sanitizeItems($data['items'] ?? []),
        ];
    }

    /**
     * Validate FAQ item count.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_FAQS) {
            return ['FAQ cannot contain more than ' . self::MAX_FAQS . ' items.'];
        }
        return [];
    }

    /**
     * Render semantic FAQ block with Schema.org microdata.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $items = is_array($block['data']['items'] ?? null) ? $block['data']['items'] : [];
        if ($items === []) {
            return '';
        }

        $blockId = Html::escape((string) ($block['id'] ?? ''));
        $html = '<div class="kc-block kc-block-faq" data-block-id="' . $blockId . '" itemscope itemtype="https://schema.org/FAQPage">';

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $question = Html::plainText((string) ($item['question'] ?? $item['title'] ?? ''));
            $answer = (string) ($item['answer'] ?? $item['content'] ?? '');

            if ($question === '' && Html::plainText($answer) === '') {
                continue;
            }

            $escapedQuestion = Html::escape($question !== '' ? $question : 'Question');

            $html .= '<details class="kc-faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">';
            $html .= '<summary class="kc-faq-question" itemprop="name">' . $escapedQuestion . '</summary>';
            $html .= '<div class="kc-faq-answer" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">';
            $html .= '<div itemprop="text">' . $answer . '</div>';
            $html .= '</div></details>';
        }

        $html .= '</div>';
        return $html;
    }

    /**
     * Helper to sanitize FAQ question/answer pairs.
     *
     * @param mixed $items
     * @return list<array{question:string,answer:string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $question = Html::plainText(Html::clampText((string) ($item['question'] ?? $item['title'] ?? ''), 500));
            $answer = Html::sanitizeInline((string) ($item['answer'] ?? $item['content'] ?? ''), 20000);

            if ($question === '' && Html::plainText($answer) === '') {
                continue;
            }

            $out[] = ['question' => $question, 'answer' => $answer];
            if (count($out) >= self::MAX_FAQS) {
                break;
            }
        }

        return $out;
    }
}
