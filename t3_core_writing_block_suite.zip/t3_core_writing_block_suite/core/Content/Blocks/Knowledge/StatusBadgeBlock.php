<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Knowledge;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * StatusBadgeBlock - Static Knowledge Block Provider (T3).
 * Controlled semantic status badges (Draft, Review, Published, Stable, Beta, Deprecated, etc.)
 * with customizable label and controlled CSS modifier classes.
 */
final class StatusBadgeBlock extends AbstractBlock
{
    public const STATUSES = [
        'stable',
        'beta',
        'deprecated',
        'internal',
        'experimental',
        'recommended',
        'draft',
        'review',
        'published',
        'archived',
    ];

    public function type(): string
    {
        return 'statusBadge';
    }

    public function label(): string
    {
        return 'Status Badge';
    }

    /**
     * Sanitize status against allowed whitelist enum and clamp custom label.
     *
     * @param array<string, mixed> $data
     * @return array{status: string, label: string}
     */
    public function sanitize(array $data): array
    {
        $status = $this->enum($data['status'] ?? 'stable', self::STATUSES, 'stable');
        $label = Html::plainText(Html::clampText((string) ($data['label'] ?? ''), 40));
        if ($label === '') {
            $label = ucfirst($status);
        }

        return [
            'status' => $status,
            'label'  => $label,
        ];
    }

    /**
     * Validate status against allowed whitelist.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $errors = [];
        $status = (string) ($data['status'] ?? 'stable');
        if (!in_array($status, self::STATUSES, true)) {
            $errors[] = 'Invalid status badge value: ' . $status;
        }
        return $errors;
    }

    /**
     * Render semantic status badge HTML.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $status = $this->enum($block['data']['status'] ?? 'stable', self::STATUSES, 'stable');
        $label = Html::plainText((string) ($block['data']['label'] ?? ucfirst($status)));
        if ($label === '') {
            $label = ucfirst($status);
        }

        $blockId = Html::escape((string) ($block['id'] ?? ''));
        $escapedStatus = Html::escape($status);
        $escapedLabel = Html::escape($label);

        return '<p class="kc-block kc-block-status" data-block-id="' . $blockId . '">'
            . '<span class="kc-badge kc-badge-' . $escapedStatus . '">' . $escapedLabel . '</span>'
            . '</p>';
    }
}
