<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Knowledge;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * StepsBlock - Static Knowledge Block Provider (T3).
 * Renders numbered procedure steps with step index badge, title, and body instructions.
 */
final class StepsBlock extends AbstractBlock
{
    private const MAX_STEPS = 50;

    public function type(): string
    {
        return 'steps';
    }

    public function label(): string
    {
        return 'Steps';
    }

    /**
     * Sanitize list of procedure steps.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{title: string, content: string}>}
     */
    public function sanitize(array $data): array
    {
        return [
            'items' => self::sanitizeItems($data['items'] ?? []),
        ];
    }

    /**
     * Validate step count.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_STEPS) {
            return ['Steps cannot contain more than ' . self::MAX_STEPS . ' items.'];
        }
        return [];
    }

    /**
     * Render semantic ordered steps list HTML.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $items = is_array($block['data']['items'] ?? null) ? $block['data']['items'] : [];
        if ($items === []) {
            return '';
        }

        $blockId = Html::escape((string) ($block['id'] ?? ''));
        $html = '<ol class="kc-block kc-block-steps" data-block-id="' . $blockId . '">';

        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = Html::plainText((string) ($item['title'] ?? ''));
            $content = (string) ($item['content'] ?? '');

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $html .= '<li class="kc-steps-item">';
            $html .= '<div class="kc-steps-index" aria-hidden="true">' . (int) ($i + 1) . '</div>';
            $html .= '<div class="kc-steps-body">';
            
            if ($title !== '') {
                $html .= '<div class="kc-steps-title">' . Html::escape($title) . '</div>';
            }
            if (Html::plainText($content) !== '') {
                $html .= '<div class="kc-steps-content">' . $content . '</div>';
            }
            
            $html .= '</div></li>';
        }

        $html .= '</ol>';
        return $html;
    }

    /**
     * Helper to sanitize step item rows.
     *
     * @param mixed $items
     * @return list<array{title:string,content:string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = Html::plainText(Html::clampText((string) ($item['title'] ?? ''), 300));
            $content = Html::sanitizeInline((string) ($item['content'] ?? ''), 20000);

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $out[] = ['title' => $title, 'content' => $content];
            if (count($out) >= self::MAX_STEPS) {
                break;
            }
        }

        return $out;
    }
}
