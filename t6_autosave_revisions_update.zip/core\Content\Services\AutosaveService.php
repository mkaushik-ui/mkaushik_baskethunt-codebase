<?php
namespace SOI\Core\Content\Services;

use SOI\Core\Database;
use SOI\Core\Auth;

/**
 * Server-Side Autosave & Draft Handler Service
 * Location: core/Content/Services/AutosaveService.php
 */
class AutosaveService {

    /**
     * Handle autosave background draft update request.
     */
    public static function processAutosave(array $payload): array {
        // 1. Security: Check CSRF
        $csrfToken = $payload['_csrf'] ?? ($payload['csrf_token'] ?? '');
        if (!Auth::verifyCsrf($csrfToken)) {
            return ['success' => false, 'error' => 'invalid_csrf', 'message' => 'CSRF verification failed.'];
        }

        // 2. Security: Authorization check
        if (!Auth::hasRole('admin') && !Auth::hasRole('editor') && !Auth::hasRole('author')) {
            return ['success' => false, 'error' => 'unauthorized', 'message' => 'Insufficient permissions to save.'];
        }

        $documentId = (int)($payload['id'] ?? 0);
        $entity     = $payload['entity'] ?? 'pages';
        $title      = trim($payload['title'] ?? 'Untitled Document');
        $slug       = trim($payload['slug'] ?? 'untitled');
        $bodyJson   = $payload['body_json'] ?? null;
        $content    = $payload['content'] ?? null;
        $expectedTs = $payload['expected_revision_timestamp'] ?? null;

        if ($documentId <= 0) {
            return ['success' => false, 'error' => 'invalid_id', 'message' => 'Invalid document ID.'];
        }

        // 3. Optimistic Concurrency Check
        $concurrency = ConcurrencyService::validateConcurrency($entity, $documentId, $expectedTs);
        if ($concurrency['conflict']) {
            return [
                'success'           => false,
                'error'             => 'concurrency_conflict',
                'message'           => $concurrency['message'],
                'server_updated_at' => $concurrency['server_updated_at']
            ];
        }

        // 4. Update draft in database
        $tableName = (str_starts_with($entity, 'soi_')) ? $entity : 'soi_' . $entity;
        $stmt = Database::prepare("
            UPDATE `{$tableName}` 
            SET title = :title, slug = :slug, body_json = :body_json, content = :content, updated_at = NOW() 
            WHERE id = :id
        ");

        $stmt->execute([
            'title'     => $title,
            'slug'      => $slug,
            'body_json' => $bodyJson,
            'content'   => $content,
            'id'        => $documentId,
        ]);

        // Fetch fresh updated_at timestamp
        $tsStmt = Database::prepare("SELECT updated_at FROM `{$tableName}` WHERE id = :id LIMIT 1");
        $tsStmt->execute(['id' => $documentId]);
        $updatedAt = $tsStmt->fetchColumn() ?: date('Y-m-d H:i:s');

        return [
            'success'            => true,
            'message'            => 'Draft autosaved successfully.',
            'updated_at'         => $updatedAt,
            'document_id'        => $documentId
        ];
    }
}
