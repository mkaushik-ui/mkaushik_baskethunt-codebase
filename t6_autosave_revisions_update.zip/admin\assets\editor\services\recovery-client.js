/**
 * SOI Knowledge Center — Local Browser Recovery Buffer Controller
 * Location: admin/assets/editor/services/recovery-client.js
 */

(function () {
  'use strict';

  class KCRecoveryClient {
    constructor() {
      this.docId = new URLSearchParams(window.location.search).get('id') || '0';
      this.storageKey = `kc_recovery_draft_${this.docId}`;

      this.init();
    }

    init() {
      this.bindEvents();
      this.checkLocalRecovery();
    }

    bindEvents() {
      // Listen for dirty event from autosave client
      document.addEventListener('kc:editor-dirty', (e) => {
        if (e.detail) {
          this.saveLocalDraft(e.detail);
        }
      });

      // Clear local recovery buffer when server save succeeds
      document.addEventListener('kc:editor-saved', () => {
        this.clearLocalDraft();
      });
    }

    saveLocalDraft(data) {
      try {
        const payload = {
          docId: this.docId,
          title: data.title || '',
          content: data.content || '',
          timestamp: new Date().toISOString()
        };
        localStorage.setItem(this.storageKey, JSON.stringify(payload));
      } catch (err) {
        console.warn('Unable to persist to localStorage:', err);
      }
    }

    clearLocalDraft() {
      try {
        localStorage.removeItem(this.storageKey);
      } catch (err) {
        console.warn('Unable to clear localStorage:', err);
      }
    }

    checkLocalRecovery() {
      try {
        const saved = localStorage.getItem(this.storageKey);
        if (!saved) return;

        const draft = JSON.parse(saved);
        if (!draft || !draft.content) return;

        // Prompt user for local recovery
        setTimeout(() => {
          const timeAgo = new Date(draft.timestamp).toLocaleString();
          const restore = confirm(
            `LOCAL RECOVERY DRAFT DETECTED:\n\n` +
            `An unsaved local recovery draft from (${timeAgo}) was found in browser storage.\n\n` +
            `Would you like to RESTORE this local draft?\n` +
            `• Click OK to Restore Local Draft\n` +
            `• Click Cancel to Discard Local Draft`
          );

          if (restore) {
            this.applyLocalDraft(draft);
          } else {
            this.clearLocalDraft();
          }
        }, 400);

      } catch (err) {
        console.error('Error reading local recovery draft:', err);
      }
    }

    applyLocalDraft(draft) {
      const docTitleInput = document.getElementById('kc-doc-title');
      const canvasInner   = document.getElementById('kc-canvas-inner');

      if (docTitleInput && draft.title) {
        docTitleInput.value = draft.title;
      }
      if (canvasInner && draft.content) {
        canvasInner.innerHTML = draft.content;
      }

      // Mark status badge
      const statusBadge = document.getElementById('kc-save-status');
      if (statusBadge) {
        statusBadge.className = 'kc-save-status-badge unsaved';
        statusBadge.textContent = 'Restored from Local Buffer';
      }
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCRecovery = new KCRecoveryClient();
  });
})();
