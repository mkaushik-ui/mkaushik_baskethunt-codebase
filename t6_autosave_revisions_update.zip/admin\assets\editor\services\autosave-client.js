/**
 * SOI Knowledge Center — Debounced Client Autosave Engine
 * Location: admin/assets/editor/services/autosave-client.js
 */

(function () {
  'use strict';

  class KCAutosaveClient {
    constructor() {
      this.debounceMs = 2500;
      this.debounceTimer = null;
      this.lastSavedState = null;
      this.expectedTimestamp = null;
      this.statusBadge = document.getElementById('kc-save-status');
      this.docTitleInput = document.getElementById('kc-doc-title');
      this.canvasInner = document.getElementById('kc-canvas-inner');

      this.init();
    }

    init() {
      this.bindEvents();
      this.initShortcuts();
    }

    bindEvents() {
      // Listen for canvas input / title edits
      if (this.canvasInner) {
        this.canvasInner.addEventListener('input', () => this.markUnsaved());
      }
      if (this.docTitleInput) {
        this.docTitleInput.addEventListener('input', () => this.markUnsaved());
      }

      // Manual Save Button
      const saveBtn = document.getElementById('kc-save-btn');
      if (saveBtn) {
        saveBtn.addEventListener('click', () => this.saveImmediately());
      }
    }

    initShortcuts() {
      // Manual Save Shortcut (Ctrl+S / Cmd+S)
      window.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
          e.preventDefault();
          this.saveImmediately();
        }
      });
    }

    markUnsaved() {
      this.updateBadge('unsaved', 'Unsaved');

      // Clear existing debounce timer and start fresh 2500ms countdown
      if (this.debounceTimer) {
        clearTimeout(this.debounceTimer);
      }

      this.debounceTimer = setTimeout(() => {
        this.triggerAutosave();
      }, this.debounceMs);

      // Trigger Local Recovery persistence
      const event = new CustomEvent('kc:editor-dirty', {
        detail: {
          title: this.docTitleInput ? this.docTitleInput.value : '',
          content: this.canvasInner ? this.canvasInner.innerHTML : ''
        }
      });
      document.dispatchEvent(event);
    }

    saveImmediately() {
      if (this.debounceTimer) {
        clearTimeout(this.debounceTimer);
      }
      this.triggerAutosave(true);
    }

    async triggerAutosave(isManual = false) {
      this.updateBadge('saving', isManual ? 'Saving...' : 'Autosaving...');

      const csrfToken = document.getElementById('kc-csrf-token')?.value || '';
      const docTitle  = this.docTitleInput ? this.docTitleInput.value : 'Untitled Document';
      const content   = this.canvasInner ? this.canvasInner.innerHTML : '';
      const docId     = new URLSearchParams(window.location.search).get('id') || '0';

      const payload = {
        id: docId,
        entity: 'pages',
        _csrf: csrfToken,
        title: docTitle,
        content: content,
        expected_revision_timestamp: this.expectedTimestamp,
        is_manual: isManual
      };

      try {
        const response = await fetch('editor-api.php?action=autosave', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
          },
          body: JSON.stringify(payload)
        });

        if (response.status === 409) {
          const conflictData = await response.json();
          this.handleConflict(conflictData);
          return;
        }

        const data = await response.json();

        if (data.success) {
          this.expectedTimestamp = data.updated_at;
          this.updateBadge('saved', 'Saved');
          
          // Clear local recovery buffer on successful server persistence
          document.dispatchEvent(new CustomEvent('kc:editor-saved'));
        } else {
          this.updateBadge('unsaved', 'Save Error');
          console.error('Autosave error:', data.message);
        }
      } catch (err) {
        this.updateBadge('unsaved', 'Offline / Draft Buffered');
        console.warn('Network issue during autosave. Local recovery buffer active.', err);
      }
    }

    handleConflict(data) {
      this.updateBadge('unsaved', 'Conflict (409)');
      alert(`CONCURRENCY CONFLICT (HTTP 409):\n${data.message || 'Document modified by another user.'}\n\nPlease reload the page before saving.`);
    }

    updateBadge(stateClass, label) {
      if (!this.statusBadge) return;
      this.statusBadge.className = `kc-save-status-badge ${stateClass}`;
      this.statusBadge.innerHTML = `
        <svg width="8" height="8" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
        ${label}
      `;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCAutosave = new KCAutosaveClient();
  });
})();
