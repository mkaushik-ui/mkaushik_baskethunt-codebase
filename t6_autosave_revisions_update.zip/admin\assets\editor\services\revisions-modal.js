/**
 * SOI Knowledge Center — Revision History & Restore Modal Controller
 * Location: admin/assets/editor/services/revisions-modal.js
 */

(function () {
  'use strict';

  class KCRevisionsModal {
    constructor() {
      this.docId = new URLSearchParams(window.location.search).get('id') || '0';
      this.modalEl = null;

      this.init();
    }

    init() {
      this.bindEvents();
    }

    bindEvents() {
      // Listen for click on Document -> Revisions toolbar button
      document.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-tool="doc-revisions"]');
        if (btn) {
          this.openModal();
        }
      });
    }

    async openModal() {
      this.createModalDOM();
      await this.loadRevisions();
    }

    createModalDOM() {
      if (document.getElementById('kc-revisions-modal')) {
        this.modalEl = document.getElementById('kc-revisions-modal');
        this.modalEl.style.display = 'flex';
        return;
      }

      const modal = document.createElement('div');
      modal.id = 'kc-revisions-modal';
      modal.style.cssText = `
        position: fixed; inset: 0; z-index: 99999;
        background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(4px);
        display: flex; align-items: center; justify-content: center;
      `;

      modal.innerHTML = `
        <div style="background: var(--kc-bg-surface, #1e293b); border: 1px solid var(--kc-border, #334155); border-radius: 12px; width: 680px; max-width: 90vw; max-height: 85vh; display: flex; flex-direction: column; color: #f8fafc; box-shadow: 0 20px 40px rgba(0,0,0,0.6);">
          <div style="padding: 16px 20px; border-bottom: 1px solid var(--kc-border, #334155); display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 1.1rem; font-weight: 600;">Revision History &amp; Restore</h3>
            <button type="button" id="kc-rev-modal-close" style="background: none; border: none; color: #94a3b8; font-size: 1.2rem; cursor: pointer;">✕</button>
          </div>
          
          <div style="padding: 12px 20px; background: rgba(59, 130, 246, 0.1); border-bottom: 1px solid var(--kc-border, #334155); font-size: 0.82rem; color: #93c5fd;">
            🛡 <strong>Safety Rail Active:</strong> Restoring an older revision automatically creates a pre-restore snapshot of your current state.
          </div>

          <div id="kc-rev-list-body" style="padding: 20px; flex: 1; overflow-y: auto;">
            <div style="text-align: center; color: #94a3b8; padding: 40px;">Loading revision history...</div>
          </div>
        </div>
      `;

      document.body.appendChild(modal);
      this.modalEl = modal;

      document.getElementById('kc-rev-modal-close').addEventListener('click', () => {
        this.modalEl.style.display = 'none';
      });
    }

    async loadRevisions() {
      const listBody = document.getElementById('kc-rev-list-body');
      if (!listBody) return;

      try {
        const res = await fetch(`editor-api.php?action=get_revisions&id=${this.docId}&entity=pages`);
        const data = await res.json();

        if (!data.success || !data.revisions || !data.revisions.length) {
          listBody.innerHTML = `<div style="text-align:center;color:#94a3b8;padding:30px;">No revision snapshots found yet.</div>`;
          return;
        }

        let html = `<table style="width:100%;border-collapse:collapse;font-size:0.86rem;color:#f8fafc;">
          <thead>
            <tr style="border-bottom:1px solid #334155;text-align:left;color:#94a3b8;">
              <th style="padding:8px;">Rev #</th>
              <th style="padding:8px;">Author</th>
              <th style="padding:8px;">Status</th>
              <th style="padding:8px;">Created At</th>
              <th style="padding:8px;text-align:right;">Action</th>
            </tr>
          </thead>
          <tbody>`;

        data.revisions.forEach(rev => {
          html += `<tr style="border-bottom:1px solid #1e293b;">
            <td style="padding:10px 8px;font-weight:600;color:#3b82f6;">#${rev.revision_num}</td>
            <td style="padding:10px 8px;">${this.sanitize(rev.user_name || 'System Author')}</td>
            <td style="padding:10px 8px;"><span style="padding:2px 8px;border-radius:10px;font-size:0.75rem;background:rgba(148,163,184,0.15);color:#cbd5e1;">${this.sanitize(rev.status)}</span></td>
            <td style="padding:10px 8px;color:#94a3b8;">${this.sanitize(rev.created_at)}</td>
            <td style="padding:10px 8px;text-align:right;">
              <button type="button" class="kc-restore-rev-btn" data-rev-id="${rev.id}" data-rev-num="${rev.revision_num}" style="padding:4px 10px;background:#10b981;border:none;border-radius:4px;color:#fff;font-size:0.78rem;cursor:pointer;">
                Restore #${rev.revision_num}
              </button>
            </td>
          </tr>`;
        });

        html += `</tbody></table>`;
        listBody.innerHTML = html;

        // Bind restore buttons
        listBody.querySelectorAll('.kc-restore-rev-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const revId  = e.target.dataset.revId;
            const revNum = e.target.dataset.revNum;
            this.confirmAndRestore(revId, revNum);
          });
        });

      } catch (err) {
        listBody.innerHTML = `<div style="color:#ef4444;text-align:center;padding:20px;">Failed to load revisions log.</div>`;
      }
    }

    async confirmAndRestore(revId, revNum) {
      const confirmRestore = confirm(
        `PRE-RESTORE SAFETY RAIL CONFIRMATION:\n\n` +
        `Are you sure you want to restore Revision #${revNum}?\n\n` +
        `• Revision #${revNum} will replace your current canvas state.\n` +
        `• A pre-restore snapshot of your CURRENT state will automatically be saved first.`
      );

      if (!confirmRestore) return;

      const csrfToken = document.getElementById('kc-csrf-token')?.value || '';

      try {
        const res = await fetch(`editor-api.php?action=restore_revision`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
          },
          body: JSON.stringify({
            revision_id: revId,
            _csrf: csrfToken
          })
        });

        const data = await res.json();

        if (data.success) {
          alert(`RESTORE SUCCESSFUL:\n${data.message}`);
          
          if (data.body_json || data.content) {
            const canvasInner = document.getElementById('kc-canvas-inner');
            if (canvasInner && data.content) {
              canvasInner.innerHTML = data.content;
            }
          }
          
          this.modalEl.style.display = 'none';
          location.reload();
        } else {
          alert(`Restore failed: ${data.message}`);
        }

      } catch (err) {
        alert('Network error attempting to restore revision.');
      }
    }

    sanitize(str) {
      const div = document.createElement('div');
      div.textContent = str || '';
      return div.innerHTML;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCRevisionsModal = new KCRevisionsModal();
  });
})();
