<?php
namespace SOI\Core\Content\Services;

use SOI\Core\Database;
use SOI\Core\Auth;

/**
 * Revision Management & Restore Safety Rail Service
 * Location: core/Content/Services/RevisionService.php
 */
class RevisionService {

    /**
     * Create a new revision snapshot for a document.
     */
    public static function createRevision(
        string $entity,
        int $documentId,
        string $title,
        string $slug,
        string $status,
        ?string $bodyJson,
        ?string $content,
        ?int $userId = null,
        ?string $userName = ''
    ): int {
        $nextNum = self::getNextRevisionNum($entity, $documentId);
        $userId  = $userId ?? Auth::id();
        $userName = $userName ?: (Auth::user()['display_name'] ?? 'System Author');

        $stmt = Database::prepare("
            INSERT INTO `soi_document_revisions` 
            (`entity`, `document_id`, `revision_num`, `title`, `slug`, `status`, `body_json`, `content`, `user_id`, `user_name`, `created_at`)
            VALUES
            (:entity, :document_id, :revision_num, :title, :slug, :status, :body_json, :content, :user_id, :user_name, NOW())
        ");

        $stmt->execute([
            'entity'       => $entity,
            'document_id'  => $documentId,
            'revision_num' => $nextNum,
            'title'        => $title,
            'slug'         => $slug,
            'status'       => $status,
            'body_json'    => $bodyJson,
            'content'      => $content,
            'user_id'      => $userId,
            'user_name'    => $userName,
        ]);

        return (int)Database::lastInsertId();
    }

    /**
     * Get list of all revisions for a document.
     */
    public static function getRevisions(string $entity, int $documentId, int $limit = 30): array {
        $stmt = Database::prepare("
            SELECT id, revision_num, title, status, user_id, user_name, created_at 
            FROM `soi_document_revisions` 
            WHERE entity = :entity AND document_id = :doc_id 
            ORDER BY revision_num DESC 
            LIMIT :limit
        ");
        $stmt->bindValue(':entity', $entity);
        $stmt->bindValue(':doc_id', $documentId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];
    }

    /**
     * Get a specific revision by ID.
     */
    public static function getRevisionById(int $revisionId): ?array {
        $stmt = Database::prepare("SELECT * FROM `soi_document_revisions` WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $revisionId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return $row ?: null;
    }

    /**
     * Restore Safety Rail: Before restoring revision N, automatically create a pre-restore snapshot
     * of current state as revision N+1, then apply revision N to the target document.
     */
    public static function restoreRevision(int $revisionId): array {
        // Security check: Author authorization
        if (!Auth::hasRole('admin') && !Auth::hasRole('editor') && !Auth::hasRole('author')) {
            return ['success' => false, 'message' => 'Unauthorized to restore revisions.'];
        }

        $targetRev = self::getRevisionById($revisionId);
        if (!$targetRev) {
            return ['success' => false, 'message' => 'Target revision not found.'];
        }

        $entity     = $targetRev['entity'];
        $documentId = (int)$targetRev['document_id'];

        // 1. Fetch current live document state from database
        $tableName = (str_starts_with($entity, 'soi_')) ? $entity : 'soi_' . $entity;
        $stmt = Database::prepare("SELECT * FROM `{$tableName}` WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $documentId]);
        $currentDoc = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$currentDoc) {
            return ['success' => false, 'message' => 'Target document no longer exists.'];
        }

        // 2. Pre-Restore Safety Rail: Create Revision N+1 snapshot of current state before overwrite
        $preRestoreRevId = self::createRevision(
            $entity,
            $documentId,
            $currentDoc['title'] . ' (Pre-Restore Snapshot)',
            $currentDoc['slug'],
            $currentDoc['status'],
            $currentDoc['body_json'] ?? null,
            $currentDoc['content'] ?? null,
            Auth::id(),
            Auth::user()['display_name'] ?? 'System Author'
        );

        // 3. Apply target revision to document
        $updateStmt = Database::prepare("
            UPDATE `{$tableName}` 
            SET title = :title, slug = :slug, body_json = :body_json, content = :content, updated_at = NOW() 
            WHERE id = :id
        ");

        $updateStmt->execute([
            'title'     => $targetRev['title'],
            'slug'      => $targetRev['slug'],
            'body_json' => $targetRev['body_json'],
            'content'   => $targetRev['content'],
            'id'        => $documentId,
        ]);

        return [
            'success'             => true,
            'message'             => "Restored to revision #{$targetRev['revision_num']}. Pre-restore snapshot created.",
            'restored_revision'   => $targetRev['revision_num'],
            'pre_restore_rev_id'  => $preRestoreRevId,
            'body_json'           => $targetRev['body_json'],
            'title'               => $targetRev['title']
        ];
    }

    private static function getNextRevisionNum(string $entity, int $documentId): int {
        $stmt = Database::prepare("
            SELECT MAX(revision_num) as max_rev 
            FROM `soi_document_revisions` 
            WHERE entity = :entity AND document_id = :doc_id
        ");
        $stmt->execute(['entity' => $entity, 'doc_id' => $documentId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        return ((int)($row['max_rev'] ?? 0)) + 1;
    }
}
