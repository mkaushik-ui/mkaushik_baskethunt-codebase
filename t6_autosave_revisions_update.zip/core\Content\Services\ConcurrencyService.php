<?php
namespace SOI\Core\Content\Services;

use SOI\Core\Database;

/**
 * Optimistic Concurrency Control Service
 * Prevents stale overwrites when multiple authors edit the same document.
 * Location: core/Content/Services/ConcurrencyService.php
 */
class ConcurrencyService {

    /**
     * Check if client's expected timestamp matches server's current timestamp.
     * Throws ConflictException or returns false if stale.
     *
     * @param string $entity Table name (e.g. 'pages', 'posts')
     * @param int $documentId
     * @param string|null $expectedTimestamp ISO/datetime string from client
     * @return array ['conflict' => bool, 'message' => string, 'server_updated_at' => string]
     */
    public static function validateConcurrency(string $entity, int $documentId, ?string $expectedTimestamp): array {
        if ($documentId <= 0 || empty($expectedTimestamp)) {
            return ['conflict' => false, 'message' => 'No concurrency timestamp provided.'];
        }

        $tableName = (str_starts_with($entity, 'soi_')) ? $entity : 'soi_' . $entity;
        
        $stmt = Database::prepare("SELECT updated_at FROM `{$tableName}` WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $documentId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            return ['conflict' => false, 'message' => 'Document not found.'];
        }

        $serverUpdatedAt = $row['updated_at'] ?? '';
        
        // Convert timestamps to unix epoch for precision comparison
        $clientTime = strtotime($expectedTimestamp);
        $serverTime = strtotime($serverUpdatedAt);

        // Allow 2-second grace period for clock skew / rounding
        if ($clientTime !== false && $serverTime !== false && ($serverTime - $clientTime) > 2) {
            return [
                'conflict'          => true,
                'message'           => 'Document has been modified by another user. Reload to view latest changes.',
                'server_updated_at' => $serverUpdatedAt,
                'client_expected'   => $expectedTimestamp
            ];
        }

        return [
            'conflict'          => false,
            'message'           => 'Concurrency check passed.',
            'server_updated_at' => $serverUpdatedAt
        ];
    }

    /**
     * Set HTTP 409 Conflict header and return JSON response.
     */
    public static function respondConflict(string $message, string $serverUpdatedAt): void {
        http_response_code(409);
        header('Content-Type: application/json');
        echo json_encode([
            'success'           => false,
            'error'             => 'concurrency_conflict',
            'message'           => $message,
            'server_updated_at' => $serverUpdatedAt
        ]);
        exit;
    }
}
