/**
 * Enterprise Knowledge Center - Inspector Shell Engine
 * Task EUX-12: Document Layout Presets Canvas Engine
 * 
 * Manages right inspector panel layout controls, toggling canvas width
 * immediately between Standard (820px), Wide (1140px), and Full-width (100%),
 * and notifying the editor engine to persist layout_preset in document metadata.
 */
(function (global) {
  'use strict';

  let currentPreset = 'standard';
  let isInitialized = false;

  const PRESET_MAP = {
    'default': 'standard',
    'standard': 'standard',
    'wide': 'wide',
    'full': 'full'
  };

  const CLASS_MAP = {
    'standard': 'kc-layout-standard',
    'wide': 'kc-layout-wide',
    'full': 'kc-layout-full'
  };

  function normalizePreset(val) {
    if (!val) return 'standard';
    const lower = String(val).toLowerCase().trim();
    return PRESET_MAP[lower] || 'standard';
  }

  function applyLayoutPreset(presetName, options) {
    const norm = normalizePreset(presetName);
    currentPreset = norm;
    const targetClass = CLASS_MAP[norm];

    // 1. Target elements: Canvas surface, Redactor root, Workspace wrapper
    const canvas = document.getElementById('kc-editor-canvas');
    const redactor = document.querySelector('.codex-editor__redactor');
    const workspace = document.getElementById('kc-editor') || document.querySelector('.kc-workspace');

    const targets = [canvas, redactor, workspace].filter(Boolean);

    targets.forEach(function (el) {
      el.classList.remove('kc-layout-standard', 'kc-layout-wide', 'kc-layout-full', 'kc-layout-default');
      el.classList.add(targetClass);
    });

    // 2. Synchronize select dropdown in the Layout tab
    const select = document.getElementById('kc-layout-preset-select');
    if (select) {
      select.value = (norm === 'standard' ? 'default' : norm);
    }

    // 3. Notify callback if provided
    if (options && typeof options.onChange === 'function') {
      options.onChange(norm);
    }

    // Also dispatch event on window for loose coupling
    window.dispatchEvent(new CustomEvent('kc:layout-preset-changed', {
      detail: { preset: norm, className: targetClass }
    }));

    return norm;
  }

  function getLayoutPreset() {
    return currentPreset;
  }

  function init(options) {
    if (isInitialized && !options?.force) return;
    isInitialized = true;

    options = options || {};

    const select = document.getElementById('kc-layout-preset-select');
    if (select) {
      select.addEventListener('change', function () {
        const norm = applyLayoutPreset(select.value, options);
        if (typeof options.markDirty === 'function') {
          options.markDirty();
        } else if (typeof global.markDirty === 'function') {
          global.markDirty();
        }
      });
    }

    // Mobile Stacking Checkbox
    const stackMobile = document.getElementById('kc-stack-mobile');
    if (stackMobile) {
      stackMobile.addEventListener('change', function () {
        const canvas = document.getElementById('kc-editor-canvas');
        if (canvas) {
          canvas.classList.toggle('kc-stack-mobile-enabled', stackMobile.checked);
        }
        if (typeof options.markDirty === 'function') {
          options.markDirty();
        }
      });
    }

    // Initial preset resolution: option > select value > default
    const initial = options.initialPreset || (select ? select.value : 'default');
    applyLayoutPreset(initial, options);
  }

  // Auto-initialize if DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { init(); });
  } else {
    init();
  }

  global.KcInspectorShell = {
    init: init,
    applyLayoutPreset: applyLayoutPreset,
    getLayoutPreset: getLayoutPreset,
    normalizePreset: normalizePreset
  };

})(typeof window !== 'undefined' ? window : this);
