<?php
/**
 * Admin — Posts Management (List + Edit + New + Delete)
 */
$pageTitle = 'Posts';
$activeNav = 'posts';
$pageContentClass = 'page-content--fluid';

if (!defined('SOI_ROOT')) define('SOI_ROOT', dirname(__DIR__));
require_once SOI_ROOT . '/config/config.php';
require_once SOI_ROOT . '/core/helpers.php';
spl_autoload_register(fn($c) => (fn($f) => file_exists($f) && require_once $f)(SOI_ROOT.'/core/'.str_replace(['SOI\\Core\\','\\'],['','/'],$c).'.php'));
use SOI\Core\{Database, Auth, Blog};
Database::connect(['host'=>SOI_DB_HOST,'name'=>SOI_DB_NAME,'user'=>SOI_DB_USER,'pass'=>SOI_DB_PASS,'port'=>SOI_DB_PORT,'prefix'=>SOI_DB_PREFIX]);
Auth::init();
Auth::requireAuth('author');
Blog::ensureMigrated();
if (!Blog::isEnabled()) {
    soi_flash('error', 'Blog features are disabled. Enable them in General Settings → Blog Module.');
    soi_redirect(SOI_ADMIN_URL . '/settings.php');
}

$action = soi_get('action', 'list');
$id     = (int) soi_get('id', 0);

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::verifyCsrf($_POST['_csrf'] ?? '')) die('CSRF check failed.');
    $postAction = $_POST['_action'] ?? '';

    if ($postAction === 'save') {
        $title    = trim($_POST['title'] ?? '');
        $slug     = slugify(trim($_POST['slug'] ?? '') ?: $title);
        $content  = $_POST['content'] ?? '';
        $excerpt  = trim($_POST['excerpt'] ?? '');
        $status   = $_POST['status'] ?? 'draft';
        $metaT    = trim($_POST['meta_title'] ?? '');
        $metaD    = trim($_POST['meta_desc'] ?? '');
        $catIds   = $_POST['categories'] ?? [];
        $editId   = (int)($_POST['id'] ?? 0);

        if (empty($title)) { soi_flash('error', 'Title is required.'); }
        else {
            $data = ['title'=>$title,'slug'=>$slug,'content'=>$content,'excerpt'=>$excerpt,'status'=>$status,'meta_title'=>$metaT,'meta_desc'=>$metaD];
            if ($editId) {
                Database::update('posts', $data, 'id = ?', [$editId]);
                // Sync categories
                $postId = $editId;
                Database::query("DELETE FROM `" . Database::prefix('post_categories') . "` WHERE post_id = ?", [$postId]);
            } else {
                $data['author_id'] = Auth::id();
                $postId = Database::insert('posts', $data);
            }
            foreach ($catIds as $catId) {
                $catId = (int)$catId;
                if ($catId) Database::query("INSERT IGNORE INTO `" . Database::prefix('post_categories') . "` (post_id, category_id) VALUES (?,?)", [$postId, $catId]);
            }
            class_exists(\SOI\Core\Cache::class) && \SOI\Core\Cache::purgeAll();
            soi_flash('success', $editId ? 'Post updated.' : 'Post created.');
            soi_redirect(SOI_ADMIN_URL . '/posts.php');
        }
    }

    if ($postAction === 'delete') {
        $delId = (int)($_POST['id'] ?? 0);
        if ($delId) {
            Database::delete('posts', 'id = ?', [$delId]);
            class_exists(\SOI\Core\Cache::class) && \SOI\Core\Cache::purgeAll();
            soi_flash('success', 'Post deleted.');
        }
        soi_redirect(SOI_ADMIN_URL . '/posts.php');
    }
}

$editPost = null;
if ($action === 'edit' && $id) {
    $editPost = Database::selectOne("SELECT * FROM `" . Database::prefix('posts') . "` WHERE id = ?", [$id]);
    if (!$editPost) { soi_flash('error', 'Post not found.'); soi_redirect(SOI_ADMIN_URL . '/posts.php'); }
    $pageTitle = 'Edit Post';
    // Get assigned categories
    $assignedCats = array_column(Database::select(
        "SELECT category_id FROM `" . Database::prefix('post_categories') . "` WHERE post_id = ?", [$id]
    ), 'category_id');
}
if ($action === 'new') { $pageTitle = 'New Post'; $assignedCats = []; }

$allCategories = Database::select("SELECT * FROM `" . Database::prefix('categories') . "` ORDER BY name");

$topbarActions = $action === 'list'
    ? '<a href="?action=new" class="topbar-btn topbar-btn-primary">+ New Post</a>'
    : '<a href="' . SOI_ADMIN_URL . '/posts.php" class="topbar-btn topbar-btn-ghost">← All Posts</a>';

$extraHead = '<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>tinymce.init({selector:"#tinymce-editor",height:450,plugins:"lists link image code table media",toolbar:"undo redo | h2 h3 | bold italic | bullist numlist | link image media | table | code",skin:"oxide",content_css:"default",promotion:false});</script>';

require_once __DIR__ . '/partials/header.php';

if ($action === 'list'):
    $filter = soi_get('status','');
    $search = soi_get('q','');
    $where = '1=1'; $params = [];
    if ($filter) { $where .= " AND p.status = ?"; $params[] = $filter; }
    if ($search) { $where .= " AND p.title LIKE ?"; $params[] = "%$search%"; }
    $posts = Database::select("SELECT p.*, u.display_name as author_name FROM `".Database::prefix('posts')."` p LEFT JOIN `".Database::prefix('users')."` u ON p.author_id=u.id WHERE $where ORDER BY p.created_at DESC", $params);
?>

<form method="GET" class="toolbar">
  <input class="search-input" type="text" name="q" placeholder="Search posts…" value="<?= esc($search) ?>">
  <button type="submit" class="btn btn-ghost">Search</button>
  <?php foreach(['','published','draft'] as $s): ?>
  <a href="?status=<?= $s ?>" class="btn btn-ghost btn-sm <?= $filter===$s?'btn-primary':'' ?>"><?= $s?ucfirst($s):'All' ?></a>
  <?php endforeach; ?>
</form>

<div class="card">
  <?php if (!$posts): ?>
  <div class="empty-state">
    <div class="empty-state-icon">📝</div>
    <div class="empty-state-title">No posts yet</div>
    <div class="empty-state-text"><a href="?action=new" class="admin-link">Write your first post →</a></div>
  </div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="table--dense">
      <thead><tr>
        <th><input type="checkbox" id="select-all"></th>
        <th>Title</th><th>Author</th><th>Status</th><th>Date</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php foreach ($posts as $post): ?>
        <tr>
          <td><input type="checkbox" class="row-checkbox"></td>
          <td class="td-title">
            <a href="?action=edit&id=<?= $post['id'] ?>" class="table-link"><?= esc($post['title']) ?></a>
            <div class="table-meta">/<?= esc($post['slug']) ?></div>
          </td>
          <td><?= esc($post['author_name'] ?? '—') ?></td>
          <td>
            <?php $sc = ['published'=>'badge-success','draft'=>'badge-warning','private'=>'badge-info'][$post['status']] ?? 'badge-muted'; ?>
            <span class="badge <?= $sc ?>"><?= esc($post['status']) ?></span>
          </td>
          <td class="text-muted nowrap"><?= date('M j, Y', strtotime($post['created_at'])) ?></td>
          <td>
            <div class="td-actions">
              <a href="?action=edit&id=<?= $post['id'] ?>" class="btn btn-ghost btn-sm">✏️ Edit</a>
              <a href="<?= SOI_HOME_URL ?>/<?= esc($post['slug']) ?>" target="_blank" class="btn btn-ghost btn-sm">🌐</a>
              <form method="POST" class="form-inline">
                <?= Auth::csrfField() ?>
                <input type="hidden" name="_action" value="delete">
                <input type="hidden" name="id" value="<?= $post['id'] ?>">
                <button class="btn btn-danger btn-sm" data-confirm="Delete this post?">🗑️</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php else: // edit/new form
$p = $editPost ?? [];
?>
<form method="POST">
  <?= Auth::csrfField() ?>
  <input type="hidden" name="_action" value="save">
  <input type="hidden" name="id" value="<?= $p['id'] ?? 0 ?>">

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;align-items:start;">
    <div style="display:flex;flex-direction:column;gap:1.25rem;">
      <div class="card card-body" style="padding:1.25rem;">
        <div class="form-group" style="margin-bottom:1rem;">
          <label class="form-label">Post Title</label>
          <input class="form-input" type="text" id="post-title" name="title" value="<?= esc($p['title'] ?? '') ?>" placeholder="Enter post title…" required>
        </div>
        <div class="form-group">
          <label class="form-label">Permalink Slug</label>
          <input class="form-input" type="text" id="post-slug" name="slug" value="<?= esc($p['slug'] ?? '') ?>">
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">Content</h3></div>
        <div style="padding:0;">
          <textarea id="tinymce-editor" name="content"><?= htmlspecialchars($p['content'] ?? '') ?></textarea>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">Excerpt</h3></div>
        <div class="card-body">
          <textarea class="form-textarea" name="excerpt" rows="3" placeholder="Optional short summary shown in blog listings…"><?= esc($p['excerpt'] ?? '') ?></textarea>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">SEO</h3></div>
        <div class="card-body form-section">
          <div class="form-group">
            <label class="form-label">Meta Title</label>
            <input class="form-input" type="text" name="meta_title" value="<?= esc($p['meta_title'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Meta Description</label>
            <textarea class="form-textarea" name="meta_desc" rows="3"><?= esc($p['meta_desc'] ?? '') ?></textarea>
          </div>
        </div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:1.25rem;">
      <div class="card">
        <div class="card-header"><h3 class="card-title">Publish</h3></div>
        <div class="card-body" style="display:flex;flex-direction:column;gap:0.75rem;">
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" name="status">
              <?php foreach(['published','draft','private'] as $s): ?>
              <option value="<?= $s ?>" <?= ($p['status']??'draft')===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">
            💾 <?= isset($editPost) ? 'Update Post' : 'Publish Post' ?>
          </button>
          <?php if (isset($editPost)): ?>
          <a href="<?= SOI_HOME_URL ?>/<?= esc($editPost['slug']) ?>" target="_blank" class="btn btn-ghost" style="width:100%;justify-content:center;">🌐 View Post</a>
          <?php endif; ?>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">Categories</h3></div>
        <div class="card-body" style="max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:0.5rem;">
          <?php if ($allCategories): ?>
            <?php foreach ($allCategories as $cat): ?>
            <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;font-size:0.83rem;">
              <input type="checkbox" name="categories[]" value="<?= $cat['id'] ?>" <?= in_array($cat['id'], $assignedCats ?? []) ? 'checked' : '' ?>>
              <?= esc($cat['name']) ?>
            </label>
            <?php endforeach; ?>
          <?php else: ?>
            <span style="font-size:0.8rem;color:var(--text-muted);">No categories yet.</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</form>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
