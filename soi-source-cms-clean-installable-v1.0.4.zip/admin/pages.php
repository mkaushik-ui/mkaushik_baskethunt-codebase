<?php
/**
 * Admin — Pages Management (List + Edit + New + Delete)
 */
$pageTitle = 'Pages';
$activeNav = 'pages';
$pageContentClass = 'page-content--fluid';

// Handle action before loading header
if (!defined('SOI_ROOT')) define('SOI_ROOT', dirname(__DIR__));
require_once SOI_ROOT . '/config/config.php';
require_once SOI_ROOT . '/core/helpers.php';
spl_autoload_register(fn($c) => (fn($f) => file_exists($f) && require_once $f)(SOI_ROOT.'/core/'.str_replace(['SOI\\Core\\','\\'],['','/'],$c).'.php'));
use SOI\Core\{Database, Auth};
Database::connect(['host'=>SOI_DB_HOST,'name'=>SOI_DB_NAME,'user'=>SOI_DB_USER,'pass'=>SOI_DB_PASS,'port'=>SOI_DB_PORT,'prefix'=>SOI_DB_PREFIX]);
Auth::init();
Auth::requireAuth('author');

$action = soi_get('action', 'list');
$id     = (int) soi_get('id', 0);

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::verifyCsrf($_POST['_csrf'] ?? '')) die('CSRF check failed.');

    $postAction = $_POST['_action'] ?? '';

    if ($postAction === 'save') {
        $title   = trim($_POST['title'] ?? '');
        $slug    = slugify(trim($_POST['slug'] ?? '') ?: $title);
        $content = $_POST['content'] ?? '';
        $status  = $_POST['status'] ?? 'draft';
        $metaT   = trim($_POST['meta_title'] ?? '');
        $metaD   = trim($_POST['meta_desc'] ?? '');
        $editId  = (int) ($_POST['id'] ?? 0);

        if (empty($title)) { soi_flash('error', 'Title is required.'); }
        else {
            $data = ['title'=>$title,'slug'=>$slug,'content'=>$content,'status'=>$status,'meta_title'=>$metaT,'meta_desc'=>$metaD];
            if ($editId) {
                Database::update('pages', $data, 'id = ?', [$editId]);
                class_exists(\SOI\Core\Cache::class) && \SOI\Core\Cache::purgeAll();
                soi_flash('success', 'Page updated successfully.');
            } else {
                $data['author_id'] = Auth::id();
                Database::insert('pages', $data);
                class_exists(\SOI\Core\Cache::class) && \SOI\Core\Cache::purgeAll();
                soi_flash('success', 'Page created successfully.');
            }
            soi_redirect(SOI_ADMIN_URL . '/pages.php');
        }
    }

    if ($postAction === 'delete') {
        $delId = (int) ($_POST['id'] ?? 0);
        if ($delId) {
            Database::delete('pages', 'id = ?', [$delId]);
            class_exists(\SOI\Core\Cache::class) && \SOI\Core\Cache::purgeAll();
            soi_flash('success', 'Page deleted.');
        }
        soi_redirect(SOI_ADMIN_URL . '/pages.php');
    }
}


// Load page for editing
$editPage = null;
if ($action === 'edit' && $id) {
    $editPage = Database::selectOne("SELECT * FROM `" . Database::prefix('pages') . "` WHERE id = ?", [$id]);
    if (!$editPage) { soi_flash('error', 'Page not found.'); soi_redirect(SOI_ADMIN_URL . '/pages.php'); }
    $pageTitle = 'Edit Page';
}
if ($action === 'new') {
    $pageTitle = 'New Page';
}

$topbarActions = '';
if ($action === 'list') {
    $topbarActions = '<a href="?action=new" class="topbar-btn topbar-btn-primary">+ New Page</a>';
} else {
    $topbarActions = '<a href="' . SOI_ADMIN_URL . '/pages.php" class="topbar-btn topbar-btn-ghost">← All Pages</a>';
}

$extraHead = '<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>tinymce.init({selector:"#tinymce-editor",height:400,plugins:"lists link image code table",toolbar:"undo redo | h2 h3 | bold italic underline | bullist numlist | link image | table | code",skin:"oxide",content_css:"default",promotion:false});</script>';

require_once __DIR__ . '/partials/header.php';

// ===========================
// List View
// ===========================
if ($action === 'list'):
    $filter = soi_get('status', '');
    $search = soi_get('q', '');
    $where  = '1=1';
    $params = [];
    if ($filter) { $where .= " AND status = ?"; $params[] = $filter; }
    if ($search) { $where .= " AND title LIKE ?"; $params[] = "%$search%"; }
    $pages = Database::select("SELECT * FROM `" . Database::prefix('pages') . "` WHERE $where ORDER BY created_at DESC", $params);
?>
<form method="GET" class="toolbar">
  <input type="hidden" name="status" value="<?= esc($filter) ?>">
  <input class="search-input" type="text" name="q" placeholder="Search pages…" value="<?= esc($search) ?>">
  <button type="submit" class="btn btn-ghost">Search</button>
  <?php foreach(['','published','draft'] as $s): ?>
  <a href="?status=<?= $s ?>" class="btn btn-ghost btn-sm <?= $filter===$s?'btn-primary':'' ?>"><?= $s?ucfirst($s):'All' ?></a>
  <?php endforeach; ?>
</form>

<div class="card">
  <?php if (!$pages): ?>
  <div class="empty-state">
    <div class="empty-state-icon">📄</div>
    <div class="empty-state-title">No pages found</div>
    <div class="empty-state-text"><a href="?action=new" class="admin-link">Create your first page →</a></div>
  </div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="table--dense">
      <thead><tr>
        <th><input type="checkbox" id="select-all"></th>
        <th>Title</th><th>Slug</th><th>Status</th><th>Date</th><th>Actions</th>
      </tr></thead>
      <tbody>
        <?php foreach ($pages as $page): ?>
        <tr>
          <td><input type="checkbox" class="row-checkbox" value="<?= $page['id'] ?>"></td>
          <td class="td-title"><a href="?action=edit&id=<?= $page['id'] ?>" class="table-link"><?= esc($page['title']) ?></a></td>
          <td><code class="table-meta">/<?= esc($page['slug']) ?></code></td>
          <td>
            <?php $sc = ['published'=>'badge-success','draft'=>'badge-warning','private'=>'badge-info'][$page['status']] ?? 'badge-muted'; ?>
            <span class="badge <?= $sc ?>"><?= esc($page['status']) ?></span>
          </td>
          <td class="text-muted nowrap"><?= date('M j, Y', strtotime($page['created_at'])) ?></td>
          <td>
            <div class="td-actions">
              <a href="?action=edit&id=<?= $page['id'] ?>" class="btn btn-ghost btn-sm">✏️ Edit</a>
              <a href="<?= SOI_HOME_URL ?>/<?= esc($page['slug']) ?>" target="_blank" class="btn btn-ghost btn-sm">🌐</a>
              <form method="POST" class="form-inline">
                <?= Auth::csrfField() ?>
                <input type="hidden" name="_action" value="delete">
                <input type="hidden" name="id" value="<?= $page['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm" data-confirm="Delete this page?">🗑️</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php
// ===========================
// Edit / New Form
// ===========================
else:
    $p = $editPage ?? [];
?>
<form method="POST">
  <?= Auth::csrfField() ?>
  <input type="hidden" name="_action" value="save">
  <input type="hidden" name="id" value="<?= $p['id'] ?? 0 ?>">

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;align-items:start;">
    <!-- Left -->
    <div style="display:flex;flex-direction:column;gap:1.25rem;">
      <div class="card">
        <div class="card-body">
          <div class="form-group" style="margin-bottom:1rem;">
            <label class="form-label">Page Title</label>
            <input class="form-input" type="text" id="page-title" name="title" value="<?= esc($p['title'] ?? '') ?>" placeholder="Enter page title…" required>
          </div>
          <div class="form-group">
            <label class="form-label">Permalink Slug</label>
            <input class="form-input" type="text" id="page-slug" name="slug" value="<?= esc($p['slug'] ?? '') ?>" placeholder="auto-generated-from-title">
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">Content</h3></div>
        <div class="card-body" style="padding:0;">
          <textarea id="tinymce-editor" name="content"><?= htmlspecialchars($p['content'] ?? '') ?></textarea>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3 class="card-title">SEO</h3></div>
        <div class="card-body form-section">
          <div class="form-group">
            <label class="form-label">Meta Title</label>
            <input class="form-input" type="text" name="meta_title" value="<?= esc($p['meta_title'] ?? '') ?>" placeholder="SEO title (leave blank to use page title)">
          </div>
          <div class="form-group">
            <label class="form-label">Meta Description</label>
            <textarea class="form-textarea" name="meta_desc" rows="3" placeholder="Short description for search engines…"><?= esc($p['meta_desc'] ?? '') ?></textarea>
          </div>
        </div>
      </div>
    </div>

    <!-- Right -->
    <div style="display:flex;flex-direction:column;gap:1.25rem;">
      <div class="card">
        <div class="card-header"><h3 class="card-title">Publish</h3></div>
        <div class="card-body">
          <div class="form-group" style="margin-bottom:1rem;">
            <label class="form-label">Status</label>
            <select class="form-select" name="status">
              <?php foreach (['published','draft','private'] as $s): ?>
              <option value="<?= $s ?>" <?= ($p['status'] ?? 'draft') === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">
            💾 <?= isset($editPage) ? 'Update Page' : 'Publish Page' ?>
          </button>
          <?php if (isset($editPage)): ?>
          <a href="<?= SOI_HOME_URL ?>/<?= esc($editPage['slug']) ?>" target="_blank" class="btn btn-ghost" style="width:100%;justify-content:center;margin-top:0.5rem;">
            🌐 View Page
          </a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</form>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
