<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Content\RenderContext;

/**
 * Task EUX-01: Divider Block Provider.
 */
class DividerBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'divider';
    }

    public function label(): string
    {
        return 'Divider';
    }

    public function category(): string
    {
        return 'basic';
    }

    public function sanitize(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        return '<hr class="kc-divider-line" />';
    }
}