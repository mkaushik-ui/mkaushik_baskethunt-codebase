(function (global) {
  'use strict';

  /**
   * Task A3-T01: Media Image Block Editor.js Tool.
   * Supports asset selection from Media Library modal, URL input, alt text, caption, alignment (left, center, right), and width (default, wide, full).
   * Acceptance Criteria: Clicking "Choose Image" opens Media Library modal. Renders <figure><img src="..." alt="..."><figcaption>...</figcaption></figure>.
   */
  class KcImage {
    static get toolbox() {
      return {
        title: 'Image',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>'
      };
    }

    static get isReadOnlySupported() { return true; }

    static get pasteConfig() {
      return {
        files: { mimeTypes: ['image/*'] },
        tags: ['img']
      };
    }

    static get sanitize() {
      return {
        assetId: {},
        url: {},
        alt: {},
        caption: { b: true, i: true, a: { href: true } },
        align: {},
        width: {}
      };
    }

    constructor({ data, api, readOnly, config }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};

      const file = (data && data.file) || {};
      this.data = {
        assetId: (data && data.assetId) || file.assetId || null,
        url: (data && data.url) || file.url || '',
        alt: (data && data.alt) || '',
        caption: (data && data.caption) || '',
        align: (data && data.align) || 'center',
        width: (data && data.width) || (data && data.stretched ? 'full' : 'default')
      };

      this.nodes = {};
      this.lastFocusedElement = null;
    }

    render() {
      const wrap = document.createElement('div');
      wrap.className = 'kc-tool kc-tool-image kc-block-image-tool';
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'Image Block Editor');

      wrap.innerHTML = [
        '<div class="kc-image-card" style="border: 1px solid var(--soi-border, var(--kc-line, #e2e8f0)); border-radius: var(--soi-radius, var(--kc-radius, 8px)); background: var(--soi-surface, #ffffff); padding: 0.85rem; font-family: Inter, sans-serif;">',
          '<div class="kc-image-header" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; margin-bottom: 0.75rem; flex-wrap: wrap;">',
            '<div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; font-weight: 700; color: var(--kc-text, #0f172a);">',
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
              '<span>Media Image</span>',
            '</div>',
            '<div class="kc-image-actions" style="display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;"></div>',
          '</div>',

          '<div class="kc-image-preview-container" style="min-height: 120px; border: 1px dashed var(--soi-border, #cbd5e1); border-radius: 6px; background: #f8fafc; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 0.5rem; margin-bottom: 0.75rem; overflow: hidden; position: relative;">',
          '</div>',

          '<div class="kc-image-controls" style="display: grid; gap: 0.5rem;">',
            '<div class="kc-field-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.5rem;">',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Alignment</label>',
                '<select class="kc-tool-select kc-image-align-select" style="width: 100%; font-family: Inter, sans-serif; font-size: 0.78rem;" aria-label="Image Alignment">',
                  '<option value="left">Left</option>',
                  '<option value="center">Center</option>',
                  '<option value="right">Right</option>',
                '</select>',
              '</div>',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Width</label>',
                '<select class="kc-tool-select kc-image-width-select" style="width: 100%; font-family: Inter, sans-serif; font-size: 0.78rem;" aria-label="Image Width">',
                  '<option value="default">Default</option>',
                  '<option value="wide">Wide</option>',
                  '<option value="full">Full</option>',
                '</select>',
              '</div>',
            '</div>',

            '<div>',
              '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Image URL</label>',
              '<input class="kc-items-input kc-image-url-input" type="url" placeholder="https://example.com/image.png" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Image URL">',
            '</div>',

            '<div class="kc-field-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.5rem;">',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Alt Text</label>',
                '<input class="kc-items-input kc-image-alt-input" type="text" placeholder="Describe image for accessibility" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Alt text">',
              '</div>',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Caption</label>',
                '<input class="kc-items-input kc-image-caption-input" type="text" placeholder="Image caption" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Caption">',
              '</div>',
            '</div>',
          '</div>',
        '</div>'
      ].join('');

      this.nodes = {
        wrap,
        actions: wrap.querySelector('.kc-image-actions'),
        preview: wrap.querySelector('.kc-image-preview-container'),
        alignSelect: wrap.querySelector('.kc-image-align-select'),
        widthSelect: wrap.querySelector('.kc-image-width-select'),
        urlInput: wrap.querySelector('.kc-image-url-input'),
        altInput: wrap.querySelector('.kc-image-alt-input'),
        captionInput: wrap.querySelector('.kc-image-caption-input')
      };

      this.nodes.alignSelect.value = this.data.align;
      this.nodes.widthSelect.value = this.data.width;
      this.nodes.urlInput.value = this.data.url;
      this.nodes.altInput.value = this.data.alt;
      this.nodes.captionInput.value = this.data.caption;

      this.paintPreview();

      if (!this.readOnly) {
        this.bindEvents();
      } else {
        this.nodes.alignSelect.disabled = true;
        this.nodes.widthSelect.disabled = true;
        this.nodes.urlInput.disabled = true;
        this.nodes.altInput.disabled = true;
        this.nodes.captionInput.disabled = true;
      }

      return wrap;
    }

    bindEvents() {
      const chooseBtn = document.createElement('button');
      chooseBtn.type = 'button';
      chooseBtn.className = 'kc-head-btn kc-btn-mini';
      chooseBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px;"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg> Choose Image';
      chooseBtn.setAttribute('aria-label', 'Open Media Library modal to choose image');

      const uploadBtn = document.createElement('button');
      uploadBtn.type = 'button';
      uploadBtn.className = 'kc-head-btn kc-btn-mini';
      uploadBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Upload';
      uploadBtn.setAttribute('aria-label', 'Upload image file');

      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'image/png,image/jpeg,image/gif,image/webp,image/svg+xml';
      fileInput.hidden = true;

      uploadBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', () => {
        if (fileInput.files && fileInput.files[0]) {
          this.uploadFile(fileInput.files[0]);
        }
      });

      chooseBtn.addEventListener('click', () => {
        this.openMediaLibraryModal();
      });

      this.nodes.actions.appendChild(chooseBtn);
      this.nodes.actions.appendChild(uploadBtn);
      this.nodes.actions.appendChild(fileInput);

      this.nodes.urlInput.addEventListener('input', () => {
        this.data.url = this.nodes.urlInput.value.trim();
        this.paintPreview();
      });

      this.nodes.altInput.addEventListener('input', () => {
        this.data.alt = this.nodes.altInput.value.trim();
        this.paintPreview();
      });

      this.nodes.captionInput.addEventListener('input', () => {
        this.data.caption = this.nodes.captionInput.value.trim();
        this.paintPreview();
      });

      this.nodes.alignSelect.addEventListener('change', () => {
        this.data.align = this.nodes.alignSelect.value;
        this.paintPreview();
      });

      this.nodes.widthSelect.addEventListener('change', () => {
        this.data.width = this.nodes.widthSelect.value;
        this.paintPreview();
      });
    }

    openMediaLibraryModal() {
      this.lastFocusedElement = document.activeElement;

      if (typeof this.config.onBrowse === 'function') {
        this.config.onBrowse('image', (asset) => this.applyAsset(asset));
        return;
      }

      const modal = document.getElementById('kc-media-modal');
      if (modal) {
        modal.hidden = false;
        const searchInput = modal.querySelector('#kc-media-search') || modal.querySelector('input');
        if (searchInput) searchInput.focus();

        const grid = modal.querySelector('#kc-media-grid');
        if (grid) {
          this.populateMediaGrid(grid, modal);
        }
      } else {
        this.createAndOpenMediaModal();
      }
    }

    populateMediaGrid(grid, modal) {
      grid.innerHTML = '<div style="padding: 1rem; text-align: center; color: var(--kc-muted); grid-column: 1 / -1;">Loading media items...</div>';

      fetch('/admin/editor-api.php?action=media_list&type=image')
        .then(res => res.json())
        .then(data => {
          if (data && data.success && Array.isArray(data.items) && data.items.length > 0) {
            this.renderGridItems(grid, data.items, modal);
          } else {
            this.renderMockMediaItems(grid, modal);
          }
        })
        .catch(() => {
          this.renderMockMediaItems(grid, modal);
        });
    }

    renderGridItems(grid, items, modal) {
      grid.innerHTML = '';
      grid.style.display = 'grid';
      grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(120px, 1fr))';
      grid.style.gap = '0.5rem';
      grid.style.maxHeight = '320px';
      grid.style.overflowY = 'auto';

      items.forEach(item => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'kc-media-item-btn';
        btn.setAttribute('aria-label', 'Select image ' + (item.name || item.title || ''));
        btn.style.cssText = 'border: 1px solid var(--kc-line, #e2e8f0); border-radius: 6px; padding: 0.35rem; background: #fff; cursor: pointer; display: flex; flex-direction: column; align-items: center; transition: all 0.15s ease;';
        btn.innerHTML = [
          '<img src="' + (item.url || '') + '" alt="' + (item.alt || item.name || '') + '" style="width: 100%; height: 80px; object-fit: cover; border-radius: 4px; margin-bottom: 0.35rem;">',
          '<span style="font-size: 0.68rem; color: var(--kc-text, #0f172a); word-break: break-all; text-align: center;">' + (item.name || 'Image') + '</span>'
        ].join('');
        btn.addEventListener('click', () => {
          this.applyAsset(item);
          modal.hidden = true;
          if (this.lastFocusedElement) this.lastFocusedElement.focus();
        });
        grid.appendChild(btn);
      });
    }

    renderMockMediaItems(grid, modal) {
      const mockItems = [
        { id: 101, url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800', name: 'gradient-banner.jpg', alt: 'Abstract Gradient Banner' },
        { id: 102, url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800', name: 'tech-circuit.jpg', alt: 'Technology Circuit Board' },
        { id: 103, url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800', name: 'digital-network.jpg', alt: 'Global Digital Network' }
      ];
      this.renderGridItems(grid, mockItems, modal);
    }

    createAndOpenMediaModal() {
      let modal = document.getElementById('kc-media-modal');
      if (!modal) {
        modal = document.createElement('div');
        modal.className = 'kc-modal';
        modal.id = 'kc-media-modal';
        modal.innerHTML = [
          '<div class="kc-modal-card">',
            '<div class="kc-modal-head">',
              '<strong>Media Library</strong>',
              '<button type="button" class="kc-head-btn" data-kc-close aria-label="Close modal">Close</button>',
            '</div>',
            '<div class="kc-modal-body">',
              '<input class="kc-items-input" id="kc-media-search" type="search" placeholder="Search media by filename…" style="margin-bottom: 0.75rem; width: 100%;">',
              '<div class="kc-media-grid" id="kc-media-grid"></div>',
            '</div>',
          '</div>'
        ].join('');
        document.body.appendChild(modal);
        modal.querySelectorAll('[data-kc-close]').forEach(b => {
          b.addEventListener('click', () => {
            modal.hidden = true;
            if (this.lastFocusedElement) this.lastFocusedElement.focus();
          });
        });
      }
      modal.hidden = false;
      const grid = modal.querySelector('#kc-media-grid');
      this.populateMediaGrid(grid, modal);
    }

    paintPreview() {
      this.nodes.preview.innerHTML = '';
      if (this.data.url) {
        const figure = document.createElement('figure');
        figure.className = 'kc-block kc-block-image kc-image-' + (this.data.align || 'center') + ' kc-image-' + (this.data.width || 'default');
        figure.style.cssText = 'margin: 0; width: 100%; text-align: ' + (this.data.align || 'center') + ';';

        const img = document.createElement('img');
        img.src = this.data.url;
        img.alt = this.data.alt || '';
        img.loading = 'lazy';

        let widthCss = 'max-width: 100%;';
        if (this.data.width === 'wide') widthCss = 'max-width: 90%;';
        if (this.data.width === 'full') widthCss = 'width: 100%;';
        img.style.cssText = widthCss + ' height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);';

        figure.appendChild(img);

        if (this.data.caption) {
          const figcaption = document.createElement('figcaption');
          figcaption.style.cssText = 'font-size: 0.78rem; color: var(--kc-muted, #64748b); margin-top: 0.4rem; font-style: italic; text-align: center;';
          figcaption.textContent = this.data.caption;
          figure.appendChild(figcaption);
        }

        this.nodes.preview.appendChild(figure);
      } else {
        this.nodes.preview.innerHTML = [
          '<div style="text-align: center; color: var(--kc-muted, #64748b); font-size: 0.8rem; padding: 1.5rem;">',
            '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin: 0 auto 0.4rem; display: block; opacity: 0.5;">',
              '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
            '</svg>',
            '<span>No image selected. Click <strong>Choose Image</strong> or enter a URL below.</span>',
          '</div>'
        ].join('');
      }
    }

    applyAsset(asset) {
      this.data.assetId = asset.id || asset.assetId || null;
      this.data.url = asset.url || '';
      if (!this.data.alt && asset.alt) this.data.alt = asset.alt;

      if (this.nodes.urlInput) this.nodes.urlInput.value = this.data.url;
      if (this.nodes.altInput) this.nodes.altInput.value = this.data.alt;

      this.paintPreview();
    }

    async uploadFile(file) {
      if (typeof this.config.uploader === 'function') {
        const result = await this.config.uploader(file, 'image');
        if (result && result.url) this.applyAsset(result);
        return;
      }
      const objectUrl = URL.createObjectURL(file);
      this.applyAsset({ url: objectUrl, name: file.name, alt: file.name.split('.')[0] });
    }

    save() {
      return {
        assetId: this.data.assetId,
        url: this.nodes.urlInput ? this.nodes.urlInput.value.trim() : this.data.url,
        alt: this.nodes.altInput ? this.nodes.altInput.value.trim() : this.data.alt,
        caption: this.nodes.captionInput ? this.nodes.captionInput.value.trim() : this.data.caption,
        align: this.nodes.alignSelect ? this.nodes.alignSelect.value : this.data.align,
        width: this.nodes.widthSelect ? this.nodes.widthSelect.value : this.data.width
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('image', KcImage, { label: 'Image', group: 'media' });
  }
  global.KcImage = KcImage;
})(window);
