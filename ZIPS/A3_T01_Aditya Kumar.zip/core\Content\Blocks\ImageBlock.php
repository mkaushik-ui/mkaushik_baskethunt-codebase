<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Media\ImageBlock as MediaImageBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\ImageBlock
 */
final class ImageBlock extends MediaImageBlock
{
}
