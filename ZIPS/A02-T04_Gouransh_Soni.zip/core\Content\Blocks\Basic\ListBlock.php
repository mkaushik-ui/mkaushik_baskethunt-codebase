<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A2-T03: Bulleted List Block Provider.
 * Supports infinitely nested unordered and ordered lists securely.
 */
class ListBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'list';
    }

    public function label(): string
    {
        return 'List';
    }

    public function category(): string
    {
        return 'basic';
    }

    public function sanitize(array $data): array
    {
        $style = ($data['style'] ?? 'unordered') === 'ordered' ? 'ordered' : 'unordered';
        $items = $this->sanitizeItemsArray($data['items'] ?? []);
        return [
            'style' => $style,
            'items' => $items,
        ];
    }

    private function sanitizeItemsArray(array $items): array
    {
        $clean = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                $clean[] = Html::sanitizeInline((string)$item);
                continue;
            }
            $clean[] = [
                'content' => Html::sanitizeInline((string)($item['content'] ?? '')),
                'items' => $this->sanitizeItemsArray($item['items'] ?? []),
            ];
        }
        return $clean;
    }

    public function icon(): string
    {
        // SVG Icon for the list block in the toolbox
        return '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>';
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = $block['data'] ?? [];
        $style = ($data['style'] ?? 'unordered') === 'ordered' ? 'ol' : 'ul';
        $items = $data['items'] ?? [];

        if (empty($items) || !is_array($items)) {
            return '';
        }

        // Apply strict UI design tokens
        $listClass = $style === 'ol' ? 'kc-list kc-list-ordered' : 'kc-list kc-list-unordered';
        $html = "<{$style} class=\"{$listClass}\">";
        $html .= $this->renderItems($items);
        $html .= "</{$style}>";

        return $html;
    }

    /**
     * Recursively traverses and renders the list items
     */
    private function renderItems(array $items): string
    {
        $html = '';
        foreach ($items as $item) {
            // Fallback for simple string lists
            if (!is_array($item)) {
                $content = $this->sanitizeHtml((string)$item);
                $html .= "<li class=\"kc-list-item\">{$content}</li>";
                continue;
            }

            // Secure rich-text inline tags
            $content = $this->sanitizeHtml((string)($item['content'] ?? ''));
            $subItems = $item['items'] ?? [];
            
            $html .= "<li class=\"kc-list-item\">{$content}";
            
            // Render nested sub-lists
            if (!empty($subItems) && is_array($subItems)) {
                $subStyle = ($item['style'] ?? 'unordered') === 'ordered' ? 'ol' : 'ul';
                $subClass = $subStyle === 'ol' ? 'kc-list-nested kc-list-ordered' : 'kc-list-nested kc-list-unordered';
                
                $html .= "<{$subStyle} class=\"{$subClass}\">";
                $html .= $this->renderItems($subItems);
                $html .= "</{$subStyle}>";
            }
            $html .= "</li>";
        }
        return $html;
    }

    private function sanitizeHtml(string $html): string
    {
        return Html::sanitizeInline($html);
    }
}
