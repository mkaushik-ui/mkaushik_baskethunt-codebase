<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Interactive\DefinitionListBlock as InteractiveDefinitionListBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\DefinitionListBlock
 */
final class DefinitionListBlock extends InteractiveDefinitionListBlock
{
}
