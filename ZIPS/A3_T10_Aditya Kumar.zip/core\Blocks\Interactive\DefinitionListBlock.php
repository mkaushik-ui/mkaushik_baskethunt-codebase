<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T10: Definition List / Glossary Block renderer and sanitizer.
 * Term-definition glossary component for technical vocabulary and SAML/OAuth specs.
 * Acceptance Criteria: Renders accessible glossary term pairs.
 */
class DefinitionListBlock extends AbstractBlock
{
    private const MAX_TERMS = 80;

    public function type(): string
    {
        return 'definitionList';
    }

    public function label(): string
    {
        return 'Definition List';
    }

    public function sanitize(array $data): array
    {
        return ['items' => self::sanitizeItems($data['items'] ?? [])];
    }

    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_TERMS) {
            return ['Definition list cannot contain more than 80 terms.'];
        }
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if ($items === []) {
            return '';
        }

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $html = '<dl class="kc-block kc-block-deflist"' . $dataAttr . ' style="margin: 1rem 0; font-family: Inter, sans-serif;">';
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $term = Html::plainText((string) ($item['term'] ?? $item['title'] ?? ''));
            $description = (string) ($item['description'] ?? $item['content'] ?? '');
            if ($term === '' && Html::plainText($description) === '') {
                continue;
            }

            $html .= '<div class="kc-deflist-row" style="margin-bottom: 0.85rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.65rem;">';
            $html .= '<dt class="kc-deflist-term" style="font-weight: 700; font-size: 0.92rem; color: #0f172a; margin-bottom: 0.25rem;">' . Html::escape($term !== '' ? $term : 'Term') . '</dt>';
            $html .= '<dd class="kc-deflist-desc" style="margin-left: 0; font-size: 0.85rem; color: #334155; line-height: 1.5;">' . $description . '</dd>';
            $html .= '</div>';
        }
        $html .= '</dl>';
        return $html;
    }

    /**
     * @param mixed $items
     * @return list<array{term:string,description:string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }
        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $term = Html::plainText(Html::clampText((string) ($item['term'] ?? $item['title'] ?? ''), 300));
            $description = Html::sanitizeInline((string) ($item['description'] ?? $item['content'] ?? ''), 10000);
            if ($term === '' && Html::plainText($description) === '') {
                continue;
            }
            $out[] = ['term' => $term, 'description' => $description];
            if (count($out) >= self::MAX_TERMS) {
                break;
            }
        }
        return $out;
    }
}
