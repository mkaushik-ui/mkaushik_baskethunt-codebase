<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A1-T01: Paragraph Block Provider.
 * Highly secure implementation supporting rich inline tags.
 */
class ParagraphBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'paragraph';
    }

    public function label(): string
    {
        return 'Paragraph';
    }

    public function category(): string
    {
        return 'basic';
    }

    public function sanitize(array $data): array
    {
        return [
            // $this->inline() leverages Html::sanitizeInline ensuring XSS prevention 
            // while preserving allowed inline tags (b, i, u, s, code, a)
            'text' => $this->inline($data['text'] ?? ''),
        ];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $text = (string)($block['data']['text'] ?? '');
        
        // Prevent rendering empty paragraph tags unless they contain visual elements like <br>
        if (trim(Html::plainText($text)) === '' && !str_contains($text, '<img') && !str_contains($text, '<br')) {
            return '';
        }
        
        $id = $block['id'] ?? '';
        return '<p class="kc-block kc-block-paragraph" data-block-id="' . Html::escape($id) . '">' . $text . '</p>';
    }
}
