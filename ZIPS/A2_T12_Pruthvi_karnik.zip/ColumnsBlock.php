<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Layout;

use SOI\Core\Content\BlockRegistry;
use SOI\Core\Content\Html;
use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\RenderContext;

/**
 * ColumnsBlock
 *
 * Multi-column layout container.
 */
final class ColumnsBlock extends AbstractBlock
{
    public const LAYOUTS = [
        '50-50',
        '33-67',
        '67-33',
        '33-33-33',
        '25-25-25-25',
    ];

    public function type(): string
    {
        return 'columns';
    }

    public function label(): string
    {
        return 'Columns';
    }

    public function capabilities(): array
    {
        return [
            'nestable' => true,
            'reusable' => true,
            'wide'     => true,
            'interactive' => false,
        ];
    }

    public function sanitize(array $data): array
    {
        $layout = $this->enum(
            $data['layout'] ?? '50-50',
            self::LAYOUTS,
            '50-50'
        );

        $columns = [];

        $inputColumns = is_array($data['columns'] ?? null)
            ? $data['columns']
            : [];

        $columnCount = match ($layout) {
            '33-33-33' => 3,
            '25-25-25-25' => 4,
            default => 2,
        };

        for ($i = 0; $i < $columnCount; $i++) {
            $column = is_array($inputColumns[$i] ?? null)
                ? $inputColumns[$i]
                : [];

            $blocks = [];

            if (is_array($column['blocks'] ?? null)) {
                foreach ($column['blocks'] as $childBlock) {
                    if (!is_array($childBlock)) {
                        continue;
                    }

                    $childType = (string) ($childBlock['type'] ?? '');

                    if ($childType === '') {
                        continue;
                    }

                    /*
                     * Prevent columns from containing columns.
                     * This avoids recursive column structures.
                     */
                    if ($childType === 'columns') {
                        continue;
                    }

                    $childData = is_array($childBlock['data'] ?? null)
                        ? $childBlock['data']
                        : [];

                    if (BlockRegistry::has($childType)) {
                        $childHandler = BlockRegistry::get($childType);
                        $childData = $childHandler->sanitize($childData);
                    }

                    $blocks[] = [
                        'id' => (string) ($childBlock['id'] ?? ''),
                        'type' => $childType,
                        'data' => $childData,
                    ];
                }
            }

            $columns[] = [
                'blocks' => $blocks,
            ];
        }

        return [
            'layout' => $layout,
            'columns' => $columns,
        ];
    }

    public function validate(array $data): array
    {
        $errors = [];

        $layout = (string) ($data['layout'] ?? '50-50');

        if (!in_array($layout, self::LAYOUTS, true)) {
            $errors[] = "Invalid column layout '{$layout}'.";
        }

        $columns = is_array($data['columns'] ?? null)
            ? $data['columns']
            : [];

        foreach ($columns as $columnIndex => $column) {
            if (!is_array($column)) {
                continue;
            }

            $blocks = is_array($column['blocks'] ?? null)
                ? $column['blocks']
                : [];

            foreach ($blocks as $blockIndex => $childBlock) {
                if (!is_array($childBlock)) {
                    continue;
                }

                $childType = (string) ($childBlock['type'] ?? '');

                if ($childType === 'columns') {
                    $errors[] =
                        "Columns cannot be nested inside columns "
                        . "(column {$columnIndex}, block {$blockIndex}).";
                }
            }
        }

        return $errors;
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(
            is_array($block['data'] ?? null)
                ? $block['data']
                : []
        );

        $layout = $data['layout'];
        $columns = $data['columns'];

        $blockId = Html::escape(
            (string) ($block['id'] ?? '')
        );

        $layoutClass = Html::escape(
            'kc-cols-' . $layout
        );

        $html = sprintf(
            '<div id="%s" class="kc-columns %s" data-block-id="%s" data-block-type="columns">',
            $blockId,
            $layoutClass,
            $blockId
        );

        foreach ($columns as $index => $column) {
            $html .= sprintf(
                '<div class="kc-column-wrapper kc-col-%d" data-col-index="%d">',
                $index + 1,
                $index
            );

            if (!is_array($column)) {
                $html .= '</div>';
                continue;
            }

            $childBlocks = is_array($column['blocks'] ?? null)
                ? $column['blocks']
                : [];

            foreach ($childBlocks as $childBlock) {
                if (!is_array($childBlock)) {
                    continue;
                }

                $childType = (string) ($childBlock['type'] ?? '');

                if ($childType === '') {
                    continue;
                }

                /*
                 * Prevent recursive columns.
                 */
                if ($childType === 'columns') {
                    continue;
                }

                if (!BlockRegistry::has($childType)) {
                    continue;
                }

                $childHandler = BlockRegistry::get($childType);

                $html .= $childHandler->render(
                    [
                        'id' => (string) ($childBlock['id'] ?? ''),
                        'type' => $childType,
                        'data' => is_array($childBlock['data'] ?? null)
                            ? $childBlock['data']
                            : [],
                    ],
                    $ctx
                );
            }

            $html .= '</div>';
        }

        $html .= '</div>';

        return $html;
    }
}