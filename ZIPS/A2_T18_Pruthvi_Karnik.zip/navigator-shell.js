/**
 * Task T2 / A2-T18: Navigator Shell Component.
 *
 * Renders the document outline tree, component library catalog,
 * and patterns tabs.
 *
 * A2-T18 acceptance criterion:
 * Clicking a heading in the Navigator tree scrolls the editor
 * canvas directly to that heading and highlights the target block.
 */
(function (global) {
  'use strict';

  class NavigatorShell {
    constructor(hostEl) {
      this.host =
        typeof hostEl === 'string'
          ? document.getElementById(hostEl)
          : hostEl;

      this.activeTab = 'components';

      this.boundClickHandler = null;
      this.boundKeydownHandler = null;
      this.boundEditorObserver = null;
      this.refreshTimer = null;

      this.injectStyles();
    }

    init() {
      if (!this.host) {
        return;
      }

      this.render();
      this.bindEvents();
      this.observeEditor();
    }

    render() {
      this.host.innerHTML = `
                <div class="kc-nav-tabs" role="tablist" aria-label="Editor navigation">
                    <button
                        type="button"
                        class="kc-nav-tab ${this.activeTab === 'components' ? 'is-active' : ''}"
                        data-nav="components"
                        role="tab"
                        aria-selected="${this.activeTab === 'components' ? 'true' : 'false'}"
                        aria-label="Components"
                    >
                        Components
                    </button>

                    <button
                        type="button"
                        class="kc-nav-tab ${this.activeTab === 'navigator' ? 'is-active' : ''}"
                        data-nav="navigator"
                        role="tab"
                        aria-selected="${this.activeTab === 'navigator' ? 'true' : 'false'}"
                        aria-label="Navigator"
                    >
                        Navigator
                    </button>

                    <button
                        type="button"
                        class="kc-nav-tab ${this.activeTab === 'patterns' ? 'is-active' : ''}"
                        data-nav="patterns"
                        role="tab"
                        aria-selected="${this.activeTab === 'patterns' ? 'true' : 'false'}"
                        aria-label="Patterns"
                    >
                        Patterns
                    </button>
                </div>

                <div
                    class="kc-nav-content"
                    id="kc-nav-content"
                    role="tabpanel"
                    tabindex="0"
                >
                    ${this.renderActiveContent()}
                </div>
            `;

      this.restoreTabFocus();
    }

    renderActiveContent() {
      switch (this.activeTab) {
        case 'navigator':
          return this.renderNavigator();

        case 'patterns':
          return this.renderPatterns();

        case 'components':
        default:
          return this.renderComponents();
      }
    }

    renderComponents() {
      return `
                <div
                    class="kc-nav-panel"
                    aria-label="Components"
                >
                    <div class="kc-nav-empty">
                        Component library is managed by the editor catalog.
                    </div>
                </div>
            `;
    }

    renderPatterns() {
      return `
                <div
                    class="kc-nav-panel"
                    aria-label="Patterns"
                >
                    <div class="kc-nav-empty">
                        Patterns are managed by the editor configuration.
                    </div>
                </div>
            `;
    }

    renderNavigator() {
      const headings = this.getEditorHeadings();

      if (!headings.length) {
        return `
                    <div
                        class="kc-nav-panel"
                        aria-label="Navigator"
                    >
                        <div class="kc-nav-empty">
                            No headings found in the document.
                        </div>
                    </div>
                `;
      }

      const tree = this.buildHeadingTree(headings);

      return `
                <div
                    class="kc-nav-panel kc-navigator-panel"
                    aria-label="Document Navigator"
                >
                    <div class="kc-navigator-head">
                        <span class="kc-navigator-title">
                            Document
                        </span>

                        <span class="kc-navigator-count">
                            ${headings.length}
                        </span>
                    </div>

                    <div
                        class="kc-navigator-tree"
                        role="tree"
                        aria-label="Document headings"
                    >
                        ${this.renderHeadingNodes(tree)}
                    </div>
                </div>
            `;
    }

    getEditorHeadings() {
      const canvas = document.getElementById('kc-editorjs');

      if (!canvas) {
        return [];
      }

      const headingElements = canvas.querySelectorAll(
        'h1, h2, h3, h4, h5, h6'
      );

      const headings = [];

      headingElements.forEach((heading, index) => {
        const text = (heading.textContent || '').trim();

        if (!text) {
          return;
        }

        const level = Number(
          heading.tagName.substring(1)
        );

        const holder =
          heading.closest('.ce-block') ||
          heading.closest('[data-id]') ||
          heading.parentElement;

        if (!holder) {
          return;
        }

        let blockIndex = -1;

        const runtime = global.KcEditorRuntime;

        if (
          runtime &&
          runtime.instance &&
          runtime.instance.blocks &&
          typeof runtime.instance.blocks.getBlocksCount ===
          'function'
        ) {
          const blocks = runtime.instance.blocks;
          const count = blocks.getBlocksCount();

          for (let i = 0; i < count; i++) {
            const block = blocks.getBlockByIndex(i);

            if (!block || !block.holder) {
              continue;
            }

            if (
              block.holder === holder ||
              block.holder.contains(holder) ||
              holder.contains(block.holder)
            ) {
              blockIndex = i;
              break;
            }
          }
        }

        headings.push({
          id: `kc-nav-heading-${index}`,
          element: heading,
          holder: holder,
          text: text,
          level: level,
          blockIndex: blockIndex
        });
      });

      return headings;
    }

    buildHeadingTree(headings) {
      const root = [];
      const stack = [];

      headings.forEach((heading) => {
        const node = {
          heading: heading,
          children: []
        };

        while (
          stack.length &&
          stack[stack.length - 1].heading.level >=
          heading.level
        ) {
          stack.pop();
        }

        if (!stack.length) {
          root.push(node);
        } else {
          stack[stack.length - 1].children.push(node);
        }

        stack.push(node);
      });

      return root;
    }

    renderHeadingNodes(nodes) {
      return nodes
        .map((node) => {
          const heading = node.heading;

          return `
                        <div
                            class="kc-navigator-node"
                            role="treeitem"
                            aria-level="${heading.level}"
                        >
                            <button
                                type="button"
                                class="kc-navigator-item"
                                data-navigator-heading="${this.escapeAttribute(
            heading.id
          )}"
                                aria-label="Go to ${this.escapeAttribute(
            heading.text
          )}"
                            >
                                <span
                                    class="kc-navigator-marker"
                                    aria-hidden="true"
                                ></span>

                                <span class="kc-navigator-text">
                                    ${this.escapeHtml(heading.text)}
                                </span>
                            </button>

                            ${node.children.length
              ? `
                                        <div
                                            class="kc-navigator-children"
                                            role="group"
                                        >
                                            ${this.renderHeadingNodes(
                node.children
              )}
                                        </div>
                                    `
              : ''
            }
                        </div>
                    `;
        })
        .join('');
    }

    bindEvents() {
      if (this.boundClickHandler) {
        this.host.removeEventListener(
          'click',
          this.boundClickHandler
        );
      }

      this.boundClickHandler = (e) => {
        const tabBtn =
          e.target.closest('.kc-nav-tab');

        if (
          tabBtn &&
          tabBtn.dataset.nav &&
          this.host.contains(tabBtn)
        ) {
          this.switchTab(tabBtn.dataset.nav);
          return;
        }

        const navigatorItem =
          e.target.closest(
            '[data-navigator-heading]'
          );

        if (
          navigatorItem &&
          this.host.contains(navigatorItem)
        ) {
          const headingId =
            navigatorItem.dataset.navigatorHeading;

          this.navigateToHeading(headingId);
        }
      };

      this.host.addEventListener(
        'click',
        this.boundClickHandler
      );

      if (this.boundKeydownHandler) {
        this.host.removeEventListener(
          'keydown',
          this.boundKeydownHandler
        );
      }

      this.boundKeydownHandler = (e) => {
        const tab =
          e.target.closest('.kc-nav-tab');

        if (!tab) {
          return;
        }

        const tabs = Array.from(
          this.host.querySelectorAll(
            '.kc-nav-tab'
          )
        );

        const currentIndex =
          tabs.indexOf(tab);

        if (e.key === 'ArrowRight') {
          e.preventDefault();

          const next =
            tabs[
            (currentIndex + 1) %
            tabs.length
            ];

          if (next) {
            next.focus();
            this.switchTab(next.dataset.nav);
          }
        }

        if (e.key === 'ArrowLeft') {
          e.preventDefault();

          const previous =
            tabs[
            (currentIndex - 1 +
              tabs.length) %
            tabs.length
            ];

          if (previous) {
            previous.focus();
            this.switchTab(
              previous.dataset.nav
            );
          }
        }
      };

      this.host.addEventListener(
        'keydown',
        this.boundKeydownHandler
      );
    }

    switchTab(tabName) {
      if (
        ![
          'components',
          'navigator',
          'patterns'
        ].includes(tabName)
      ) {
        return;
      }

      this.activeTab = tabName;
      this.render();

      if (tabName === 'navigator') {
        this.refreshNavigator();
      }
    }

    navigateToHeading(headingId) {
      const headings =
        this.getEditorHeadings();

      const target = headings.find(
        (heading) =>
          heading.id === headingId
      );

      if (!target || !target.element) {
        return;
      }

      const holder =
        target.holder ||
        target.element.closest('.ce-block') ||
        target.element;

      /*
       * Scroll the actual editor block into view.
       */
      holder.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest'
      });

      /*
       * Keep focus in the Navigator button rather than
       * moving focus into the editor and disturbing the
       * Editor.js caret.
       */
      const navigatorButton =
        this.host.querySelector(
          `[data-navigator-heading="${this.escapeSelector(
            headingId
          )}"]`
        );

      if (navigatorButton) {
        navigatorButton.focus({
          preventScroll: true
        });
      }

      this.highlightBlock(holder);
    }

    highlightBlock(holder) {
      if (!holder) {
        return;
      }

      holder.classList.add(
        'kc-navigator-highlight'
      );

      window.setTimeout(() => {
        holder.classList.remove(
          'kc-navigator-highlight'
        );
      }, 1200);
    }

    observeEditor() {
      const canvas =
        document.getElementById('kc-editorjs');

      if (!canvas || typeof MutationObserver === 'undefined') {
        return;
      }

      if (this.boundEditorObserver) {
        this.boundEditorObserver.disconnect();
      }

      this.boundEditorObserver =
        new MutationObserver(() => {
          if (
            this.activeTab !==
            'navigator'
          ) {
            return;
          }

          window.clearTimeout(
            this.refreshTimer
          );

          this.refreshTimer =
            window.setTimeout(() => {
              this.refreshNavigator();
            }, 100);
        });

      this.boundEditorObserver.observe(
        canvas,
        {
          childList: true,
          subtree: true,
          characterData: true
        }
      );
    }

    refreshNavigator() {
      if (this.activeTab !== 'navigator') {
        return;
      }

      const content =
        this.host.querySelector(
          '#kc-nav-content'
        );

      if (!content) {
        return;
      }

      const activeElement =
        document.activeElement;

      const activeHeadingId =
        activeElement &&
          activeElement.dataset
          ? activeElement.dataset
            .navigatorHeading
          : null;

      content.innerHTML =
        this.renderNavigator();

      if (activeHeadingId) {
        const replacement =
          this.host.querySelector(
            `[data-navigator-heading="${this.escapeSelector(
              activeHeadingId
            )}"]`
          );

        if (replacement) {
          replacement.focus({
            preventScroll: true
          });
        }
      }
    }

    restoreTabFocus() {
      const activeTab =
        this.host.querySelector(
          `.kc-nav-tab[data-nav="${this.escapeSelector(
            this.activeTab
          )}"]`
        );

      if (activeTab) {
        activeTab.setAttribute(
          'aria-selected',
          'true'
        );
      }
    }

    injectStyles() {
      const styleId =
        'kc-navigator-shell-styles';

      if (document.getElementById(styleId)) {
        return;
      }

      const style =
        document.createElement('style');

      style.id = styleId;

      style.textContent = `
                .kc-nav-tabs {
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    border-bottom: 1px solid var(--soi-border);
                }

                .kc-nav-tab {
                    appearance: none;
                    border: 0;
                    background: transparent;
                    color: inherit;
                    font-family: Inter, sans-serif;
                    font-size: 13px;
                    font-weight: 600;
                    line-height: 1.4;
                    padding: 9px 11px;
                    cursor: pointer;
                    border-radius: var(--soi-radius);
                }

                .kc-nav-tab:hover {
                    background: var(--soi-surface);
                }

                .kc-nav-tab.is-active {
                    color: var(--brand);
                }

                .kc-nav-tab:focus-visible,
                .kc-navigator-item:focus-visible {
                    outline: 2px solid var(--brand);
                    outline-offset: 2px;
                }

                .kc-nav-content {
                    font-family: Inter, sans-serif;
                    min-height: 0;
                }

                .kc-nav-panel {
                    padding: 10px;
                }

                .kc-nav-empty {
                    color: inherit;
                    opacity: 0.65;
                    font-family: Inter, sans-serif;
                    font-size: 13px;
                    line-height: 1.5;
                    padding: 14px 8px;
                }

                .kc-navigator-head {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 8px;
                    padding: 4px 6px 10px;
                    border-bottom: 1px solid var(--soi-border);
                }

                .kc-navigator-title {
                    font-size: 12px;
                    font-weight: 700;
                }

                .kc-navigator-count {
                    color: var(--brand);
                    font-size: 11px;
                    font-weight: 700;
                }

                .kc-navigator-tree {
                    padding-top: 6px;
                }

                .kc-navigator-node {
                    min-width: 0;
                }

                .kc-navigator-item {
                    width: 100%;
                    display: flex;
                    align-items: center;
                    gap: 7px;
                    min-width: 0;
                    border: 0;
                    background: transparent;
                    color: inherit;
                    font-family: Inter, sans-serif;
                    font-size: 13px;
                    line-height: 1.4;
                    text-align: left;
                    padding: 6px 7px;
                    border-radius: var(--soi-radius);
                    cursor: pointer;
                }

                .kc-navigator-item:hover {
                    background: var(--soi-surface);
                }

                .kc-navigator-marker {
                    width: 6px;
                    height: 6px;
                    flex: 0 0 6px;
                    border: 1px solid var(--soi-border);
                    border-radius: 50%;
                }

                .kc-navigator-text {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }

                .kc-navigator-children {
                    margin-left: 14px;
                    padding-left: 7px;
                    border-left: 1px solid var(--soi-border);
                }

                .kc-navigator-highlight {
                    outline: 2px solid var(--brand) !important;
                    outline-offset: 3px;
                    border-radius: var(--soi-radius);
                    scroll-margin-block: 120px;
                }

                @media (max-width: 980px) {
                    .kc-nav-panel {
                        overflow-y: auto;
                        max-height: 70vh;
                    }
                }

                @media (max-width: 720px) {
                    .kc-nav-tabs {
                        overflow-x: auto;
                    }

                    .kc-nav-tab {
                        flex: 0 0 auto;
                    }

                    .kc-nav-panel {
                        max-height: 65vh;
                    }
                }
            `;

      document.head.appendChild(style);
    }

    escapeHtml(value) {
      return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    escapeAttribute(value) {
      return this.escapeHtml(value);
    }

    escapeSelector(value) {
      if (
        global.CSS &&
        typeof global.CSS.escape ===
        'function'
      ) {
        return global.CSS.escape(
          String(value)
        );
      }

      return String(value).replace(
        /([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g,
        '\\$1'
      );
    }
  }

  global.KcNavigatorShell = NavigatorShell;
})(typeof window !== 'undefined' ? window : this);