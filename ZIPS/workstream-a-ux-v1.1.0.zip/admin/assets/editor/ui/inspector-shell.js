/**
 * SOI Knowledge Center — Contextual Block Inspector Shell
 * Location: admin/assets/editor/ui/inspector-shell.js
 *
 * Implements EUX-11 Contextual Block Inspector Synchronization.
 * Dynamically binds property inspection and live two-way synchronization
 * for active canvas blocks (Heading, Callout, Image, Columns, Code, ApiEndpoint).
 */
(function (global) {
  'use strict';

  class InspectorShell {
    constructor(hostEl) {
      this.host = typeof hostEl === 'string' ? document.getElementById(hostEl) : hostEl;
      this.container = null;
      this.titleEl = null;
      this.metaEl = null;
      this.activeBlock = null;
      this.selectedBlock = null;

      this.init();
    }

    init() {
      this.resolveDOMElements();
      this.render();
      this.bindEvents();
    }

    resolveDOMElements() {
      this.container = document.getElementById('kc-inspector-content') || document.getElementById('kc-block-fields');
      this.titleEl = document.getElementById('kc-inspector-title');
      this.metaEl = document.getElementById('kc-selected-meta');
    }

    sanitizeText(str) {
      if (typeof str !== 'string') return '';
      const temp = document.createElement('div');
      temp.textContent = str;
      return temp.innerHTML;
    }

    bindEvents() {
      // Listen for window.KcEditorRuntime event
      if (global.KcEditorRuntime && typeof global.KcEditorRuntime.on === 'function') {
        global.KcEditorRuntime.on('selectionChange', (block) => {
          this.setBlock(block);
        });
      }

      // Interoperability with custom DOM events
      if (typeof document !== 'undefined') {
        document.addEventListener('kc:selectionChange', (e) => {
          if (e.detail !== undefined) {
            this.setBlock(e.detail);
          }
        });
        document.addEventListener('kc:block-selected', (e) => {
          if (e.detail && e.detail.block !== undefined) {
            this.setBlock(e.detail.block);
          }
        });

        // Canvas background click clears selection
        const canvas = document.getElementById('kc-canvas');
        if (canvas) {
          canvas.addEventListener('click', (e) => {
            if (e.target.id === 'kc-canvas' || e.target.classList.contains('kc-doc-stage') || e.target.classList.contains('kc-doc-surface')) {
              if (!e.target.closest('.ce-block')) {
                this.setBlock(null);
              }
            }
          });
        }
      }
    }

    /**
     * Sets active block and triggers UI update
     * @param {Object|null} block - { index, type, id, data, block, holder }
     */
    setBlock(block) {
      this.activeBlock = block;
      this.selectedBlock = block;
      this.resolveDOMElements();
      this.render();
    }

    /**
     * Notify editor runtime and DOM of canvas changes
     */
    notifyDirty() {
      if (global.KcEditorRuntime && typeof global.KcEditorRuntime.emit === 'function') {
        global.KcEditorRuntime.emit('documentChange', { block: this.activeBlock });
      }
      if (typeof window !== 'undefined' && typeof window.__kcMarkDirty === 'function') {
        window.__kcMarkDirty();
      } else {
        const docForm = document.getElementById('kc-editor');
        if (docForm) {
          docForm.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    }

    /**
     * Render the Inspector view (empty state or active block controls)
     */
    render() {
      if (!this.container) {
        this.resolveDOMElements();
        if (!this.container) return;
      }

      if (!this.activeBlock) {
        if (this.titleEl) {
          this.titleEl.textContent = 'DOCUMENT SETTINGS';
        }
        if (this.metaEl) {
          this.metaEl.textContent = 'Select a block on the canvas to configure properties.';
          this.metaEl.style.display = 'block';
        }
        this.container.innerHTML = '<p class="kc-empty-hint">Select a block on the canvas to configure properties.</p>';
        return;
      }

      const type = (this.activeBlock.type || this.activeBlock.name || 'block').toLowerCase();
      const typeLabel = type.toUpperCase();

      if (this.titleEl) {
        this.titleEl.textContent = `BLOCK: ${typeLabel}`;
      }
      if (this.metaEl) {
        this.metaEl.textContent = `Active Block: ${typeLabel} (ID: ${this.activeBlock.id || 'new'})`;
        this.metaEl.style.display = 'block';
      }

      this.renderBlockControls();
    }

    /**
     * Render block-specific controls for the active block
     */
    renderBlockControls() {
      const block = this.activeBlock;
      const type = (block.type || block.name || 'block').toLowerCase();
      const data = block.data || {};
      const holder = block.holder || (block.block ? block.block.holder : null);

      let html = '';

      if (type === 'header' || type === 'heading') {
        const curLevel = data.level || (holder ? this.detectHeadingLevel(holder) : 2);
        const curAnchor = data.anchor || (holder ? (holder.querySelector('h1,h2,h3,h4,h5,h6')?.id || '') : '');

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-hlevel">Heading Level</label>
              <select class="kc-tool-select" id="kc-insp-hlevel">
                <option value="1" ${curLevel === 1 ? 'selected' : ''}>H1 — Main Title</option>
                <option value="2" ${curLevel === 2 ? 'selected' : ''}>H2 — Section Header</option>
                <option value="3" ${curLevel === 3 ? 'selected' : ''}>H3 — Subsection Header</option>
                <option value="4" ${curLevel === 4 ? 'selected' : ''}>H4 — Minor Header</option>
                <option value="5" ${curLevel === 5 ? 'selected' : ''}>H5 — Micro Header</option>
                <option value="6" ${curLevel === 6 ? 'selected' : ''}>H6 — Smallest Header</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-anchor">Anchor ID (slug)</label>
              <input type="text" class="kc-tool-input" id="kc-insp-anchor" value="${this.sanitizeText(curAnchor)}" placeholder="e.g. section-overview">
              <small class="kc-field-hint">Deep-link anchor for table of contents.</small>
            </div>
          </div>
        `;
      } else if (type === 'callout') {
        const curTone = data.tone || (holder ? (holder.querySelector('.kc-tool-callout')?.dataset.tone || 'info') : 'info');
        const curTitle = data.title || (holder ? (holder.querySelector('.kc-tool-title')?.value || '') : '');

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-tone">Callout Tone</label>
              <select class="kc-tool-select" id="kc-insp-tone">
                <option value="info" ${curTone === 'info' ? 'selected' : ''}>ℹ️ Info (Blue)</option>
                <option value="note" ${curTone === 'note' ? 'selected' : ''}>📝 Note (Gray)</option>
                <option value="tip" ${curTone === 'tip' ? 'selected' : ''}>💡 Tip (Teal)</option>
                <option value="warning" ${curTone === 'warning' ? 'selected' : ''}>⚠️ Warning (Amber)</option>
                <option value="danger" ${curTone === 'danger' ? 'selected' : ''}>⛔ Danger (Red)</option>
                <option value="success" ${curTone === 'success' ? 'selected' : ''}>✓ Success (Green)</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-callout-title">Callout Title</label>
              <input type="text" class="kc-tool-input" id="kc-insp-callout-title" value="${this.sanitizeText(curTitle)}" placeholder="Optional header...">
            </div>
          </div>
        `;
      } else if (type === 'image') {
        const curCap = data.caption || '';
        const curAlt = data.alt || '';
        const curWidth = data.width || 'full';
        const curAlign = data.alignment || data.align || 'center';

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-caption">Caption</label>
              <input type="text" class="kc-tool-input" id="kc-insp-img-caption" value="${this.sanitizeText(curCap)}" placeholder="Image caption...">
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-alt">Alt Text</label>
              <input type="text" class="kc-tool-input" id="kc-insp-img-alt" value="${this.sanitizeText(curAlt)}" placeholder="Descriptive alternative text...">
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-width">Width</label>
              <select class="kc-tool-select" id="kc-insp-img-width">
                <option value="auto" ${curWidth === 'auto' ? 'selected' : ''}>Natural (Auto)</option>
                <option value="half" ${curWidth === 'half' || curWidth === '50%' ? 'selected' : ''}>50% Width</option>
                <option value="full" ${curWidth === 'full' || curWidth === '100%' ? 'selected' : ''}>100% Full Width</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-align">Alignment</label>
              <select class="kc-tool-select" id="kc-insp-img-align">
                <option value="left" ${curAlign === 'left' ? 'selected' : ''}>Left</option>
                <option value="center" ${curAlign === 'center' ? 'selected' : ''}>Center</option>
                <option value="right" ${curAlign === 'right' ? 'selected' : ''}>Right</option>
              </select>
            </div>
          </div>
        `;
      } else if (type === 'columns') {
        const curLayout = data.layout || '50-50';

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-col-ratio">Column Split Ratio</label>
              <select class="kc-tool-select" id="kc-insp-col-ratio">
                <option value="50-50" ${curLayout === '50-50' ? 'selected' : ''}>50% / 50% (Equal)</option>
                <option value="33-67" ${curLayout === '33-67' ? 'selected' : ''}>33% / 67% (Narrow / Wide)</option>
                <option value="67-33" ${curLayout === '67-33' ? 'selected' : ''}>67% / 33% (Wide / Narrow)</option>
                <option value="33-33-33" ${curLayout === '33-33-33' ? 'selected' : ''}>33% / 33% / 33% (3 Columns)</option>
              </select>
            </div>
          </div>
        `;
      } else if (type === 'code') {
        const curLang = data.language || 'javascript';
        const curLines = data.showLineNumbers !== false;

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-code-lang">Programming Language</label>
              <select class="kc-tool-select" id="kc-insp-code-lang">
                <option value="javascript" ${curLang === 'javascript' ? 'selected' : ''}>JavaScript / TypeScript</option>
                <option value="php" ${curLang === 'php' ? 'selected' : ''}>PHP</option>
                <option value="python" ${curLang === 'python' ? 'selected' : ''}>Python</option>
                <option value="html" ${curLang === 'html' ? 'selected' : ''}>HTML</option>
                <option value="css" ${curLang === 'css' ? 'selected' : ''}>CSS</option>
                <option value="json" ${curLang === 'json' ? 'selected' : ''}>JSON</option>
                <option value="bash" ${curLang === 'bash' || curLang === 'sh' ? 'selected' : ''}>Bash / Shell</option>
                <option value="sql" ${curLang === 'sql' ? 'selected' : ''}>SQL</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-checkbox-label">
                <input type="checkbox" id="kc-insp-code-lines" ${curLines ? 'checked' : ''}>
                <span>Display Line Numbers</span>
              </label>
            </div>
          </div>
        `;
      } else if (type === 'apiendpoint' || type === 'api-endpoint') {
        const curMethod = data.method || 'GET';
        const curEndpoint = data.endpoint || '';

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-api-method">HTTP Method</label>
              <select class="kc-tool-select" id="kc-insp-api-method">
                <option value="GET" ${curMethod === 'GET' ? 'selected' : ''}>GET</option>
                <option value="POST" ${curMethod === 'POST' ? 'selected' : ''}>POST</option>
                <option value="PUT" ${curMethod === 'PUT' ? 'selected' : ''}>PUT</option>
                <option value="PATCH" ${curMethod === 'PATCH' ? 'selected' : ''}>PATCH</option>
                <option value="DELETE" ${curMethod === 'DELETE' ? 'selected' : ''}>DELETE</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-api-endpoint">Endpoint Path</label>
              <input type="text" class="kc-tool-input" id="kc-insp-api-endpoint" value="${this.sanitizeText(curEndpoint)}" placeholder="/api/v1/resource">
            </div>
          </div>
        `;
        html = `
          <div class="kc-inspector-section">
            <p class="kc-empty-hint">Standard block properties active for <strong>${this.sanitizeText(type.toUpperCase())}</strong>.</p>
          </div>
        `;
      }

      this.container.innerHTML = html;
      this.attachControlListeners(block, holder);
    }

    detectHeadingLevel(holder) {
      if (!holder) return 2;
      const h = holder.querySelector('h1,h2,h3,h4,h5,h6');
      if (h) {
        const lvl = parseInt(h.tagName.substring(1), 10);
        return isNaN(lvl) ? 2 : lvl;
      }
      return 2;
    }

    attachControlListeners(block, holder) {
      // 1. Heading Controls
      const hLevelSel = document.getElementById('kc-insp-hlevel');
      if (hLevelSel) {
        hLevelSel.addEventListener('change', () => {
          const newLevel = parseInt(hLevelSel.value, 10);
          block.data = block.data || {};
          block.data.level = newLevel;

          if (holder) {
            const hTag = holder.querySelector('h1,h2,h3,h4,h5,h6,[contenteditable]');
            if (hTag) {
              const targetTag = 'H' + newLevel;
              if (hTag.tagName !== targetTag) {
                const newEl = document.createElement(targetTag);
                newEl.contentEditable = hTag.contentEditable || 'true';
                newEl.className = hTag.className;
                newEl.innerHTML = hTag.innerHTML;
                if (hTag.id) newEl.id = hTag.id;
                hTag.parentNode.replaceChild(newEl, hTag);
              }
            }
          }
          this.notifyDirty();
        });
      }

      const hAnchorInput = document.getElementById('kc-insp-anchor');
      if (hAnchorInput) {
        hAnchorInput.addEventListener('input', () => {
          const anchor = hAnchorInput.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-');
          block.data = block.data || {};
          block.data.anchor = anchor;

          if (holder) {
            const hTag = holder.querySelector('h1,h2,h3,h4,h5,h6,[contenteditable]');
            if (hTag) {
              if (anchor) {
                hTag.id = anchor;
                hTag.setAttribute('data-anchor', anchor);
              } else {
                hTag.removeAttribute('id');
                hTag.removeAttribute('data-anchor');
              }
            }
          }
          this.notifyDirty();
        });
      }

      // 2. Callout Controls
      const toneSel = document.getElementById('kc-insp-tone');
      if (toneSel) {
        toneSel.addEventListener('change', () => {
          const newTone = toneSel.value;
          block.data = block.data || {};
          block.data.tone = newTone;

          if (holder) {
            const wrap = holder.querySelector('.kc-tool-callout') || holder;
            wrap.className = wrap.className.replace(/\bkc-callout-[a-z]+\b/g, '').trim();
            wrap.classList.add('kc-callout-' + newTone);
            wrap.dataset.tone = newTone;

            const inlineSelect = holder.querySelector('.kc-tool-tone');
            if (inlineSelect) inlineSelect.value = newTone;

            const badge = holder.querySelector('.kc-callout-badge-icon');
            if (badge) {
              const icons = { info: 'ℹ', note: '📝', tip: '💡', warning: '⚠️', danger: '⛔', success: '✓' };
              badge.textContent = icons[newTone] || 'ℹ';
            }
          }
          this.notifyDirty();
        });
      }

      const calloutTitleInput = document.getElementById('kc-insp-callout-title');
      if (calloutTitleInput) {
        calloutTitleInput.addEventListener('input', () => {
          const val = calloutTitleInput.value;
          block.data = block.data || {};
          block.data.title = val;

          if (holder) {
            const titleField = holder.querySelector('.kc-tool-title');
            if (titleField && titleField.value !== val) {
              titleField.value = val;
            }
          }
          this.notifyDirty();
        });
      }

      // 3. Image Controls
      const imgCaption = document.getElementById('kc-insp-img-caption');
      if (imgCaption) {
        imgCaption.addEventListener('input', () => {
          const val = imgCaption.value;
          block.data = block.data || {};
          block.data.caption = val;

          if (holder) {
            const cap = holder.querySelector('.kc-image-caption-input') || holder.querySelector('figcaption');
            if (cap) {
              if ('value' in cap) cap.value = val;
              else cap.textContent = val;
            }
          }
          this.notifyDirty();
        });
      }

      const imgAlt = document.getElementById('kc-insp-img-alt');
      if (imgAlt) {
        imgAlt.addEventListener('input', () => {
          const val = imgAlt.value;
          block.data = block.data || {};
          block.data.alt = val;

          if (holder) {
            const alt = holder.querySelector('.kc-image-alt-input') || holder.querySelector('img');
            if (alt) {
              if ('value' in alt) alt.value = val;
              else alt.alt = val;
            }
          }
          this.notifyDirty();
        });
      }

      const imgWidth = document.getElementById('kc-insp-img-width');
      if (imgWidth) {
        imgWidth.addEventListener('change', () => {
          const val = imgWidth.value;
          block.data = block.data || {};
          block.data.width = val;

          if (holder) {
            const card = holder.querySelector('.kc-image-card') || holder.querySelector('.kc-tool-image') || holder;
            card.className = card.className.replace(/\bkc-image-width-[a-z0-9%]+\b/g, '').trim();
            card.classList.add('kc-image-width-' + val);
            card.dataset.width = val;
          }
          this.notifyDirty();
        });
      }

      const imgAlign = document.getElementById('kc-insp-img-align');
      if (imgAlign) {
        imgAlign.addEventListener('change', () => {
          const val = imgAlign.value;
          block.data = block.data || {};
          block.data.alignment = val;
          block.data.align = val;

          if (holder) {
            const card = holder.querySelector('.kc-image-card') || holder.querySelector('.kc-tool-image') || holder;
            card.className = card.className.replace(/\bkc-image-align-[a-z]+\b/g, '').trim();
            card.classList.add('kc-image-align-' + val);
            card.dataset.align = val;
          }
          this.notifyDirty();
        });
      }

      // 4. Columns Controls
      const colRatio = document.getElementById('kc-insp-col-ratio');
      if (colRatio) {
        colRatio.addEventListener('change', () => {
          const val = colRatio.value;
          block.data = block.data || {};
          block.data.layout = val;

          if (holder) {
            const wrap = holder.querySelector('.kc-tool-columns') || holder;
            wrap.dataset.layout = val;

            const inlineSelect = holder.querySelector('.kc-columns-select') || holder.querySelector('select');
            if (inlineSelect) inlineSelect.value = val;
          }
          this.notifyDirty();
        });
      }

      // 5. Code Controls
      const codeLang = document.getElementById('kc-insp-code-lang');
      if (codeLang) {
        codeLang.addEventListener('change', () => {
          const val = codeLang.value;
          block.data = block.data || {};
          block.data.language = val;

          if (holder) {
            const inlineSelect = holder.querySelector('.kc-code-lang-select') || holder.querySelector('select');
            if (inlineSelect) inlineSelect.value = val;
          }
          this.notifyDirty();
        });
      }

      const codeLines = document.getElementById('kc-insp-code-lines');
      if (codeLines) {
        codeLines.addEventListener('change', () => {
          const checked = !!codeLines.checked;
          block.data = block.data || {};
          block.data.showLineNumbers = checked;

          if (holder) {
            const toggle = holder.querySelector('.kc-code-lines-toggle') || holder.querySelector('input[type="checkbox"]');
            if (toggle) toggle.checked = checked;

            const gutter = holder.querySelector('.kc-code-gutter');
            if (gutter) gutter.style.display = checked ? '' : 'none';
          }
          this.notifyDirty();
        });
      }

      // 6. API Endpoint Controls
      const apiMethod = document.getElementById('kc-insp-api-method');
      if (apiMethod) {
        apiMethod.addEventListener('change', () => {
          const val = apiMethod.value;
          block.data = block.data || {};
          block.data.method = val;

          if (holder) {
            const methodTag = holder.querySelector('.kc-api-method-badge') || holder.querySelector('.kc-api-method');
            if (methodTag) {
              methodTag.textContent = val;
              methodTag.className = methodTag.className.replace(/\bkc-api-method-[A-Z]+\b/g, '').trim();
              methodTag.classList.add('kc-api-method-' + val);
            }
          }
          this.notifyDirty();
        });
      }

      const apiEndpoint = document.getElementById('kc-insp-api-endpoint');
      if (apiEndpoint) {
        apiEndpoint.addEventListener('input', () => {
          const val = apiEndpoint.value;
          block.data = block.data || {};
          block.data.endpoint = val;

          if (holder) {
            const epField = holder.querySelector('.kc-api-path') || holder.querySelector('.kc-api-endpoint-input');
            if (epField && ('value' in epField ? epField.value !== val : epField.textContent !== val)) {
              if ('value' in epField) epField.value = val;
              else epField.textContent = val;
            }
          }
          this.notifyDirty();
        });
      }
    }
  }

  // Self-register upon DOM ready
  let inspectorInstance = null;
  function bootstrapInspector() {
    if (!inspectorInstance) {
      inspectorInstance = new InspectorShell('kc-right-pane');
    }
    global.KCInspector = inspectorInstance;
    global.InspectorShell = InspectorShell;
    global.KcInspectorShell = InspectorShell;
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bootstrapInspector);
    } else {
      bootstrapInspector();
    }
  }

  global.KcInspectorShell = InspectorShell;
  global.InspectorShell = InspectorShell;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { InspectorShell };
  }
})(typeof window !== 'undefined' ? window : this);
