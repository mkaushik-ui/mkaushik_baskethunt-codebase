class DividerBlock {
  static get toolbox() {
    return {
      title: 'Divider',
      icon: '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><line x1="4" y1="12" x2="20" y2="12"></line></svg>'
    };
  }

  static get isReadOnlySupported() {
    return true;
  }

  constructor({ data, config, api, readOnly }) {
    this.api = api;
  }

  render() {
    const wrapper = document.createElement('div');
    // Using native Editor.js block class ensures it selects and behaves properly
    if (this.api && this.api.styles) {
      wrapper.classList.add(this.api.styles.block);
    }
    wrapper.classList.add('kc-divider-tool');
    
    wrapper.innerHTML = '<hr class="kc-divider-line">';
    return wrapper;
  }

  save(blockContent) {
    return {}; // Output is strictly { type: 'divider', data: {} }
  }
}

if (typeof window !== 'undefined') {
  window.DividerBlock = DividerBlock;
  if (window.KcEditorRegistry && typeof window.KcEditorRegistry.register === 'function') {
    window.KcEditorRegistry.register('divider', DividerBlock, { label: 'Divider', group: 'basic' });
    window.KcEditorRegistry.register('delimiter', DividerBlock, { label: 'Divider', group: 'basic' });
  }
}
