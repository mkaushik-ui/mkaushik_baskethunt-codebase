<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\BlockType;
use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T12: Numbered Steps Block
 * 
 * Procedural how-to instruction steps component with step title,
 * description, and connector timeline styling.
 * 
 * @author Saurabh
 */
final class StepsBlock extends AbstractBlock implements BlockType
{
    public function type(): string
    {
        return 'steps';
    }

    public function label(): string
    {
        return 'Steps';
    }

    /**
     * Sanitize stored data payload.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{title:string, content:string}>}
     */
    public function sanitize(array $data): array
    {
        return ['items' => self::sanitizeItems($data['items'] ?? [])];
    }

    /**
     * Validate block data constraints.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > 50) {
            return ['Steps cannot contain more than 50 items.'];
        }
        return [];
    }

    /**
     * Render semantic HTML output with connector timeline items.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(is_array($block['data'] ?? null) ? $block['data'] : []);
        $items = $data['items'];
        if ($items === []) {
            return '';
        }

        $id = isset($block['id']) ? Html::escape((string) $block['id']) : '';
        $dataAttr = $id !== '' ? ' data-block-id="' . $id . '"' : '';

        $html = '<ol class="kc-block kc-block-steps"' . $dataAttr . '>';
        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = (string) ($item['title'] ?? '');
            $content = (string) ($item['content'] ?? '');

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $html .= '<li class="kc-steps-item">';
            $html .= '<div class="kc-steps-index" aria-hidden="true">' . (int) ($i + 1) . '</div>';
            $html .= '<div class="kc-steps-body">';

            if ($title !== '') {
                $html .= '<div class="kc-steps-title">' . Html::escape($title) . '</div>';
            }

            if (Html::plainText($content) !== '') {
                $html .= '<div class="kc-steps-content">' . $content . '</div>';
            }

            $html .= '</div></li>';
        }
        $html .= '</ol>';

        return $html;
    }

    /**
     * @param mixed $items
     * @return list<array{title:string,content:string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = Html::plainText(Html::clampText((string) ($item['title'] ?? ''), 300));
            $content = Html::sanitizeInline((string) ($item['content'] ?? ''), 20000);

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $out[] = [
                'title' => $title,
                'content' => $content,
            ];

            if (count($out) >= 50) {
                break;
            }
        }

        return $out;
    }
}
