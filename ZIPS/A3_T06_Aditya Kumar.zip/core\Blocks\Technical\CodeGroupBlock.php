<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T06: Multi-Language Code Group renderer and sanitizer.
 * Tabbed code group block allowing developers to provide cURL, PHP, JavaScript, and Python tabs in a single component.
 * Acceptance Criteria: Renders tabbed interface. Clicking tab switches visible code block snippet.
 */
class CodeGroupBlock extends AbstractBlock
{
    private const MAX_SNIPPETS = 12;

    public function type(): string
    {
        return 'codeGroup';
    }

    public function label(): string
    {
        return 'Code Group';
    }

    public function sanitize(array $data): array
    {
        return ['items' => self::sanitizeItems($data['items'] ?? [])];
    }

    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_SNIPPETS) {
            return ['Code group cannot contain more than 12 snippets.'];
        }
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if ($items === []) {
            return '';
        }

        $id = Html::escape($block['id'] ?? 'cg-' . uniqid());
        $html = '<div class="kc-block kc-block-codegroup" data-block-id="' . $id . '">';
        
        // Tab Navigation Header
        $html .= '<div class="kc-codegroup-tabs" role="tablist" aria-label="Code languages">';
        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = Html::plainText((string) ($item['label'] ?? $item['language'] ?? ''));
            if ($label === '') {
                $label = 'Code ' . ($i + 1);
            }
            $tabId = $id . '-ctab-' . $i;
            $panelId = $id . '-cpanel-' . $i;
            $isActive = $i === 0;

            $html .= '<button type="button" class="kc-codegroup-tab' . ($isActive ? ' is-active' : '') . '" role="tab" id="' . $tabId . '" aria-controls="' . $panelId . '" aria-selected="' . ($isActive ? 'true' : 'false') . '" data-kc-tab="' . $i . '">' . Html::escape($label) . '</button>';
        }
        $html .= '</div>';

        // Tab Panels
        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = Html::plainText((string) ($item['label'] ?? $item['language'] ?? 'code'));
            $code = (string) ($item['code'] ?? '');
            $caption = Html::plainText((string) ($item['caption'] ?? ''));
            $tabId = $id . '-ctab-' . $i;
            $panelId = $id . '-cpanel-' . $i;
            $isActive = $i === 0;

            $html .= '<div class="kc-codegroup-panel' . ($isActive ? ' is-active' : '') . '" role="tabpanel" id="' . $panelId . '" aria-labelledby="' . $tabId . '"' . ($isActive ? '' : ' hidden') . ' data-kc-panel="' . $i . '">';
            if ($caption !== '') {
                $html .= '<div class="kc-code-caption">' . Html::escape($caption) . '</div>';
            }
            $langSlug = strtolower(preg_replace('/[^a-z0-9_+-]/i', '', $label)) ?: 'text';
            $html .= '<pre class="kc-codegroup-pre"><code class="kc-code language-' . Html::escape($langSlug) . '" data-language="' . Html::escape($langSlug) . '">' . Html::escape($code) . '</code></pre>';
            $html .= '</div>';
        }

        // Self-contained tab switching click handler
        $html .= '<script>';
        $html .= 'if(!window.kcTabHandlerBound){window.kcTabHandlerBound=true;document.addEventListener("click",function(e){var tab=e.target.closest("[data-kc-tab]");if(!tab)return;var group=tab.closest(".kc-block-codegroup");if(!group)return;var idx=tab.getAttribute("data-kc-tab");group.querySelectorAll("[data-kc-tab]").forEach(function(t){var isSel=t===tab;t.classList.toggle("is-active",isSel);t.setAttribute("aria-selected",isSel?"true":"false");});group.querySelectorAll("[data-kc-panel]").forEach(function(p){var isTarget=p.getAttribute("data-kc-panel")===idx;p.classList.toggle("is-active",isTarget);p.hidden=!isTarget;});});}';
        $html .= '</script>';

        $html .= '</div>';
        return $html;
    }

    /**
     * @param mixed $items
     * @return list<array{label:string,language:string,code:string,caption:string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }
        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = Html::plainText(Html::clampText((string) ($item['label'] ?? ''), 40));
            $language = Html::plainText(Html::clampText((string) ($item['language'] ?? $label), 40));
            $code = Html::clampText((string) ($item['code'] ?? ''), 100000);
            $caption = Html::plainText(Html::clampText((string) ($item['caption'] ?? ''), 200));

            if ($label === '' && $language === '' && trim($code) === '') {
                continue;
            }
            if ($label === '') {
                $label = $language !== '' ? $language : 'Code';
            }
            $out[] = [
                'label' => $label,
                'language' => $language !== '' ? $language : $label,
                'code' => $code,
                'caption' => $caption,
            ];
            if (count($out) >= self::MAX_SNIPPETS) {
                break;
            }
        }
        return $out;
    }
}
