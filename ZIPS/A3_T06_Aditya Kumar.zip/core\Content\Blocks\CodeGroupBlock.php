<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\CodeGroupBlock as TechnicalCodeGroupBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\CodeGroupBlock
 */
final class CodeGroupBlock extends TechnicalCodeGroupBlock
{
}
