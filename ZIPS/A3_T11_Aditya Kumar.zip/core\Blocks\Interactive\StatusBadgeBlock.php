<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T11: Status Badge Component renderer and sanitizer.
 * Status indicator badge (Stable, Beta, Deprecated, Experimental).
 * Acceptance Criteria: Invalid status text falls back safely to controlled default style.
 */
class StatusBadgeBlock extends AbstractBlock
{
    public const ALLOWED_STATUSES = [
        'stable',
        'beta',
        'deprecated',
        'experimental',
        'internal',
        'recommended',
    ];

    public const DEFAULT_STATUS = 'stable';

    public function type(): string
    {
        return 'statusBadge';
    }

    public function label(): string
    {
        return 'Status Badge';
    }

    public function sanitize(array $data): array
    {
        $rawStatus = strtolower(trim((string) ($data['status'] ?? self::DEFAULT_STATUS)));
        
        // Acceptance Criteria: Invalid status text falls back safely to controlled default style
        $status = in_array($rawStatus, self::ALLOWED_STATUSES, true) ? $rawStatus : self::DEFAULT_STATUS;

        $label = Html::plainText((string) ($data['label'] ?? ''));
        if ($label === '') {
            $label = ucfirst($status);
        }

        return [
            'status' => $status,
            'label' => Html::clampText($label, 40),
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $d = $this->sanitize($block['data'] ?? []);
        $status = $d['status'];
        $label = $d['label'];

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        return '<div class="kc-block kc-block-status"' . $dataAttr . ' style="display: inline-block; font-family: Inter, sans-serif;">'
            . '<span class="kc-badge kc-badge-' . Html::escape($status) . '">' . Html::escape($label) . '</span>'
            . '</div>';
    }
}
