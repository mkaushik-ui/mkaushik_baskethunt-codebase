<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Interactive\StatusBadgeBlock as InteractiveStatusBadgeBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\StatusBadgeBlock
 */
final class StatusBadgeBlock extends InteractiveStatusBadgeBlock
{
}
