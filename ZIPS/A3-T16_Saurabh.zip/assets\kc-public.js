/**
 * Task A3-T16: Public Interactive Micro-Runtime
 * 
 * Ultra-lightweight frontend interaction helper for Knowledge Center blocks.
 * Powers client TabsBlock switching, keyboard navigation (Arrows, Home, End, Enter, Space),
 * ARIA attribute synchronization, and accessible Accordion toggling.
 * 
 * Standalone lightweight public runtime with zero external dependencies.
 * 
 * @author Saurabh
 */
(function (global) {
  'use strict';

  /**
   * Activate tab and corresponding panel within a container root.
   * 
   * @param {HTMLElement} root
   * @param {string|number} index
   */
  function activateTab(root, index) {
    if (!root) return;
    var targetIndex = String(index);

    // 1. Synchronize Tab Buttons
    var tabs = root.querySelectorAll('[role="tab"], [data-kc-tab]');
    for (var i = 0; i < tabs.length; i++) {
      var tab = tabs[i];
      var tabIndex = tab.getAttribute('data-kc-tab');
      if (tabIndex === null) {
        tabIndex = String(i);
      }
      var isActive = (tabIndex === targetIndex);

      tab.classList.toggle('is-active', isActive);
      tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
      tab.tabIndex = isActive ? 0 : -1;
    }

    // 2. Synchronize Tab Panels
    var panels = root.querySelectorAll('[role="tabpanel"], [data-kc-panel]');
    for (var j = 0; j < panels.length; j++) {
      var panel = panels[j];
      var panelIndex = panel.getAttribute('data-kc-panel');
      if (panelIndex === null) {
        panelIndex = String(j);
      }
      var isPanelActive = (panelIndex === targetIndex);

      panel.classList.toggle('is-active', isPanelActive);
      if (isPanelActive) {
        panel.removeAttribute('hidden');
      } else {
        panel.setAttribute('hidden', '');
      }
    }
  }

  // --- Global Click Handler (Delegation) ---
  document.addEventListener('click', function (event) {
    // 1. Tab Button Click
    var tab = event.target.closest('[data-kc-tab], [role="tab"]');
    if (tab) {
      var root = tab.closest('.kc-block-tabs, .kc-block-codegroup, [data-tabs-id]');
      if (root) {
        event.preventDefault();
        var index = tab.getAttribute('data-kc-tab');
        if (index === null) {
          var allTabs = Array.prototype.slice.call(root.querySelectorAll('[role="tab"], [data-kc-tab]'));
          index = allTabs.indexOf(tab);
        }
        activateTab(root, index);
        tab.focus();
        return;
      }
    }

    // 2. Accordion / Details Toggle A11y Sync
    var summary = event.target.closest('summary.kc-accordion-title, summary.kc-faq-question');
    if (summary) {
      var details = summary.closest('details');
      if (details) {
        setTimeout(function () {
          var isOpen = details.hasAttribute('open');
          summary.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        }, 1);
      }
    }
  });

  // --- Global Keyboard Handler (WAI-ARIA Tabs Specification) ---
  document.addEventListener('keydown', function (event) {
    var tab = event.target.closest('[role="tab"], [data-kc-tab]');
    if (!tab) return;

    var root = tab.closest('.kc-block-tabs, .kc-block-codegroup, [data-tabs-id]');
    if (!root) return;

    var tabs = Array.prototype.slice.call(root.querySelectorAll('[role="tab"], [data-kc-tab]'));
    if (!tabs.length) return;

    var currentIndex = tabs.indexOf(tab);
    if (currentIndex === -1) return;

    var key = event.key;
    var targetTab = null;

    if (key === 'ArrowRight' || key === 'ArrowDown') {
      event.preventDefault();
      targetTab = tabs[(currentIndex + 1) % tabs.length];
    } else if (key === 'ArrowLeft' || key === 'ArrowUp') {
      event.preventDefault();
      targetTab = tabs[(currentIndex - 1 + tabs.length) % tabs.length];
    } else if (key === 'Home') {
      event.preventDefault();
      targetTab = tabs[0];
    } else if (key === 'End') {
      event.preventDefault();
      targetTab = tabs[tabs.length - 1];
    } else if (key === 'Enter' || key === ' ') {
      event.preventDefault();
      targetTab = tab;
    }

    if (targetTab) {
      var index = targetTab.getAttribute('data-kc-tab');
      if (index === null) {
        index = tabs.indexOf(targetTab);
      }
      activateTab(root, index);
      targetTab.focus();
    }
  });

  // Export minimal namespace for programmatic initialization if needed
  global.KCPublicRuntime = {
    version: '1.0.0',
    activateTab: activateTab
  };

})(typeof window !== 'undefined' ? window : this);
