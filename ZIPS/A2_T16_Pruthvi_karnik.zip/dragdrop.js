/**
 * Task T4: Drag and Drop Engine.
 *
 * Handles dragging components onto the Editor.js canvas, displaying
 * a drop-position preview, and inserting the component at the
 * position where it is dropped.
 */
(function (global) {
    'use strict';

    class DragDropEngine {
        constructor() {
            this.activeDraggedComponent = null;
            this.draggedElement = null;
            this.canvas = null;
            this.dropPreview = null;
            this.dropPreviewIndex = null;
        }

        init() {
            this.canvas = document.getElementById('kc-editorjs');

            if (!this.canvas) {
                return;
            }

            this.bindDraggables();
            this.bindDropZones();
        }

        bindDraggables() {
            document.addEventListener('dragstart', (e) => {
                const item = e.target.closest(
                    '[data-component-id]'
                );

                if (!item) {
                    return;
                }

                const componentId =
                    item.dataset.componentId;

                if (!componentId) {
                    return;
                }

                this.activeDraggedComponent =
                    componentId;

                this.draggedElement = item;

                item.classList.add(
                    'kc-is-dragging'
                );

                if (e.dataTransfer) {
                    e.dataTransfer.effectAllowed =
                        'copy';

                    e.dataTransfer.setData(
                        'text/plain',
                        componentId
                    );
                }
            });

            document.addEventListener('dragend', () => {
                if (this.draggedElement) {
                    this.draggedElement.classList.remove(
                        'kc-is-dragging'
                    );
                }

                this.activeDraggedComponent =
                    null;

                this.draggedElement = null;

                if (this.canvas) {
                    this.canvas.classList.remove(
                        'kc-dropzone-active'
                    );
                }

                this.removeDropPreview();
            });
        }

        bindDropZones() {
            const canvas = this.canvas;

            canvas.addEventListener(
                'dragover',
                (e) => {
                    e.preventDefault();

                    if (e.dataTransfer) {
                        e.dataTransfer.dropEffect =
                            'copy';
                    }

                    canvas.classList.add(
                        'kc-dropzone-active'
                    );

                    const runtime =
                        global.KcEditorRuntime;

                    if (
                        !runtime ||
                        !runtime.instance
                    ) {
                        return;
                    }

                    const editor =
                        runtime.instance;

                    const index =
                        this.getDropIndex(
                            e,
                            editor
                        );

                    if (
                        typeof index ===
                        'number'
                    ) {
                        this.updateDropPreview(
                            index,
                            editor
                        );
                    }
                }
            );

            canvas.addEventListener(
                'dragleave',
                (e) => {
                    if (
                        !canvas.contains(
                            e.relatedTarget
                        )
                    ) {
                        canvas.classList.remove(
                            'kc-dropzone-active'
                        );

                        this.removeDropPreview();
                    }
                }
            );

            canvas.addEventListener(
                'drop',
                async (e) => {
                    e.preventDefault();

                    canvas.classList.remove(
                        'kc-dropzone-active'
                    );

                    const componentId =
                        (
                            e.dataTransfer &&
                            e.dataTransfer.getData(
                                'text/plain'
                            )
                        ) ||
                        this.activeDraggedComponent;

                    if (!componentId) {
                        this.removeDropPreview();
                        return;
                    }

                    try {
                        await this.insertComponent(
                            componentId,
                            e
                        );
                    } catch (err) {
                        console.error(
                            '[DragDrop] Failed to insert component:',
                            err
                        );
                    } finally {
                        this.removeDropPreview();
                    }
                }
            );
        }

        createDropPreview() {
            if (this.dropPreview) {
                return this.dropPreview;
            }

            const preview =
                document.createElement('div');

            preview.setAttribute(
                'aria-hidden',
                'true'
            );

            /*
             * All preview styling is intentionally
             * inline so this task requires no changes
             * to kceditor.css.
             */
            preview.style.position =
                'absolute';

            preview.style.left =
                '12px';

            preview.style.right =
                '12px';

            preview.style.height =
                '3px';

            preview.style.display =
                'block';

            preview.style.background =
                '#2563eb';

            preview.style.borderRadius =
                '999px';

            preview.style.boxShadow =
                '0 0 0 2px rgba(37, 99, 235, 0.12)';

            preview.style.pointerEvents =
                'none';

            preview.style.zIndex =
                '70';

            preview.style.transition =
                'top 0.08s ease';

            /*
             * The Editor.js canvas already uses
             * position: relative through kceditor.css.
             * Set it defensively here as well so the
             * preview remains correctly positioned even
             * if surrounding styles change.
             */
            const canvasPosition =
                window.getComputedStyle(
                    this.canvas
                ).position;

            if (
                canvasPosition === 'static'
            ) {
                this.canvas.style.position =
                    'relative';
            }

            this.canvas.appendChild(
                preview
            );

            this.dropPreview =
                preview;

            return preview;
        }

        updateDropPreview(index, editor) {
            const preview =
                this.createDropPreview();

            const blocks =
                editor.blocks;

            if (
                !blocks ||
                typeof blocks.getBlocksCount !==
                'function'
            ) {
                return;
            }

            const count =
                blocks.getBlocksCount();

            this.dropPreviewIndex =
                index;

            const canvasRect =
                this.canvas.getBoundingClientRect();

            /*
             * Empty editor.
             */
            if (count === 0) {
                preview.style.display =
                    'block';

                preview.style.top =
                    '16px';

                return;
            }

            /*
             * Preview before an existing block.
             */
            if (index < count) {
                const block =
                    blocks.getBlockByIndex(
                        index
                    );

                if (
                    block &&
                    block.holder
                ) {
                    const rect =
                        block.holder.getBoundingClientRect();

                    preview.style.display =
                        'block';

                    preview.style.top =
                        (
                            rect.top -
                            canvasRect.top -
                            3
                        ) + 'px';

                    return;
                }
            }

            /*
             * Preview after the final block.
             */
            const lastBlock =
                blocks.getBlockByIndex(
                    count - 1
                );

            if (
                lastBlock &&
                lastBlock.holder
            ) {
                const rect =
                    lastBlock.holder.getBoundingClientRect();

                preview.style.display =
                    'block';

                preview.style.top =
                    (
                        rect.bottom -
                        canvasRect.top +
                        3
                    ) + 'px';
            }
        }

        removeDropPreview() {
            if (this.dropPreview) {
                this.dropPreview.remove();

                this.dropPreview =
                    null;
            }

            this.dropPreviewIndex =
                null;
        }

        async insertComponent(
            componentId,
            event
        ) {
            const runtime =
                global.KcEditorRuntime;

            if (
                !runtime ||
                !runtime.instance
            ) {
                console.warn(
                    '[DragDrop] Editor runtime is not ready.'
                );
                return;
            }

            const editor =
                runtime.instance;

            if (
                !editor.blocks ||
                typeof editor.blocks.insert !==
                'function'
            ) {
                console.warn(
                    '[DragDrop] Editor.js block API is unavailable.'
                );
                return;
            }

            const component =
                this.resolveComponent(
                    componentId
                );

            if (!component) {
                console.warn(
                    '[DragDrop] Component not found:',
                    componentId
                );
                return;
            }

            let editorType =
                component.editorType ||
                component.type ||
                component.id;

            /*
             * Match the existing kc-editor.js mappings.
             */
            if (
                editorType === 'heading'
            ) {
                editorType =
                    'header';
            }

            if (
                editorType === 'link'
            ) {
                editorType =
                    'linkCard';
            }

            const data =
                component.data
                    ? Object.assign(
                        {},
                        component.data
                    )
                    : {};

            /*
             * Use the same position calculation
             * that drives the visual preview.
             */
            const index =
                this.getDropIndex(
                    event,
                    editor
                );

            await editor.blocks.insert(
                editorType,
                data,
                {},
                index,
                true
            );

            console.log(
                '[DragDrop] Component inserted:',
                componentId,
                'at index:',
                index
            );
        }

        resolveComponent(
            componentId
        ) {
            const runtime =
                global.KcEditorRuntime;

            /*
             * Try runtime configuration first.
             */
            if (
                runtime &&
                runtime.config
            ) {
                const config =
                    runtime.config;

                if (
                    Array.isArray(
                        config.catalog
                    )
                ) {
                    const component =
                        config.catalog.find(
                            (item) =>
                                String(
                                    item.id
                                ) ===
                                String(
                                    componentId
                                )
                        );

                    if (component) {
                        return component;
                    }
                }

                if (
                    Array.isArray(
                        config.components
                    )
                ) {
                    const component =
                        config.components.find(
                            (item) =>
                                String(
                                    item.id
                                ) ===
                                String(
                                    componentId
                                )
                        );

                    if (component) {
                        return component;
                    }
                }

                /*
                 * If the component id is directly
                 * registered as an Editor.js tool,
                 * use it directly.
                 */
                if (
                    config.tools &&
                    config.tools[componentId]
                ) {
                    return {
                        id: componentId,
                        editorType:
                            componentId,
                        data: {}
                    };
                }
            }

            /*
             * Try the global editor registry.
             */
            if (
                global.KcEditorRegistry &&
                typeof global.KcEditorRegistry
                    .getTools ===
                'function'
            ) {
                const tools =
                    global.KcEditorRegistry
                        .getTools();

                if (
                    tools &&
                    tools[componentId]
                ) {
                    return {
                        id: componentId,
                        editorType:
                            componentId,
                        data: {}
                    };
                }
            }

            /*
             * Final fallback: treat the component id
             * as the Editor.js tool name.
             */
            return {
                id: componentId,
                editorType: componentId,
                data: {}
            };
        }

        getDropIndex(
            event,
            editor
        ) {
            const blocks =
                editor.blocks;

            if (
                !blocks ||
                typeof blocks
                    .getBlocksCount !==
                'function'
            ) {
                return undefined;
            }

            const count =
                blocks.getBlocksCount();

            if (count === 0) {
                return 0;
            }

            const pointerY =
                event.clientY;

            for (
                let index = 0;
                index < count;
                index++
            ) {
                const block =
                    blocks.getBlockByIndex(
                        index
                    );

                if (
                    !block ||
                    !block.holder
                ) {
                    continue;
                }

                const rect =
                    block.holder
                        .getBoundingClientRect();

                const midpoint =
                    rect.top +
                    rect.height / 2;

                if (
                    pointerY <
                    midpoint
                ) {
                    return index;
                }
            }

            return count;
        }
    }

    global.KcDragDropEngine =
        DragDropEngine;

    /*
     * Initialize after the DOM is ready.
     */
    function initialize() {
        if (
            global.kcDragDropEngine
        ) {
            return;
        }

        global.kcDragDropEngine =
            new DragDropEngine();

        global.kcDragDropEngine.init();
    }

    if (
        document.readyState ===
        'loading'
    ) {
        document.addEventListener(
            'DOMContentLoaded',
            initialize
        );
    } else {
        initialize();
    }

})(typeof window !== 'undefined'
    ? window
    : this);
