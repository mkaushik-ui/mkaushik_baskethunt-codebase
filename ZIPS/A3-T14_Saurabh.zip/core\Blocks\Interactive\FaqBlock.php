<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\BlockType;
use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T14: FAQ Schema Block
 * 
 * Question and Answer block automatically generating Schema.org FAQPage
 * microdata for search engines and accessibility.
 * 
 * @author Saurabh
 */
final class FaqBlock extends AbstractBlock implements BlockType
{
    private const MAX_ITEMS = 50;

    public function type(): string
    {
        return 'faq';
    }

    public function label(): string
    {
        return 'FAQ';
    }

    /**
     * Sanitize stored data payload.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{question: string, answer: string, open: bool}>}
     */
    public function sanitize(array $data): array
    {
        return [
            'items' => self::sanitizeItems($data['items'] ?? [])
        ];
    }

    /**
     * Validate block data constraints.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_ITEMS) {
            return ['FAQ cannot contain more than ' . self::MAX_ITEMS . ' items.'];
        }
        return [];
    }

    /**
     * Render semantic HTML output with Schema.org FAQPage microdata.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(is_array($block['data'] ?? null) ? $block['data'] : []);
        $items = $data['items'];
        if ($items === []) {
            return '';
        }

        $id = isset($block['id']) ? Html::escape((string) $block['id']) : '';
        $dataAttr = $id !== '' ? ' data-block-id="' . $id . '"' : '';

        $html = '<div class="kc-block kc-block-faq"' . $dataAttr . ' itemscope itemtype="https://schema.org/FAQPage">';
        
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $question = (string) ($item['question'] ?? '');
            $answer = (string) ($item['answer'] ?? '');

            if ($question === '' && Html::plainText($answer) === '') {
                continue;
            }

            $open = !empty($item['open']);
            $openAttr = $open ? ' open' : '';

            $html .= '<details class="kc-faq-item"' . $openAttr . ' itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">';
            $html .= '<summary class="kc-faq-question" itemprop="name">' . Html::escape($question !== '' ? $question : 'Question') . '</summary>';
            $html .= '<div class="kc-faq-answer" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">';
            $html .= '<div class="kc-faq-answer-text" itemprop="text">' . $answer . '</div>';
            $html .= '</div></details>';
        }

        $html .= '</div>';

        return $html;
    }

    /**
     * Sanitize list of FAQ question-answer pairs.
     *
     * @param mixed $items
     * @return list<array{question: string, answer: string, open: bool}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $question = Html::plainText(Html::clampText((string) ($item['question'] ?? $item['title'] ?? ''), 500));
            $answer = Html::sanitizeInline((string) ($item['answer'] ?? $item['content'] ?? ''), 20000);
            $open = !empty($item['open']);

            if ($question === '' && Html::plainText($answer) === '') {
                continue;
            }

            $out[] = [
                'question' => $question,
                'answer' => $answer,
                'open' => $open,
            ];

            if (count($out) >= self::MAX_ITEMS) {
                break;
            }
        }

        return $out;
    }
}
