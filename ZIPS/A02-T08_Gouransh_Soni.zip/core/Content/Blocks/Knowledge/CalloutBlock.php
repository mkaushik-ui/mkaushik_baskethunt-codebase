<?php

namespace SOI\Core\Content\Blocks\Knowledge;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Contracts\BlockProviderInterface;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A2-T08: Callout Notice Block
 * Custom professional implementation for SOI Knowledge Center
 */
class CalloutBlock extends AbstractBlock implements BlockProviderInterface
{
    public function type(): string
    {
        return 'callout';
    }

    public function label(): string
    {
        return 'Callout';
    }

    public function category(): string
    {
        return 'knowledge';
    }

    public function icon(): string
    {
        // Simple info circle icon for the CMS selector
        return '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
    }

    /**
     * MUST be public to satisfy BlockProviderInterface.
     */
    public function sanitize(array $data): array
    {
        $allowedTones = ['info', 'note', 'tip', 'warning', 'danger', 'success'];
        $tone = $data['tone'] ?? 'info';
        
        return [
            // Prevent XSS Injection using strict inline sanitization
            'text' => Html::sanitizeInline($data['text'] ?? ''),
            // Enforce strictly whitelisted tones
            'tone' => in_array($tone, $allowedTones, true) ? $tone : 'info',
        ];
    }

    public function outlineTitle(array $data): ?string
    {
        $text = strip_tags($data['text'] ?? '');
        $tone = ucfirst($data['tone'] ?? 'info');
        return $text !== '' ? "[$tone] " . mb_substr($text, 0, 25) . '...' : "Empty $tone Callout";
    }

    public function render(array $block, RenderContext $ctx): string
    {
        // STRICT SECURITY: Always pull via sanitize, never direct array access
        $data = $this->sanitize($block['data'] ?? []);
        $text = $data['text'];
        $tone = $data['tone'];

        if (empty($text)) {
            return '';
        }

        // Return perfectly semantic and styled HTML block
        return sprintf('<div class="kc-callout kc-callout-%s">%s</div>', htmlspecialchars($tone, ENT_QUOTES, 'UTF-8'), $text);
    }
}
