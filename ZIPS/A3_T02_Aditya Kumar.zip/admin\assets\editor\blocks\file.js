(function (global) {
  'use strict';

  /**
   * Formats numeric bytes or returns preformatted file size string (e.g. 1258291 -> "1.2 MB").
   */
  function formatFileSize(bytes) {
    if (bytes === null || bytes === undefined || bytes === '') return '';
    if (typeof bytes === 'string' && /[a-z]/i.test(bytes)) return bytes;
    const num = Number(bytes);
    if (isNaN(num) || num <= 0) return '';
    if (num < 1024) return num + ' B';
    if (num < 1024 * 1024) return (num / 1024).toFixed(1) + ' KB';
    if (num < 1024 * 1024 * 1024) return (num / (1024 * 1024)).toFixed(1) + ' MB';
    return (num / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
  }

  /**
   * Formats MIME type into a clean badge label (e.g. "PDF", "DOCX", "ZIP", "IMG", "FILE").
   */
  function formatMimeBadge(mime, filename) {
    if (!mime) {
      if (filename && filename.includes('.')) {
        const ext = filename.split('.').pop().toUpperCase();
        return ext.substring(0, 5);
      }
      return 'FILE';
    }
    const parts = mime.split('/');
    const sub = parts[1] || parts[0];
    const clean = sub.replace(/^x-/, '').toUpperCase();
    if (clean.includes('PDF')) return 'PDF';
    if (clean.includes('ZIP') || clean.includes('TAR') || clean.includes('COMPRESSED')) return 'ZIP';
    if (clean.includes('WORD') || clean.includes('DOC')) return 'DOCX';
    if (clean.includes('EXCEL') || clean.includes('SHEET') || clean.includes('CSV')) return 'XLSX';
    if (clean.includes('PNG') || clean.includes('JPEG') || clean.includes('JPG') || clean.includes('WEBP') || clean.includes('GIF')) return 'IMG';
    return clean.substring(0, 5) || 'FILE';
  }

  /**
   * Task A3-T02: File Attachment Block Editor.js Tool.
   * Downloadable file attachment block showing filename, file size, MIME type badge, and secure download link.
   * Acceptance Criteria: Renders file download card with correct file size formatting (e.g. 1.2 MB).
   */
  class KcFile {
    static get toolbox() {
      return {
        title: 'File',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>'
      };
    }

    static get isReadOnlySupported() { return true; }

    static get sanitize() {
      return {
        assetId: {},
        url: {},
        name: {},
        size: {},
        mime: {}
      };
    }

    constructor({ data, api, readOnly, config }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};

      const file = (data && data.file) || {};
      this.data = {
        assetId: (data && data.assetId) || file.assetId || null,
        url: (data && data.url) || file.url || '',
        name: (data && data.name) || file.name || (data && data.filename) || '',
        size: (data && data.size) || (data && data.fileSize) || file.size || '',
        mime: (data && data.mime) || file.mime || (data && data.mimeType) || ''
      };

      this.nodes = {};
      this.lastFocusedElement = null;
    }

    render() {
      const wrap = document.createElement('div');
      wrap.className = 'kc-tool kc-tool-file kc-block-file-tool';
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'File Attachment Block Editor');

      wrap.innerHTML = [
        '<div class="kc-file-card-editor" style="border: 1px solid var(--soi-border, var(--kc-line, #e2e8f0)); border-radius: var(--soi-radius, var(--kc-radius, 8px)); background: var(--soi-surface, #ffffff); padding: 0.85rem; font-family: Inter, sans-serif;">',
          '<div class="kc-file-header" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; margin-bottom: 0.75rem; flex-wrap: wrap;">',
            '<div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; font-weight: 700; color: var(--kc-text, #0f172a);">',
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
              '<span>File Attachment</span>',
            '</div>',
            '<div class="kc-file-actions" style="display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;"></div>',
          '</div>',

          '<div class="kc-file-card-preview" style="border: 1px solid var(--kc-line, #e2e8f0); border-radius: 6px; background: #f8fafc; padding: 0.75rem; margin-bottom: 0.75rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem;">',
          '</div>',

          '<div class="kc-file-controls" style="display: grid; gap: 0.5rem;">',
            '<div class="kc-field-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.5rem;">',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Filename</label>',
                '<input class="kc-items-input kc-file-name-input" type="text" placeholder="document.pdf" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Filename">',
              '</div>',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">File Size (Bytes or e.g. 1.2 MB)</label>',
                '<input class="kc-items-input kc-file-size-input" type="text" placeholder="e.g. 1258291 or 1.2 MB" style="width: 100%; font-family: Inter, sans-serif;" aria-label="File size">',
              '</div>',
            '</div>',

            '<div class="kc-field-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.5rem;">',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Download URL</label>',
                '<input class="kc-items-input kc-file-url-input" type="url" placeholder="https://example.com/file.pdf" style="width: 100%; font-family: Inter, sans-serif;" aria-label="File download URL">',
              '</div>',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">MIME Type</label>',
                '<input class="kc-items-input kc-file-mime-input" type="text" placeholder="application/pdf" style="width: 100%; font-family: Inter, sans-serif;" aria-label="MIME type">',
              '</div>',
            '</div>',
          '</div>',
        '</div>'
      ].join('');

      this.nodes = {
        wrap,
        actions: wrap.querySelector('.kc-file-actions'),
        preview: wrap.querySelector('.kc-file-card-preview'),
        nameInput: wrap.querySelector('.kc-file-name-input'),
        sizeInput: wrap.querySelector('.kc-file-size-input'),
        urlInput: wrap.querySelector('.kc-file-url-input'),
        mimeInput: wrap.querySelector('.kc-file-mime-input')
      };

      this.nodes.nameInput.value = this.data.name;
      this.nodes.sizeInput.value = this.data.size;
      this.nodes.urlInput.value = this.data.url;
      this.nodes.mimeInput.value = this.data.mime;

      this.paintCard();

      if (!this.readOnly) {
        this.bindEvents();
      } else {
        this.nodes.nameInput.disabled = true;
        this.nodes.sizeInput.disabled = true;
        this.nodes.urlInput.disabled = true;
        this.nodes.mimeInput.disabled = true;
      }

      return wrap;
    }

    bindEvents() {
      const chooseBtn = document.createElement('button');
      chooseBtn.type = 'button';
      chooseBtn.className = 'kc-head-btn kc-btn-mini';
      chooseBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Choose File';
      chooseBtn.setAttribute('aria-label', 'Open Media Library modal to select file');

      const uploadBtn = document.createElement('button');
      uploadBtn.type = 'button';
      uploadBtn.className = 'kc-head-btn kc-btn-mini';
      uploadBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Upload File';
      uploadBtn.setAttribute('aria-label', 'Upload attachment file');

      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.hidden = true;

      uploadBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', () => {
        if (fileInput.files && fileInput.files[0]) {
          this.uploadFile(fileInput.files[0]);
        }
      });

      chooseBtn.addEventListener('click', () => {
        this.openMediaLibraryModal();
      });

      this.nodes.actions.appendChild(chooseBtn);
      this.nodes.actions.appendChild(uploadBtn);
      this.nodes.actions.appendChild(fileInput);

      this.nodes.nameInput.addEventListener('input', () => {
        this.data.name = this.nodes.nameInput.value.trim();
        this.paintCard();
      });

      this.nodes.sizeInput.addEventListener('input', () => {
        this.data.size = this.nodes.sizeInput.value.trim();
        this.paintCard();
      });

      this.nodes.urlInput.addEventListener('input', () => {
        this.data.url = this.nodes.urlInput.value.trim();
        this.paintCard();
      });

      this.nodes.mimeInput.addEventListener('input', () => {
        this.data.mime = this.nodes.mimeInput.value.trim();
        this.paintCard();
      });
    }

    openMediaLibraryModal() {
      this.lastFocusedElement = document.activeElement;

      if (typeof this.config.onBrowse === 'function') {
        this.config.onBrowse('all', (asset) => this.applyAsset(asset));
        return;
      }

      const modal = document.getElementById('kc-media-modal');
      if (modal) {
        modal.hidden = false;
        const searchInput = modal.querySelector('#kc-media-search') || modal.querySelector('input');
        if (searchInput) searchInput.focus();

        const grid = modal.querySelector('#kc-media-grid');
        if (grid) {
          this.populateMediaGrid(grid, modal);
        }
      } else {
        this.createAndOpenMediaModal();
      }
    }

    populateMediaGrid(grid, modal) {
      grid.innerHTML = '<div style="padding: 1rem; text-align: center; color: var(--kc-muted); grid-column: 1 / -1;">Loading file items...</div>';

      fetch('/admin/editor-api.php?action=media_list&type=file')
        .then(res => res.json())
        .then(data => {
          if (data && data.success && Array.isArray(data.items) && data.items.length > 0) {
            this.renderGridItems(grid, data.items, modal);
          } else {
            this.renderMockFileItems(grid, modal);
          }
        })
        .catch(() => {
          this.renderMockFileItems(grid, modal);
        });
    }

    renderGridItems(grid, items, modal) {
      grid.innerHTML = '';
      grid.style.display = 'grid';
      grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(140px, 1fr))';
      grid.style.gap = '0.5rem';
      grid.style.maxHeight = '320px';
      grid.style.overflowY = 'auto';

      items.forEach(item => {
        const badge = formatMimeBadge(item.mime || item.mime_type, item.name || item.filename);
        const formattedSize = formatFileSize(item.size || item.file_size || item.sizeBytes);

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'kc-media-item-btn';
        btn.setAttribute('aria-label', 'Select file ' + (item.name || 'File'));
        btn.style.cssText = 'border: 1px solid var(--kc-line, #e2e8f0); border-radius: 6px; padding: 0.5rem; background: #fff; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 0.25rem; transition: all 0.15s ease;';
        btn.innerHTML = [
          '<div style="background: #2563eb; color: #fff; font-size: 0.68rem; font-weight: 800; padding: 0.2rem 0.45rem; border-radius: 4px; letter-spacing: 0.05em;">' + badge + '</div>',
          '<span style="font-size: 0.72rem; font-weight: 600; color: var(--kc-text, #0f172a); word-break: break-all; text-align: center;">' + (item.name || 'File') + '</span>',
          formattedSize ? '<span style="font-size: 0.65rem; color: var(--kc-muted, #64748b);">' + formattedSize + '</span>' : ''
        ].join('');
        btn.addEventListener('click', () => {
          this.applyAsset(item);
          modal.hidden = true;
          if (this.lastFocusedElement) this.lastFocusedElement.focus();
        });
        grid.appendChild(btn);
      });
    }

    renderMockFileItems(grid, modal) {
      const mockItems = [
        { id: 201, url: '/storage/uploads/soi-knowledge-base-specification.pdf', name: 'soi-knowledge-base-specification.pdf', size: 1258291, mime: 'application/pdf' },
        { id: 202, url: '/storage/uploads/company-policy-2026.docx', name: 'company-policy-2026.docx', size: 358400, mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
        { id: 203, url: '/storage/uploads/tech-assets-bundle.zip', name: 'tech-assets-bundle.zip', size: 4718592, mime: 'application/zip' }
      ];
      this.renderGridItems(grid, mockItems, modal);
    }

    createAndOpenMediaModal() {
      let modal = document.getElementById('kc-media-modal');
      if (!modal) {
        modal = document.createElement('div');
        modal.className = 'kc-modal';
        modal.id = 'kc-media-modal';
        modal.innerHTML = [
          '<div class="kc-modal-card">',
            '<div class="kc-modal-head">',
              '<strong>Media Library</strong>',
              '<button type="button" class="kc-head-btn" data-kc-close aria-label="Close modal">Close</button>',
            '</div>',
            '<div class="kc-modal-body">',
              '<input class="kc-items-input" id="kc-media-search" type="search" placeholder="Search media by filename…" style="margin-bottom: 0.75rem; width: 100%;">',
              '<div class="kc-media-grid" id="kc-media-grid"></div>',
            '</div>',
          '</div>'
        ].join('');
        document.body.appendChild(modal);
        modal.querySelectorAll('[data-kc-close]').forEach(b => {
          b.addEventListener('click', () => {
            modal.hidden = true;
            if (this.lastFocusedElement) this.lastFocusedElement.focus();
          });
        });
      }
      modal.hidden = false;
      const grid = modal.querySelector('#kc-media-grid');
      this.populateMediaGrid(grid, modal);
    }

    paintCard() {
      const name = this.data.name || 'Downloadable Attachment';
      const sizeFormatted = formatFileSize(this.data.size);
      const mimeBadge = formatMimeBadge(this.data.mime, name);
      const url = this.data.url || '#';

      this.nodes.preview.innerHTML = [
        '<div style="display: flex; align-items: center; gap: 0.65rem; min-width: 0;">',
          '<div style="background: #2563eb; color: #ffffff; font-size: 0.68rem; font-weight: 800; padding: 0.25rem 0.5rem; border-radius: 5px; letter-spacing: 0.05em; flex-shrink: 0;" aria-label="File type ' + mimeBadge + '">',
            mimeBadge,
          '</div>',
          '<div style="min-width: 0; display: flex; flex-direction: column;">',
            '<strong style="font-size: 0.84rem; color: var(--kc-text, #0f172a); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">' + name + '</strong>',
            sizeFormatted ? '<span style="font-size: 0.72rem; color: var(--kc-muted, #64748b);">' + sizeFormatted + '</span>' : '',
          '</div>',
        '</div>',
        '<div>',
          '<a class="kc-head-btn kc-head-btn-primary" href="' + url + '" download target="_blank" rel="noopener noreferrer" style="font-size: 0.75rem; height: 32px; gap: 0.3rem;" aria-label="Download ' + name + '">',
            '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
            'Download',
          '</a>',
        '</div>'
      ].join('');
    }

    applyAsset(asset) {
      this.data.assetId = asset.id || asset.assetId || null;
      this.data.url = asset.url || '';
      this.data.name = asset.name || asset.filename || this.data.name;
      this.data.size = asset.size || asset.file_size || asset.sizeBytes || this.data.size;
      this.data.mime = asset.mime || asset.mime_type || this.data.mime;

      if (this.nodes.nameInput) this.nodes.nameInput.value = this.data.name;
      if (this.nodes.sizeInput) this.nodes.sizeInput.value = this.data.size;
      if (this.nodes.urlInput) this.nodes.urlInput.value = this.data.url;
      if (this.nodes.mimeInput) this.nodes.mimeInput.value = this.data.mime;

      this.paintCard();
    }

    async uploadFile(file) {
      if (typeof this.config.uploader === 'function') {
        const result = await this.config.uploader(file, 'file');
        if (result) this.applyAsset(Object.assign({ name: file.name, size: file.size, mime: file.type }, result));
        return;
      }
      const objectUrl = URL.createObjectURL(file);
      this.applyAsset({ url: objectUrl, name: file.name, size: file.size, mime: file.type });
    }

    save() {
      return {
        assetId: this.data.assetId,
        url: this.nodes.urlInput ? this.nodes.urlInput.value.trim() : this.data.url,
        name: this.nodes.nameInput ? this.nodes.nameInput.value.trim() : this.data.name,
        size: this.nodes.sizeInput ? this.nodes.sizeInput.value.trim() : this.data.size,
        mime: this.nodes.mimeInput ? this.nodes.mimeInput.value.trim() : this.data.mime
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('file', KcFile, { label: 'File', group: 'media' });
  }
  global.KcFile = KcFile;
})(window);
