<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Media\FileBlock as MediaFileBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\FileBlock
 */
final class FileBlock extends MediaFileBlock
{
}
