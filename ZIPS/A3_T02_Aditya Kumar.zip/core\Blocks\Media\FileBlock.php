<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Media;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\AssetResolver;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T02: File Attachment Block renderer and sanitizer.
 * Downloadable file attachment block showing filename, file size, MIME type badge, and secure download link.
 * Acceptance Criteria: Renders file download card with correct file size formatting (e.g. 1.2 MB).
 */
class FileBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'file';
    }

    public function label(): string
    {
        return 'File';
    }

    public function sanitize(array $data): array
    {
        $file = is_array($data['file'] ?? null) ? $data['file'] : [];
        return [
            'assetId' => $this->intOrNull($data['assetId'] ?? $file['assetId'] ?? null),
            'url' => Html::sanitizeUrl((string) ($data['url'] ?? $file['url'] ?? '')),
            'name' => Html::plainText($this->text($data['name'] ?? $file['name'] ?? $data['filename'] ?? $data['title'] ?? '', 300)),
            'size' => Html::plainText($this->text((string) ($data['size'] ?? $data['fileSize'] ?? $file['size'] ?? ''), 50)),
            'mime' => Html::plainText($this->text((string) ($data['mime'] ?? $file['mime'] ?? $data['mimeType'] ?? ''), 100)),
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public static function formatFileSize(mixed $bytes): string
    {
        if ($bytes === null || $bytes === '') {
            return '';
        }
        $str = (string) $bytes;
        if (preg_match('/[a-z]/i', $str)) {
            return $str; // Preformatted e.g. "1.2 MB"
        }
        if (!is_numeric($str)) {
            return '';
        }
        $num = (float) $str;
        if ($num <= 0) {
            return '';
        }
        if ($num < 1024) {
            return $num . ' B';
        }
        if ($num < 1024 * 1024) {
            return round($num / 1024, 1) . ' KB';
        }
        if ($num < 1024 * 1024 * 1024) {
            return round($num / (1024 * 1024), 1) . ' MB';
        }
        return round($num / (1024 * 1024 * 1024), 1) . ' GB';
    }

    public static function formatMimeBadge(string $mime, string $name): string
    {
        if ($mime === '') {
            if ($name !== '' && str_contains($name, '.')) {
                $ext = strtoupper(pathinfo($name, PATHINFO_EXTENSION));
                return substr($ext, 0, 5);
            }
            return 'FILE';
        }
        $parts = explode('/', $mime);
        $sub = $parts[1] ?? $parts[0];
        $clean = strtoupper(preg_replace('/^x-/', '', $sub));
        if (str_contains($clean, 'PDF')) return 'PDF';
        if (str_contains($clean, 'ZIP') || str_contains($clean, 'TAR') || str_contains($clean, 'COMPRESSED')) return 'ZIP';
        if (str_contains($clean, 'WORD') || str_contains($clean, 'DOC')) return 'DOCX';
        if (str_contains($clean, 'EXCEL') || str_contains($clean, 'SHEET') || str_contains($clean, 'CSV')) return 'XLSX';
        if (str_contains($clean, 'PNG') || str_contains($clean, 'JPEG') || str_contains($clean, 'JPG') || str_contains($clean, 'WEBP') || str_contains($clean, 'GIF')) return 'IMG';
        return substr($clean, 0, 5) ?: 'FILE';
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $asset = AssetResolver::resolve($data);
        $url = $asset['url'] !== '' ? $asset['url'] : Html::sanitizeUrl((string) ($data['url'] ?? ''));
        if ($url === '') {
            return '';
        }

        $name = $asset['name'] !== '' ? $asset['name'] : Html::plainText((string) ($data['name'] ?? $data['filename'] ?? 'Download file'));
        if ($name === '') {
            $name = 'Download file';
        }

        $sizeRaw = $data['size'] ?? $data['fileSize'] ?? ($asset['size'] ?? '');
        $sizeFormatted = self::formatFileSize($sizeRaw);

        $mimeRaw = $asset['mime'] !== '' ? $asset['mime'] : Html::plainText((string) ($data['mime'] ?? $data['mimeType'] ?? ''));
        $mimeBadge = self::formatMimeBadge($mimeRaw, $name);

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $html = '<div class="kc-block kc-block-file kc-file-card"' . $dataAttr . '>';
        $html .= '<div class="kc-file-icon-badge">';
        $html .= '<span class="kc-file-mime-badge" aria-label="File type ' . Html::escape($mimeBadge) . '">' . Html::escape($mimeBadge) . '</span>';
        $html .= '</div>';
        $html .= '<div class="kc-file-details">';
        $html .= '<strong class="kc-file-name">' . Html::escape($name) . '</strong>';
        if ($sizeFormatted !== '') {
            $html .= '<span class="kc-file-meta">' . Html::escape($sizeFormatted) . '</span>';
        }
        $html .= '</div>';
        $html .= '<div class="kc-file-action">';
        $html .= '<a class="kc-file-download-btn kc-head-btn kc-head-btn-primary" href="' . Html::escape($url) . '" download target="_blank" rel="noopener noreferrer" aria-label="Download ' . Html::escape($name) . '">';
        $html .= '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> ';
        $html .= 'Download';
        $html .= '</a>';
        $html .= '</div>';
        $html .= '</div>';
        return $html;
    }
}
