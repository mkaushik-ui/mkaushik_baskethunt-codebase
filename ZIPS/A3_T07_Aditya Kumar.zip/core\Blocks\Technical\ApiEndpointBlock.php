<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T07: API Endpoint Specification Block renderer and sanitizer.
 * Technical API endpoint block with HTTP Method badge (GET, POST, PUT, DELETE), path, auth header spec, request body, and response JSON preview.
 * Acceptance Criteria: Method badge uses color modifier (kc-method-get, kc-method-post). Response body JSON renders formatted.
 */
class ApiEndpointBlock extends AbstractBlock
{
    private const METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD'];

    public function type(): string
    {
        return 'apiEndpoint';
    }

    public function label(): string
    {
        return 'API Endpoint';
    }

    public function sanitize(array $data): array
    {
        $method = strtoupper(trim((string) ($data['method'] ?? 'GET')));
        if (!in_array($method, self::METHODS, true)) {
            $method = 'GET';
        }

        $endpoint = trim((string) ($data['endpoint'] ?? $data['path'] ?? '/api'));
        $title = Html::plainText((string) ($data['title'] ?? ''));
        $description = Html::plainText((string) ($data['description'] ?? ''));
        $auth = Html::plainText((string) ($data['auth'] ?? $data['authHeader'] ?? ''));

        $params = [];
        if (isset($data['parameters']) && is_array($data['parameters'])) {
            foreach ($data['parameters'] as $p) {
                if (!is_array($p)) continue;
                $params[] = [
                    'name' => Html::plainText((string) ($p['name'] ?? '')),
                    'type' => Html::plainText((string) ($p['type'] ?? 'string')),
                    'required' => !empty($p['required']),
                    'description' => Html::plainText((string) ($p['description'] ?? $p['desc'] ?? '')),
                ];
            }
        }

        $requestBody = (string) ($data['requestBody'] ?? $data['request'] ?? '');
        $responseBody = (string) ($data['responseBody'] ?? $data['response'] ?? '');

        return [
            'method' => $method,
            'endpoint' => Html::clampText($endpoint, 500),
            'title' => Html::clampText($title, 300),
            'description' => Html::clampText($description, 2000),
            'auth' => Html::clampText($auth, 200),
            'parameters' => $params,
            'requestBody' => Html::clampText($requestBody, 50000),
            'responseBody' => Html::clampText($responseBody, 50000),
        ];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $d = $this->sanitize($block['data'] ?? []);
        $methodUpper = $d['method'];
        $methodLower = strtolower($methodUpper);
        
        // Color modifier requirement: kc-method-get, kc-method-post, kc-method-put, kc-method-delete
        $methodBadgeClass = 'kc-api-method kc-method-' . Html::escape($methodLower);

        $endpoint = Html::escape($d['endpoint']);
        $title = $d['title'] !== '' ? '<div class="kc-api-title"><strong style="font-size: 1rem; color: #0f172a;">' . Html::escape($d['title']) . '</strong></div>' : '';
        $desc = $d['description'] !== '' ? '<div class="kc-api-desc" style="font-size: 0.84rem; color: #475569; margin-top: 0.25rem;">' . Html::escape($d['description']) . '</div>' : '';
        $auth = $d['auth'] !== '' ? '<span class="kc-api-auth" style="font-size: 0.76rem; background: #f1f5f9; padding: 0.2rem 0.5rem; border-radius: 4px; color: #475569; border: 1px solid #cbd5e1;">Auth: <code>' . Html::escape($d['auth']) . '</code></span>' : '';

        $paramsHtml = '';
        if (!empty($d['parameters'])) {
            $rows = '';
            foreach ($d['parameters'] as $p) {
                $reqBadge = $p['required'] ? '<span class="kc-api-req" style="background: #fef2f2; color: #b91c1c; font-size: 0.7rem; font-weight: 700; padding: 0.15rem 0.4rem; border-radius: 4px;">Required</span>' : '<span class="kc-api-opt" style="background: #f8fafc; color: #64748b; font-size: 0.7rem; font-weight: 600; padding: 0.15rem 0.4rem; border-radius: 4px;">Optional</span>';
                $rows .= '<tr><td style="padding: 0.45rem 0.65rem; border: 1px solid #e2e8f0;"><code>' . Html::escape($p['name']) . '</code></td><td style="padding: 0.45rem 0.65rem; border: 1px solid #e2e8f0; font-size: 0.78rem; color: #475569;">' . Html::escape($p['type']) . '</td><td style="padding: 0.45rem 0.65rem; border: 1px solid #e2e8f0;">' . $reqBadge . '</td><td style="padding: 0.45rem 0.65rem; border: 1px solid #e2e8f0; font-size: 0.8rem; color: #334155;">' . Html::escape($p['description']) . '</td></tr>';
            }
            $paramsHtml = '<div class="kc-api-section" style="margin-top: 1rem;"><h4 style="font-size: 0.82rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin: 0 0 0.4rem;">Parameters</h4><div class="kc-table-wrap" style="overflow-x: auto; border: 1px solid #e2e8f0; border-radius: 6px;"><table class="kc-api-params" style="width: 100%; border-collapse: collapse; font-size: 0.84rem;"><thead><tr style="background: #f8fafc; text-align: left;"><th style="padding: 0.5rem 0.65rem; border: 1px solid #e2e8f0;">Name</th><th style="padding: 0.5rem 0.65rem; border: 1px solid #e2e8f0;">Type</th><th style="padding: 0.5rem 0.65rem; border: 1px solid #e2e8f0;">Required</th><th style="padding: 0.5rem 0.65rem; border: 1px solid #e2e8f0;">Description</th></tr></thead><tbody>' . $rows . '</tbody></table></div></div>';
        }

        $reqHtml = '';
        if ($d['requestBody'] !== '') {
            $formattedReq = self::formatJsonIfPossible($d['requestBody']);
            $reqHtml = '<div class="kc-api-section" style="margin-top: 1rem;"><h4 style="font-size: 0.82rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin: 0 0 0.4rem;">Request Body</h4><pre class="kc-api-code" style="background: #0f172a; color: #f8fafc; padding: 0.75rem; border-radius: 6px; font-family: ui-monospace, monospace; font-size: 0.82rem; overflow-x: auto; margin: 0;"><code>' . Html::escape($formattedReq) . '</code></pre></div>';
        }

        $resHtml = '';
        if ($d['responseBody'] !== '') {
            $formattedRes = self::formatJsonIfPossible($d['responseBody']);
            $resHtml = '<div class="kc-api-section" style="margin-top: 1rem;"><h4 style="font-size: 0.82rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin: 0 0 0.4rem;">Response Body (JSON)</h4><pre class="kc-api-code" style="background: #0f172a; color: #38bdf8; padding: 0.75rem; border-radius: 6px; font-family: ui-monospace, monospace; font-size: 0.82rem; overflow-x: auto; margin: 0;"><code>' . Html::escape($formattedRes) . '</code></pre></div>';
        }

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        return '<div class="kc-block kc-block-api kc-api-' . Html::escape($methodLower) . '"' . $dataAttr . ' style="border: 1px solid #e2e8f0; border-radius: 8px; background: #ffffff; padding: 1rem; margin-bottom: 1.25rem; font-family: Inter, sans-serif;">'
            . '<div class="kc-api-header" style="display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 0.6rem;">'
            . '<div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">'
            . '<span class="' . $methodBadgeClass . '">' . Html::escape($methodUpper) . '</span>'
            . '<code class="kc-api-endpoint" style="font-size: 0.9rem; font-weight: 700; color: #0f172a; background: #f8fafc; padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid #e2e8f0;">' . $endpoint . '</code>'
            . '</div>'
            . $auth
            . '</div>'
            . $title
            . $desc
            . $paramsHtml
            . $reqHtml
            . $resHtml
            . '</div>';
    }

    private static function formatJsonIfPossible(string $raw): string
    {
        $rawTrimmed = trim($raw);
        if ($rawTrimmed === '') return '';
        $decoded = json_decode($rawTrimmed, true);
        if (json_last_error() === JSON_ERROR_NONE && (is_array($decoded) || is_object($decoded))) {
            return (string) json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        }
        return $raw;
    }
}
