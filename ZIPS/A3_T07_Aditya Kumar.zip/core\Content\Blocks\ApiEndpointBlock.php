<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\ApiEndpointBlock as TechnicalApiEndpointBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\ApiEndpointBlock
 */
final class ApiEndpointBlock extends TechnicalApiEndpointBlock
{
}
