(function (global) {
  'use strict';

  const LANGS = [
    { value: 'php', label: 'PHP' },
    { value: 'javascript', label: 'JavaScript (JS)' },
    { value: 'python', label: 'Python' },
    { value: 'bash', label: 'Bash / Shell' },
    { value: 'sql', label: 'SQL' },
    { value: 'html', label: 'HTML' },
    { value: 'css', label: 'CSS' },
    { value: 'typescript', label: 'TypeScript' },
    { value: 'go', label: 'Go' },
    { value: 'json', label: 'JSON' }
  ];

  /**
   * Task A3-T05: Technical Code Block Editor.js Tool.
   * Code snippet block with language selector (PHP, JS, Python, Bash, SQL, HTML, CSS), line numbers, and one-click copy button.
   * Acceptance Criteria: Stores raw un-escaped code text. HTML output escapes code safely (<, >). Copy button copies raw snippet.
   */
  class KcCode {
    static get toolbox() {
      return {
        title: 'Code',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M8 8 4 12l4 4M16 8l4 4-4 4M13 6l-2 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
      };
    }

    static get isReadOnlySupported() { return true; }
    static get enableLineBreaks() { return true; }
    static get sanitize() {
      return {
        code: true,
        language: {},
        caption: {},
        showLineNumbers: {}
      };
    }

    constructor({ data, api, readOnly, config }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};

      this.data = {
        code: (data && data.code) || '',
        language: (data && data.language) || 'php',
        caption: (data && data.caption) || '',
        showLineNumbers: (data && data.showLineNumbers !== undefined) ? !!data.showLineNumbers : true
      };

      this.nodes = {};
    }

    render() {
      const wrap = document.createElement('div');
      wrap.className = 'kc-tool kc-tool-code kc-block-code-tool';
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'Technical Code Block Editor');

      wrap.innerHTML = [
        '<div class="kc-code-card-editor" style="border: 1px solid var(--soi-border, var(--kc-line, #e2e8f0)); border-radius: var(--soi-radius, var(--kc-radius, 8px)); background: var(--soi-surface, #ffffff); padding: 0.85rem; font-family: Inter, sans-serif;">',
          '<div class="kc-code-bar" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; margin-bottom: 0.75rem; flex-wrap: wrap;">',
            '<div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; font-weight: 700; color: var(--kc-text, #0f172a);">',
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 8 4 12l4 4M16 8l4 4-4 4M13 6l-2 12"/></svg>',
              '<span>Technical Code Snippet</span>',
            '</div>',
            '<div class="kc-code-actions" style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">',
              '<select class="kc-tool-select kc-code-lang-select" style="font-family: Inter, sans-serif; font-size: 0.78rem; min-width: 140px;" aria-label="Select Programming Language"></select>',
              '<label style="display: flex; align-items: center; gap: 0.3rem; font-size: 0.74rem; font-weight: 600; color: var(--kc-muted, #64748b); cursor: pointer;">',
                '<input type="checkbox" class="kc-code-lines-toggle" style="cursor: pointer;"> Line Numbers',
              '</label>',
              '<button type="button" class="kc-head-btn kc-btn-mini kc-code-copy-trigger" aria-label="Copy raw code snippet">',
                '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 3px;"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
                '<span>Copy</span>',
              '</button>',
            '</div>',
          '</div>',

          '<div style="margin-bottom: 0.5rem;">',
            '<input class="kc-items-input kc-code-caption-input" type="text" placeholder="Optional snippet title / description (e.g. Database Connection Helper)" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Snippet Caption">',
          '</div>',

          '<div class="kc-code-editor-wrap" style="position: relative; border: 1px solid var(--kc-line, #cbd5e1); border-radius: 6px; background: #0f172a; overflow: hidden;">',
            '<textarea class="kc-code-area" spellcheck="false" placeholder="Paste or write raw code snippet here…" style="width: 100%; min-height: 160px; padding: 0.75rem; border: none; background: #0f172a; color: #f8fafc; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 0.84rem; line-height: 1.5; resize: vertical; outline: none;" aria-label="Raw Code Snippet Input"></textarea>',
          '</div>',
        '</div>'
      ].join('');

      this.nodes = {
        wrap,
        langSelect: wrap.querySelector('.kc-code-lang-select'),
        linesToggle: wrap.querySelector('.kc-code-lines-toggle'),
        copyBtn: wrap.querySelector('.kc-code-copy-trigger'),
        captionInput: wrap.querySelector('.kc-code-caption-input'),
        area: wrap.querySelector('.kc-code-area')
      };

      // Populate language select options
      LANGS.forEach((item) => {
        const opt = document.createElement('option');
        opt.value = item.value;
        opt.textContent = item.label;
        if (item.value === this.data.language || (item.value === 'javascript' && this.data.language === 'js')) {
          opt.selected = true;
        }
        this.nodes.langSelect.appendChild(opt);
      });

      this.nodes.linesToggle.checked = this.data.showLineNumbers;
      this.nodes.captionInput.value = this.data.caption;
      this.nodes.area.value = this.data.code;

      if (!this.readOnly) {
        this.bindEvents();
      } else {
        this.nodes.langSelect.disabled = true;
        this.nodes.linesToggle.disabled = true;
        this.nodes.captionInput.disabled = true;
        this.nodes.area.readOnly = true;
      }

      return wrap;
    }

    bindEvents() {
      this.nodes.langSelect.addEventListener('change', () => {
        this.data.language = this.nodes.langSelect.value;
      });

      this.nodes.linesToggle.addEventListener('change', () => {
        this.data.showLineNumbers = this.nodes.linesToggle.checked;
      });

      this.nodes.captionInput.addEventListener('input', () => {
        this.data.caption = this.nodes.captionInput.value.trim();
      });

      this.nodes.area.addEventListener('input', () => {
        this.data.code = this.nodes.area.value; // Retains raw unescaped code
      });

      // One-click copy button functionality
      this.nodes.copyBtn.addEventListener('click', () => {
        const rawText = this.nodes.area.value;
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(rawText).then(() => {
            this.showCopyFeedback();
          }).catch(() => {
            this.fallbackCopy(rawText);
          });
        } else {
          this.fallbackCopy(rawText);
        }
      });
    }

    fallbackCopy(text) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        this.showCopyFeedback();
      } catch (err) {
        console.error('Copy failed', err);
      }
      document.body.removeChild(textarea);
    }

    showCopyFeedback() {
      const btnSpan = this.nodes.copyBtn.querySelector('span');
      if (btnSpan) {
        const orig = btnSpan.textContent;
        btnSpan.textContent = 'Copied!';
        setTimeout(() => {
          btnSpan.textContent = orig;
        }, 1800);
      }
    }

    save() {
      return {
        code: this.nodes.area ? this.nodes.area.value : this.data.code,
        language: this.nodes.langSelect ? this.nodes.langSelect.value : this.data.language,
        caption: this.nodes.captionInput ? this.nodes.captionInput.value.trim() : this.data.caption,
        showLineNumbers: this.nodes.linesToggle ? this.nodes.linesToggle.checked : this.data.showLineNumbers
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('code', KcCode, { label: 'Code', group: 'technical' });
  }
  global.KcCode = KcCode;
})(window);
