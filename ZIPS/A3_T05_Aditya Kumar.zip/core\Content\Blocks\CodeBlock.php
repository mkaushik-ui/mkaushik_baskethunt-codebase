<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\CodeBlock as TechnicalCodeBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\CodeBlock
 */
final class CodeBlock extends TechnicalCodeBlock
{
}
