<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T05: Technical Code Block renderer and sanitizer.
 * Code snippet block with language selector (PHP, JS, Python, Bash, SQL, HTML, CSS), line numbers, and one-click copy button.
 * Acceptance Criteria: Stores raw un-escaped code text. HTML output escapes code safely (<, >). Copy button copies raw snippet.
 */
class CodeBlock extends AbstractBlock
{
    private const MAX_CODE = 100000;

    public function type(): string
    {
        return 'code';
    }

    public function label(): string
    {
        return 'Code';
    }

    public function sanitize(array $data): array
    {
        $code = is_scalar($data['code'] ?? '') ? (string) $data['code'] : '';
        $language = strtolower(trim((string) ($data['language'] ?? '')));
        $language = preg_replace('/[^a-z0-9+#._-]/', '', $language) ?? '';
        return [
            'code' => Html::clampText($code, self::MAX_CODE), // Stores raw un-escaped code text
            'language' => Html::clampText($language, 40),
            'caption' => Html::plainText($this->text($data['caption'] ?? '', 300)),
            'showLineNumbers' => !empty($data['showLineNumbers']),
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $code = (string) ($data['code'] ?? '');
        $language = (string) ($data['language'] ?? 'text');
        if ($language === '') {
            $language = 'text';
        }
        $caption = (string) ($data['caption'] ?? '');
        $showLineNumbers = !empty($data['showLineNumbers']);

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $langClass = ' language-' . Html::escape($language);
        $lineNumClass = $showLineNumbers ? ' show-line-numbers' : '';

        $html = '<figure class="kc-block kc-block-code' . $lineNumClass . '"' . $dataAttr . '>';
        $html .= '<div class="kc-code-header">';
        $html .= '<span class="kc-code-lang">' . Html::escape(strtoupper($language)) . '</span>';
        $html .= '<button type="button" class="kc-code-copy-btn kc-head-btn kc-btn-mini" data-kc-copy aria-label="Copy code snippet">';
        $html .= '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px; vertical-align:middle;"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
        $html .= 'Copy';
        $html .= '</button>';
        $html .= '</div>';

        if ($caption !== '') {
            $html .= '<figcaption class="kc-code-caption">' . Html::escape($caption) . '</figcaption>';
        }

        $html .= '<pre class="kc-code-pre"><code class="kc-code' . $langClass . '" data-language="' . Html::escape($language) . '">';
        $html .= Html::escape($code); // Safely escapes HTML output (<, >)
        $html .= '</code></pre>';
        
        // Self-contained, robust copy event handler
        $html .= '<script>';
        $html .= 'if(!window.kcCopyHandlerBound){window.kcCopyHandlerBound=true;document.addEventListener("click",function(e){var btn=e.target.closest("[data-kc-copy]");if(!btn)return;var fig=btn.closest(".kc-block-code");if(!fig)return;var code=fig.querySelector("code");if(!code)return;var text=code.textContent||code.innerText;if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text);}else{var ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();try{document.execCommand("copy");}catch(err){}document.body.removeChild(ta);}var orig=btn.innerHTML;btn.innerHTML="Copied!";setTimeout(function(){btn.innerHTML=orig;},1800);});}';
        $html .= '</script>';

        $html .= '</figure>';

        return $html;
    }
}
