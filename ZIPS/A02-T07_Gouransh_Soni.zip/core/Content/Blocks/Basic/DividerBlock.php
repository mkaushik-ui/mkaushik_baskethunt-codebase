<?php

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Contracts\BlockProviderInterface;
use SOI\Core\Content\RenderContext;

/**
 * Task A2-T07: Divider Block
 * Custom professional implementation for SOI Knowledge Center
 */
class DividerBlock extends AbstractBlock implements BlockProviderInterface
{
    public function type(): string
    {
        return 'divider';
    }

    public function label(): string
    {
        return 'Divider';
    }

    public function category(): string
    {
        return 'basic';
    }

    public function icon(): string
    {
        return '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><line x1="4" y1="12" x2="20" y2="12"></line></svg>';
    }

    /**
     * MUST be public to satisfy BlockProviderInterface.
     */
    public function sanitize(array $data): array
    {
        // Divider has no data payload, it's just a structural block
        return [];
    }

    public function outlineTitle(array $data): ?string
    {
        return '--- Divider ---';
    }

    public function render(array $block, RenderContext $ctx): string
    {
        return '<hr class="kc-divider">';
    }
}
