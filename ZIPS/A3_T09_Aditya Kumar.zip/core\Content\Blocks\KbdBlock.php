<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\KbdBlock as TechnicalKbdBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\KbdBlock
 */
final class KbdBlock extends TechnicalKbdBlock
{
}
