<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T09: Keyboard Keys Block renderer and sanitizer.
 * Shortcut key sequence block rendering semantic <kbd> elements (e.g. Ctrl + Shift + P).
 * Acceptance Criteria: Renders <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>P</kbd>.
 */
class KbdBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'kbd';
    }

    public function label(): string
    {
        return 'Keyboard Key';
    }

    public function sanitize(array $data): array
    {
        $keys = [];
        if (isset($data['keys']) && is_array($data['keys'])) {
            foreach ($data['keys'] as $k) {
                $k = trim(Html::plainText((string) $k));
                if ($k !== '') $keys[] = Html::clampText($k, 50);
            }
        } elseif (isset($data['text']) || isset($data['keys'])) {
            $raw = (string) ($data['text'] ?? $data['keys'] ?? '');
            $parts = preg_split('/[\+,]/', $raw);
            if (is_array($parts)) {
                foreach ($parts as $p) {
                    $p = trim(Html::plainText((string) $p));
                    if ($p !== '') $keys[] = Html::clampText($p, 50);
                }
            }
        }
        $description = trim(Html::plainText((string) ($data['description'] ?? '')));
        return [
            'keys' => $keys,
            'description' => Html::clampText($description, 300),
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $d = $this->sanitize($block['data'] ?? []);
        if (empty($d['keys'])) {
            return '';
        }
        $renderedKeys = array_map(static fn($k) => '<kbd class="kc-kbd">' . Html::escape($k) . '</kbd>', $d['keys']);
        $seq = implode(' <span class="kc-kbd-plus">+</span> ', $renderedKeys);
        $desc = $d['description'] !== '' ? ' <span class="kc-kbd-desc" style="font-size: 0.8rem; color: #64748b; margin-left: 0.5rem;">' . Html::escape($d['description']) . '</span>' : '';
        
        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        return '<div class="kc-block kc-block-kbd"' . $dataAttr . ' style="display: inline-flex; align-items: center; gap: 0.25rem; font-family: Inter, sans-serif;">'
            . '<span class="kc-kbd-combo">' . $seq . '</span>'
            . $desc
            . '</div>';
    }
}
