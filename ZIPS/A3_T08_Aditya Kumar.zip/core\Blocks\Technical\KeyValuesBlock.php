<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T08: Key/Value Specification List renderer and sanitizer.
 * Structured reference key-value pairs component for documentation specs and parameter lists.
 * Acceptance Criteria: Renders <dl class="kc-keyvalues"><dt>Key</dt><dd>Value</dd></dl>.
 */
class KeyValuesBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'keyValues';
    }

    public function label(): string
    {
        return 'Key / Value';
    }

    public function sanitize(array $data): array
    {
        $items = [];
        if (isset($data['items']) && is_array($data['items'])) {
            foreach ($data['items'] as $item) {
                if (!is_array($item)) continue;
                $key = trim($this->text($item['key'] ?? $item['label'] ?? '', 200));
                $value = trim($this->inline($item['value'] ?? $item['val'] ?? '', 1000));
                if ($key !== '' || $value !== '') {
                    $items[] = [
                        'key' => Html::clampText($key, 200),
                        'value' => Html::clampText($value, 1000),
                    ];
                }
            }
        }
        $title = trim($this->text($data['title'] ?? '', 200));
        return ['title' => Html::plainText($title), 'items' => $items];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $d = $this->sanitize($block['data'] ?? []);
        if (empty($d['items'])) {
            return '';
        }
        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $titleHtml = $d['title'] !== '' ? '<div class="kc-keyvalues-title" style="font-size: 0.95rem; font-weight: 700; color: #0f172a; margin-bottom: 0.6rem;">' . Html::escape($d['title']) . '</div>' : '';

        // Acceptance Criteria requirement: Renders <dl class="kc-keyvalues"><dt>Key</dt><dd>Value</dd></dl>
        $dlContent = '';
        foreach ($d['items'] as $item) {
            $dlContent .= '<dt class="kc-keyvalue-key" style="font-weight: 700; color: #0f172a;">' . Html::escape($item['key']) . '</dt>';
            $dlContent .= '<dd class="kc-keyvalue-val" style="margin-left: 0; margin-bottom: 0.6rem; color: #334155;">' . $item['value'] . '</dd>';
        }

        $html = '<div class="kc-block kc-block-keyvalues"' . $dataAttr . '>';
        $html .= $titleHtml;
        $html .= '<dl class="kc-keyvalues" style="display: grid; grid-template-columns: auto 1fr; gap: 0.4rem 1rem; margin: 0; padding: 0.75rem; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; font-family: Inter, sans-serif; font-size: 0.85rem;">';
        $html .= $dlContent;
        $html .= '</dl>';
        $html .= '</div>';

        return $html;
    }
}
