<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\KeyValuesBlock as TechnicalKeyValuesBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\KeyValuesBlock
 */
final class KeyValuesBlock extends TechnicalKeyValuesBlock
{
}
