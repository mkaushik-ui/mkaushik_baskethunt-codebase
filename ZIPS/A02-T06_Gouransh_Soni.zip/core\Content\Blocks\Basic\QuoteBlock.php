<?php

namespace SOI\Core\Content\Blocks\Basic;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Contracts\BlockProviderInterface;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A2-T06: Quote Block
 * Custom professional implementation for SOI Knowledge Center
 */
class QuoteBlock extends AbstractBlock implements BlockProviderInterface
{
    public function type(): string
    {
        return 'quote';
    }

    public function label(): string
    {
        return 'Quote';
    }

    public function category(): string
    {
        return 'basic';
    }

    public function icon(): string
    {
        return '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>';
    }

    /**
     * MUST be public to satisfy BlockProviderInterface.
     */
    public function sanitize(array $data): array
    {
        return [
            'text'    => Html::sanitizeInline($data['text'] ?? ''),
            'caption' => Html::sanitizeInline($data['caption'] ?? ''),
        ];
    }

    public function outlineTitle(array $data): ?string
    {
        $text = strip_tags($data['text'] ?? '');
        return $text !== '' ? mb_substr($text, 0, 30) . '...' : 'Empty Quote';
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize($block['data'] ?? []);
        $text = $data['text'];
        $caption = $data['caption'];

        if (empty($text)) {
            return '';
        }

        $html = '<blockquote class="kc-quote-block">';
        $html .= '<p class="kc-quote-text">' . $text . '</p>';

        if (!empty($caption)) {
            $html .= '<cite class="kc-quote-caption">' . $caption . '</cite>';
        }

        $html .= '</blockquote>';

        return $html;
    }
}
