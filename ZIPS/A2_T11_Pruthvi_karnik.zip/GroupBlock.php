<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Layout;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\BlockRegistry;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * GroupBlock
 *
 * Wrapper container for grouping arbitrary content blocks
 * with layout settings.
 */
final class GroupBlock extends AbstractBlock
{
    public const ALIGNS = [
        'start',
        'center',
        'end',
        'between',
    ];

    public const GAPS = [
        'none',
        'sm',
        'md',
        'lg',
    ];

    public function type(): string
    {
        return 'group';
    }

    public function label(): string
    {
        return 'Group Container';
    }

    public function sanitize(array $data): array
    {
        $align = $this->enum(
            $data['align'] ?? 'start',
            self::ALIGNS,
            'start'
        );

        $gap = $this->enum(
            $data['gap'] ?? 'md',
            self::GAPS,
            'md'
        );

        $blocks = is_array($data['blocks'] ?? null)
            ? $data['blocks']
            : [];

        return [
            'align'  => $align,
            'gap'    => $gap,
            'blocks' => $blocks,
        ];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(
            is_array($block['data'] ?? null)
                ? $block['data']
                : []
        );

        $blockId = Html::escape(
            (string) ($block['id'] ?? '')
        );

        $classNames = sprintf(
            'kc-block kc-block-group kc-align-%s kc-gap-%s',
            Html::escape($data['align']),
            Html::escape($data['gap'])
        );

        $html = sprintf(
            '<div class="%s" data-block-id="%s" data-block-type="group">',
            $classNames,
            $blockId
        );

        foreach ($data['blocks'] as $childBlock) {
            if (!is_array($childBlock)) {
                continue;
            }

            $childType = (string) ($childBlock['type'] ?? '');

            if ($childType === '') {
                continue;
            }

            if (!BlockRegistry::has($childType)) {
                continue;
            }

            $childHandler = BlockRegistry::get($childType);

            $html .= $childHandler->render(
                [
                    'id' => (string) ($childBlock['id'] ?? ''),
                    'type' => $childType,
                    'data' => is_array($childBlock['data'] ?? null)
                        ? $childBlock['data']
                        : [],
                ],
                $ctx
            );
        }

        $html .= '</div>';

        return $html;
    }
}