/**
 * Task A2-T03: Nested Bulleted List Block
 * Custom professional implementation for SOI Knowledge Center
 */
class ListBlock {
  static get toolbox() {
    return {
      title: 'List',
      icon: '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>'
    };
  }

  static get isReadOnlySupported() {
    return true;
  }

  static get sanitize() {
    return {
      content: {
        b: true,
        i: true,
        u: true,
        s: true,
        a: { href: true },
        code: true
      }
    };
  }

  constructor({ data, api, readOnly }) {
    this.api = api;
    this.readOnly = readOnly;
    this.data = {
      style: data.style || 'unordered',
      items: data.items || []
    };
    
    // CSS classes for styling matching kc-editor.css tokens
    this.CSS = {
      baseBlock: this.api.styles.block,
      wrapper: 'kc-tool-list',
      list: 'kc-list-tool-ul',
      item: 'kc-list-tool-li'
    };
    
    this.nodes = {
      wrapper: null,
      list: null
    };
  }

  render() {
    this.nodes.wrapper = document.createElement('div');
    this.nodes.wrapper.classList.add(this.CSS.baseBlock, this.CSS.wrapper);
    
    this.nodes.list = document.createElement('ul');
    this.nodes.list.classList.add(this.CSS.list);
    
    if (this.data.items.length === 0) {
      this.nodes.list.appendChild(this._createItem());
    } else {
      this.nodes.list.appendChild(this._renderItems(this.data.items));
    }
    
    this.nodes.wrapper.appendChild(this.nodes.list);
    
    if (!this.readOnly) {
      this.nodes.wrapper.addEventListener('keydown', (e) => {
        const item = e.target.closest(`.${this.CSS.item}`);
        if (!item) return;

        if (e.key === 'Enter') {
          this._handleEnter(e, item);
        } else if (e.key === 'Backspace') {
          this._handleBackspace(e, item);
        } else if (e.key === 'Tab') {
          if (e.shiftKey) {
            this._handleShiftTab(e, item);
          } else {
            this._handleTab(e, item);
          }
        }
      });
    }

    return this.nodes.wrapper;
  }
  
  _renderItems(items) {
    const fragment = document.createDocumentFragment();
    items.forEach(itemData => {
      const item = this._createItem(itemData.content);
      if (itemData.items && itemData.items.length > 0) {
        const subList = document.createElement('ul');
        subList.classList.add(this.CSS.list);
        subList.appendChild(this._renderItems(itemData.items));
        item.appendChild(subList);
      }
      fragment.appendChild(item);
    });
    return fragment;
  }

  _createItem(content = '') {
    const item = document.createElement('li');
    item.classList.add(this.CSS.item);
    
    const div = document.createElement('div');
    div.contentEditable = !this.readOnly;
    div.innerHTML = content;
    
    item.appendChild(div);
    return item;
  }

  _handleEnter(e, item) {
    e.preventDefault();
    const contentDiv = item.firstElementChild;
    
    if (contentDiv.textContent.trim() === '' && !item.querySelector('ul')) {
      // Empty item: unindent or exit block
      if (item.parentNode !== this.nodes.list) {
        this._handleShiftTab(e, item);
      } else {
        // We are at root. Exit to new block.
        const currentIndex = this.api.blocks.getCurrentBlockIndex();
        item.remove();
        this.api.blocks.insert();
        this.api.caret.setToBlock(currentIndex + 1, 'start');
      }
    } else {
      // Create new item
      const newItem = this._createItem();
      item.parentNode.insertBefore(newItem, item.nextSibling);
      this._focus(newItem);
    }
  }

  _handleBackspace(e, item) {
    const contentDiv = item.firstElementChild;
    const isAtStart = window.getSelection().anchorOffset === 0;
    
    if (isAtStart && contentDiv.textContent.trim() === '' && !item.querySelector('ul')) {
      e.preventDefault();
      const prev = item.previousElementSibling;
      if (prev) {
        item.remove();
        this._focus(prev, true);
      } else {
        if (item.parentNode !== this.nodes.list) {
          this._handleShiftTab(e, item);
        } else if (this.nodes.list.children.length === 1) {
          // Delete entire block
          this.api.blocks.delete();
        }
      }
    }
  }

  _handleTab(e, item) {
    e.preventDefault();
    const prev = item.previousElementSibling;
    if (prev) {
      let ul = prev.querySelector('ul');
      if (!ul) {
        ul = document.createElement('ul');
        ul.classList.add(this.CSS.list);
        prev.appendChild(ul);
      }
      ul.appendChild(item);
      this._focus(item);
    }
  }

  _handleShiftTab(e, item) {
    e.preventDefault();
    const currentList = item.parentNode;
    if (currentList !== this.nodes.list) {
      const parentItem = currentList.parentNode;
      parentItem.parentNode.insertBefore(item, parentItem.nextSibling);
      
      if (currentList.children.length === 0) {
        currentList.remove();
      }
      this._focus(item);
    }
  }

  _focus(item, atEnd = false) {
    const contentDiv = item.firstElementChild;
    contentDiv.focus();
    if (atEnd) {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(contentDiv);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  }

  save(blockContent) {
    return {
      style: this.data.style,
      items: this._extractItems(this.nodes.list)
    };
  }
  
  _extractItems(listNode) {
    const items = [];
    const children = Array.from(listNode.children).filter(child => child.tagName === 'LI');
    
    children.forEach(li => {
      const contentDiv = li.querySelector('div[contenteditable]');
      const content = contentDiv ? contentDiv.innerHTML : '';
      
      const subList = li.querySelector('ul');
      const subItems = subList ? this._extractItems(subList) : [];
      
      if (content.trim() !== '' || subItems.length > 0) {
        items.push({
          content: content,
          items: subItems
        });
      }
    });
    
    return items;
  }
}

window.ListBlock = ListBlock; // Expose globally if required
