<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\BlockType;
use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T15: Tabs Component
 * 
 * Content switcher tabs block (e.g., Windows / macOS / Linux instructions)
 * with accessible ARIA tablist/tab/tabpanel markup, stable unique IDs,
 * and keyboard navigation hooks.
 * 
 * @author Saurabh
 */
final class TabsBlock extends AbstractBlock implements BlockType
{
    private const MAX_PANELS = 20;

    public function type(): string
    {
        return 'tabs';
    }

    public function label(): string
    {
        return 'Tabs';
    }

    /**
     * Sanitize stored data payload.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{title: string, content: string}>}
     */
    public function sanitize(array $data): array
    {
        return [
            'items' => self::sanitizeItems($data['items'] ?? [])
        ];
    }

    /**
     * Validate block data constraints.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > self::MAX_PANELS) {
            return ['Tabs cannot contain more than ' . self::MAX_PANELS . ' panels.'];
        }
        return [];
    }

    /**
     * Render semantic HTML output with accessible ARIA roles and tab-panel connections.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(is_array($block['data'] ?? null) ? $block['data'] : []);
        $items = $data['items'];
        if ($items === []) {
            return '';
        }

        $rawId = (string) ($block['id'] ?? 'tabs_' . bin2hex(random_bytes(4)));
        $instanceId = preg_replace('/[^a-zA-Z0-9_-]/', '', $rawId);
        if ($instanceId === '') {
            $instanceId = 'kc_tabs_' . mt_rand(1000, 9999);
        }
        $escapedId = Html::escape($instanceId);

        $html = '<div class="kc-block kc-block-tabs" data-block-id="' . $escapedId . '" data-tabs-id="' . $escapedId . '">';
        
        // 1. Tablist Header with Tab buttons
        $html .= '<div class="kc-tabs" role="tablist" aria-label="Tab navigation">';
        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = (string) ($item['title'] ?? '');
            if ($title === '') {
                $title = 'Tab ' . ($i + 1);
            }

            $tabId = $escapedId . '-tab-' . $i;
            $panelId = $escapedId . '-panel-' . $i;
            $isActive = ($i === 0);
            $selectedAttr = $isActive ? 'true' : 'false';
            $tabIndex = $isActive ? '0' : '-1';
            $activeClass = $isActive ? ' is-active' : '';

            $html .= '<button type="button" class="kc-tabs-tab' . $activeClass . '" role="tab" id="' . $tabId . '" aria-controls="' . $panelId . '" aria-selected="' . $selectedAttr . '" tabindex="' . $tabIndex . '" data-kc-tab="' . $i . '">' . Html::escape($title) . '</button>';
        }
        $html .= '</div>';

        // 2. Tab Panels Container
        $html .= '<div class="kc-tabs-panels">';
        foreach ($items as $i => $item) {
            if (!is_array($item)) {
                continue;
            }

            $content = (string) ($item['content'] ?? '');
            $tabId = $escapedId . '-tab-' . $i;
            $panelId = $escapedId . '-panel-' . $i;
            $isActive = ($i === 0);
            $activeClass = $isActive ? ' is-active' : '';
            $hiddenAttr = $isActive ? '' : ' hidden';

            $html .= '<div class="kc-tabs-panel' . $activeClass . '" role="tabpanel" id="' . $panelId . '" aria-labelledby="' . $tabId . '" tabindex="0"' . $hiddenAttr . ' data-kc-panel="' . $i . '">';
            $html .= $content;
            $html .= '</div>';
        }
        $html .= '</div>';

        $html .= '</div>';

        return $html;
    }

    /**
     * Sanitize list of tab items.
     *
     * @param mixed $items
     * @return list<array{title: string, content: string}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = Html::plainText(Html::clampText((string) ($item['title'] ?? ''), 150));
            $content = Html::sanitizeInline((string) ($item['content'] ?? ''), 30000);

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $out[] = [
                'title' => $title !== '' ? $title : 'Tab',
                'content' => $content,
            ];

            if (count($out) >= self::MAX_PANELS) {
                break;
            }
        }

        return $out;
    }
}
