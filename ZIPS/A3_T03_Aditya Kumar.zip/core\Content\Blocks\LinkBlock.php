<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Media\LinkCardBlock as MediaLinkCardBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\LinkBlock
 */
final class LinkBlock extends MediaLinkCardBlock
{
}
