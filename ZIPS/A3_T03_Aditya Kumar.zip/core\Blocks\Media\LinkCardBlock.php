<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Media;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T03: Link Card Block renderer and sanitizer.
 * Bookmark card block displaying URL title, snippet description, and target URL (protected against SSRF).
 * Acceptance Criteria: Link card renders bookmark tile. Avoids server-side background HTTP requests to untrusted internal IP ranges.
 */
class LinkCardBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'link';
    }

    public function label(): string
    {
        return 'Link Card';
    }

    public function sanitize(array $data): array
    {
        $meta = is_array($data['meta'] ?? null) ? $data['meta'] : [];
        $urlRaw = (string) ($data['url'] ?? $data['link'] ?? '');
        $url = self::isSafePublicUrl($urlRaw) ? Html::sanitizeUrl($urlRaw) : '';
        
        $title = Html::plainText((string) ($data['title'] ?? $meta['title'] ?? ''));
        $description = Html::plainText((string) ($data['description'] ?? $data['text'] ?? $meta['description'] ?? ''));
        
        return [
            'url' => $url,
            'title' => Html::clampText($title, 300),
            'description' => Html::clampText($description, 1000),
        ];
    }

    public function validate(array $data): array
    {
        $url = (string) ($data['url'] ?? '');
        if ($url !== '' && !self::isSafePublicUrl($url)) {
            return ['Target URL points to a restricted internal address or unsupported protocol.'];
        }
        return [];
    }

    /**
     * Validates that a URL uses http/https and does not resolve to an internal/private IP range (SSRF protection).
     */
    public static function isSafePublicUrl(string $url): bool
    {
        $url = trim($url);
        if ($url === '') {
            return false;
        }
        $parsed = parse_url($url);
        if (!$parsed || empty($parsed['scheme']) || empty($parsed['host'])) {
            return false;
        }
        $scheme = strtolower($parsed['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return false;
        }
        $host = strtolower($parsed['host']);
        if ($host === 'localhost' || $host === '127.0.0.1' || $host === '::1' || $host === '0.0.0.0') {
            return false;
        }
        if (preg_match('/^(127\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|169\.254\.)/', $host)) {
            return false;
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return (bool) filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
        }
        return true;
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $url = (string) ($data['url'] ?? '');
        if (!self::isSafePublicUrl($url)) {
            return '';
        }
        $title = Html::plainText((string) ($data['title'] ?? ''));
        if ($title === '') {
            $title = $url;
        }
        $description = Html::plainText((string) ($data['description'] ?? ''));

        $host = parse_url($url, PHP_URL_HOST) ?: '';
        $domain = preg_replace('/^www\./', '', strtolower((string) $host));

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $html = '<div class="kc-block kc-block-link-card kc-bookmark-card"' . $dataAttr . '>';
        $html .= '<a class="kc-link-card-anchor" href="' . Html::escape($url) . '" target="_blank" rel="noopener noreferrer" aria-label="Visit ' . Html::escape($title) . '">';
        $html .= '<div class="kc-link-card-content">';
        $html .= '<strong class="kc-link-card-title">' . Html::escape($title) . '</strong>';
        if ($description !== '') {
            $html .= '<p class="kc-link-card-description">' . Html::escape($description) . '</p>';
        }
        $html .= '<span class="kc-link-card-domain">';
        $html .= '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:3px; vertical-align: middle;"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
        $html .= Html::escape($domain);
        $html .= '</span>';
        $html .= '</div>';
        $html .= '</a>';
        $html .= '</div>';
        return $html;
    }
}
