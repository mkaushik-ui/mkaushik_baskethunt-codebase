(function (global) {
  'use strict';

  function isSafePublicUrl(url) {
    if (!url) return false;
    const str = url.trim();
    try {
      const u = new URL(str);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
      const host = u.hostname.toLowerCase();
      if (host === 'localhost' || host === '127.0.0.1' || host === '::1' || host === '0.0.0.0') return false;
      if (/^(127\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|169\.254\.)/.test(host)) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Task A3-T03: Link Card Block Editor.js Tool.
   * Bookmark card block displaying URL title, snippet description, and target URL (protected against SSRF).
   * Acceptance Criteria: Link card renders bookmark tile. Avoids server-side background HTTP requests to untrusted internal IP ranges.
   */
  class KcLink {
    static get toolbox() {
      return {
        title: 'Link Card',
        icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>'
      };
    }

    static get isReadOnlySupported() { return true; }

    static get sanitize() {
      return {
        url: {},
        title: {},
        description: {}
      };
    }

    constructor({ data, api, readOnly, config }) {
      this.api = api;
      this.readOnly = !!readOnly;
      this.config = config || {};

      const meta = (data && data.meta) || {};
      this.data = {
        url: (data && (data.url || data.link)) || '',
        title: (data && data.title) || meta.title || '',
        description: (data && (data.description || data.text)) || meta.description || ''
      };

      this.nodes = {};
    }

    render() {
      const wrap = document.createElement('div');
      wrap.className = 'kc-tool kc-tool-link-card kc-block-link-card-tool';
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'Link Card Block Editor');

      wrap.innerHTML = [
        '<div class="kc-link-card-editor" style="border: 1px solid var(--soi-border, var(--kc-line, #e2e8f0)); border-radius: var(--soi-radius, var(--kc-radius, 8px)); background: var(--soi-surface, #ffffff); padding: 0.85rem; font-family: Inter, sans-serif;">',
          '<div class="kc-link-card-header" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; margin-bottom: 0.75rem;">',
            '<div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; font-weight: 700; color: var(--kc-text, #0f172a);">',
              '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
              '<span>Link Card Bookmark</span>',
            '</div>',
            '<div class="kc-ssrf-badge" style="font-size: 0.65rem; font-weight: 750; background: #ecfdf5; color: #047857; padding: 0.2rem 0.45rem; border-radius: 4px; border: 1px solid #a7f3d0;">SSRF Protected</div>',
          '</div>',

          '<div class="kc-link-card-tile-preview" style="border: 1px solid var(--kc-line, #e2e8f0); border-radius: 6px; background: #f8fafc; padding: 0.75rem; margin-bottom: 0.75rem;">',
          '</div>',

          '<div class="kc-ssrf-warning" hidden style="font-size: 0.74rem; color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; padding: 0.45rem 0.6rem; border-radius: 5px; margin-bottom: 0.6rem;">',
            '⚠️ Warning: Internal/local IP addresses and unsafe protocols are blocked for security.',
          '</div>',

          '<div class="kc-link-card-controls" style="display: grid; gap: 0.5rem;">',
            '<div>',
              '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Target URL</label>',
              '<input class="kc-items-input kc-link-url-input" type="url" placeholder="https://example.com/article" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Target URL">',
            '</div>',
            '<div class="kc-field-row" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 0.5rem;">',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Card Title</label>',
                '<input class="kc-items-input kc-link-title-input" type="text" placeholder="Article Title" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Card title">',
              '</div>',
              '<div>',
                '<label style="display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--kc-muted, #64748b); margin-bottom: 0.25rem;">Snippet Description</label>',
                '<input class="kc-items-input kc-link-desc-input" type="text" placeholder="Short description of link" style="width: 100%; font-family: Inter, sans-serif;" aria-label="Snippet description">',
              '</div>',
            '</div>',
          '</div>',
        '</div>'
      ].join('');

      this.nodes = {
        wrap,
        preview: wrap.querySelector('.kc-link-card-tile-preview'),
        warning: wrap.querySelector('.kc-ssrf-warning'),
        urlInput: wrap.querySelector('.kc-link-url-input'),
        titleInput: wrap.querySelector('.kc-link-title-input'),
        descInput: wrap.querySelector('.kc-link-desc-input')
      };

      this.nodes.urlInput.value = this.data.url;
      this.nodes.titleInput.value = this.data.title;
      this.nodes.descInput.value = this.data.description;

      this.paintCard();

      if (!this.readOnly) {
        this.bindEvents();
      } else {
        this.nodes.urlInput.disabled = true;
        this.nodes.titleInput.disabled = true;
        this.nodes.descInput.disabled = true;
      }

      return wrap;
    }

    bindEvents() {
      this.nodes.urlInput.addEventListener('input', () => {
        this.data.url = this.nodes.urlInput.value.trim();
        this.paintCard();
      });

      this.nodes.titleInput.addEventListener('input', () => {
        this.data.title = this.nodes.titleInput.value.trim();
        this.paintCard();
      });

      this.nodes.descInput.addEventListener('input', () => {
        this.data.description = this.nodes.descInput.value.trim();
        this.paintCard();
      });
    }

    paintCard() {
      const url = this.data.url;
      const isSafe = !url || isSafePublicUrl(url);

      if (this.nodes.warning) {
        this.nodes.warning.hidden = isSafe;
      }

      const title = this.data.title || url || 'Bookmark Link Tile';
      const desc = this.data.description || '';

      let domain = '';
      try {
        if (url) {
          domain = new URL(url).hostname.replace(/^www\./, '');
        }
      } catch (e) {
        domain = 'web';
      }

      this.nodes.preview.innerHTML = [
        '<div style="display: flex; flex-direction: column; gap: 0.35rem;">',
          '<strong style="font-size: 0.88rem; color: #2563eb; line-height: 1.3;">' + title + '</strong>',
          desc ? '<p style="margin: 0; font-size: 0.76rem; color: var(--kc-muted, #64748b); line-height: 1.4;">' + desc + '</p>' : '',
          '<div style="display: flex; align-items: center; gap: 0.25rem; font-size: 0.7rem; color: #475569; margin-top: 0.2rem;">',
            '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
            '<span>' + (domain || 'external-link') + '</span>',
          '</div>',
        '</div>'
      ].join('');
    }

    save() {
      return {
        url: this.nodes.urlInput ? this.nodes.urlInput.value.trim() : this.data.url,
        title: this.nodes.titleInput ? this.nodes.titleInput.value.trim() : this.data.title,
        description: this.nodes.descInput ? this.nodes.descInput.value.trim() : this.data.description
      };
    }
  }

  if (global.KcEditorRegistry) {
    global.KcEditorRegistry.register('link', KcLink, { label: 'Link Card', group: 'media' });
  }
  global.KcLink = KcLink;
})(window);
