<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Blocks\Technical\TableBlock as TechnicalTableBlock;

/**
 * Forwarding class for SOI\Core\Content\Blocks\TableBlock
 */
final class TableBlock extends TechnicalTableBlock
{
}
