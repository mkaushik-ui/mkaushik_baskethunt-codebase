<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Technical;

use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T04: Table Block renderer and sanitizer.
 * Grid table block with dynamic row/column addition, header row toggle, and responsive horizontal scroll wrapper.
 * Acceptance Criteria: Renders <table><thead>...</thead><tbody>...</tbody></table> wrapped in .kc-table-wrap.
 */
class TableBlock extends AbstractBlock
{
    private const MAX_ROWS = 80;
    private const MAX_COLS = 16;

    public function type(): string
    {
        return 'table';
    }

    public function label(): string
    {
        return 'Table';
    }

    public function sanitize(array $data): array
    {
        $rows = is_array($data['content'] ?? null) ? $data['content'] : [];
        $normalized = [];
        foreach (array_slice(array_values($rows), 0, self::MAX_ROWS) as $row) {
            if (!is_array($row)) {
                continue;
            }
            $cells = [];
            foreach (array_slice(array_values($row), 0, self::MAX_COLS) as $cell) {
                $cells[] = $this->inline(is_scalar($cell) ? (string) $cell : '', 4000);
            }
            if ($cells !== []) {
                $normalized[] = $cells;
            }
        }
        return [
            'withHeadings' => !empty($data['withHeadings']),
            'content' => $normalized,
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $data = is_array($block['data'] ?? null) ? $block['data'] : [];
        $rows = $data['content'] ?? [];
        if (!is_array($rows) || $rows === []) {
            return '';
        }
        $withHeadings = !empty($data['withHeadings']);

        $blockId = isset($block['id']) ? (string) $block['id'] : '';
        $dataAttr = $blockId !== '' ? ' data-block-id="' . Html::escape($blockId) . '"' : '';

        $html = '<div class="kc-block kc-block-table-wrap kc-table-wrap"' . $dataAttr . '>';
        $html .= '<table class="kc-block-table">';

        $inTbody = false;

        foreach (array_values($rows) as $i => $row) {
            if (!is_array($row)) {
                continue;
            }
            $isHead = $withHeadings && $i === 0;

            if ($isHead) {
                $html .= '<thead><tr>';
                foreach ($row as $cell) {
                    $html .= '<th>' . (string) $cell . '</th>';
                }
                $html .= '</tr></thead>';
            } else {
                if ($withHeadings && !$inTbody) {
                    $html .= '<tbody>';
                    $inTbody = true;
                } elseif (!$withHeadings && !$inTbody && $i === 0) {
                    $html .= '<tbody>';
                    $inTbody = true;
                }

                $html .= '<tr>';
                foreach ($row as $cell) {
                    $html .= '<td>' . (string) $cell . '</td>';
                }
                $html .= '</tr>';
            }
        }

        if ($inTbody) {
            $html .= '</tbody>';
        }

        $html .= '</table></div>';
        return $html;
    }
}
