class CalloutBlock {
  static get toolbox() {
    return {
      title: 'Callout',
      icon: '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
    };
  }

  constructor({ data, api }) {
    this.api = api;
    this.data = {
      text: data.text || '',
      tone: data.tone || 'info'
    };
    
    // Define the exact tones matching backend requirements
    this.tones = [
      { name: 'info', icon: '&#8505;', label: 'Info (Blue)' },
      { name: 'note', icon: '&#9998;', label: 'Note (Slate)' },
      { name: 'tip', icon: '&#128161;', label: 'Tip (Violet)' },
      { name: 'warning', icon: '&#9888;', label: 'Warning (Amber)' },
      { name: 'danger', icon: '&#9763;', label: 'Danger (Red)' },
      { name: 'success', icon: '&#10004;', label: 'Success (Green)' }
    ];
    
    this.nodes = {
      wrapper: null,
      text: null
    };
  }

  render() {
    this.nodes.wrapper = document.createElement('div');
    this.nodes.wrapper.classList.add('kc-callout-tool', `kc-callout-tool-${this.data.tone}`);
    
    this.nodes.text = document.createElement('div');
    this.nodes.text.classList.add('kc-callout-tool-text');
    this.nodes.text.contentEditable = true;
    this.nodes.text.dataset.placeholder = 'Type callout notice...';
    this.nodes.text.innerHTML = this.data.text;
    
    this.nodes.wrapper.appendChild(this.nodes.text);
    
    return this.nodes.wrapper;
  }

  renderSettings() {
    const wrapper = document.createElement('div');
    
    this.tones.forEach(tune => {
      let button = document.createElement('div');
      
      // Hook into native EditorJS settings button CSS
      button.classList.add(this.api.styles.settingsButton);
      button.innerHTML = tune.icon;
      button.title = tune.label;
      
      // Highlight active tone
      if (this.data.tone === tune.name) {
        button.classList.add(this.api.styles.settingsButtonActive);
      }
      
      button.addEventListener('click', () => {
        // High-performance active state toggle (avoiding full array iteration)
        const activeClass = this.api.styles.settingsButtonActive;
        wrapper.querySelector(`.${activeClass}`)?.classList.remove(activeClass);
        button.classList.add(activeClass);
        
        // Update block tone CSS on the fly for live preview
        this.nodes.wrapper.classList.remove(`kc-callout-tool-${this.data.tone}`);
        this.data.tone = tune.name;
        this.nodes.wrapper.classList.add(`kc-callout-tool-${this.data.tone}`);
      });
      
      wrapper.appendChild(button);
    });
    
    return wrapper;
  }

  save(blockContent) {
    // Highly robust extraction method (resists DOM detachment errors)
    const textNode = blockContent.querySelector('.kc-callout-tool-text');
    return {
      text: textNode ? textNode.innerHTML : '',
      tone: this.data.tone
    };
  }
}
