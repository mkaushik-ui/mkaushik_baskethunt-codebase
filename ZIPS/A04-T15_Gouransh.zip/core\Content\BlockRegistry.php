<?php
declare(strict_types=1);

namespace SOI\Core\Content;

use SOI\Core\Content\Contracts\BlockProviderInterface;
use SOI\Core\Content\Blocks\AccordionBlock;
use SOI\Core\Content\Blocks\ApiEndpointBlock;
use SOI\Core\Content\Blocks\CalloutBlock;
use SOI\Core\Content\Blocks\CardsBlock;
use SOI\Core\Content\Blocks\CodeBlock;
use SOI\Core\Content\Blocks\CodeGroupBlock;
use SOI\Core\Content\Blocks\ColumnsBlock;
use SOI\Core\Content\Blocks\DefinitionListBlock;
use SOI\Core\Content\Blocks\DividerBlock;
use SOI\Core\Content\Blocks\FaqBlock;
use SOI\Core\Content\Blocks\FileBlock;
use SOI\Core\Content\Blocks\GroupBlock;
use SOI\Core\Content\Blocks\HeadingBlock;
use SOI\Core\Content\Blocks\ImageBlock;
use SOI\Core\Content\Blocks\KbdBlock;
use SOI\Core\Content\Blocks\KeyValuesBlock;
use SOI\Core\Content\Blocks\LinkBlock;
use SOI\Core\Content\Blocks\ListBlock;
use SOI\Core\Content\Blocks\ParagraphBlock;
use SOI\Core\Content\Blocks\QuoteBlock;
use SOI\Core\Content\Blocks\ReusableBlock;
use SOI\Core\Content\Blocks\StatusBadgeBlock;
use SOI\Core\Content\Blocks\StepsBlock;
use SOI\Core\Content\Blocks\TableBlock;
use SOI\Core\Content\Blocks\TabsBlock;
use SOI\Core\Content\Blocks\UnknownBlock;
use SOI\Core\Hook;

/**
 * Modular block/tool registry and provider aggregator.
 * Single source of truth for Editor.js tools, component library, patterns, and slash menu.
 */
final class BlockRegistry
{
    /** @var array<string, BlockType|BlockProviderInterface> */
    private static array $types = [];

    private static bool $booted = false;

    public static function boot(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        // Register default baseline built-in blocks
        self::registerBuiltinDefaults();

        // Auto-discover modular block provider classes in core/Content/Blocks/ subdirectories
        self::discoverProviders(__DIR__ . '/Blocks');

        if (class_exists(Hook::class)) {
            Hook::doAction('soi_register_editor_blocks', self::class);
        }
    }

    /**
     * Register a block type implementing BlockType or BlockProviderInterface.
     */
    public static function register(BlockType|BlockProviderInterface $block): void
    {
        self::$types[$block->type()] = $block;
    }

    /**
     * Alias for registering modular block provider.
     */
    public static function registerProvider(BlockProviderInterface $provider): void
    {
        self::register($provider);
    }

    public static function has(string $type): bool
    {
        self::boot();
        return isset(self::$types[$type]);
    }

    public static function get(string $type): BlockType|BlockProviderInterface
    {
        self::boot();
        return self::$types[$type] ?? new UnknownBlock($type);
    }

    /**
     * @return array<string, BlockType|BlockProviderInterface>
     */
    public static function all(): array
    {
        self::boot();
        return self::$types;
    }

    /**
     * Catalog for the editor UI (slash menu, component library, inspector, tests).
     *
     * @return list<array<string, mixed>>
     */
    public static function catalog(bool $includeLegacy = false): array
    {
        self::boot();
        $items = [];

        foreach (self::$types as $block) {
            // Skip LegacyBlock unless requested
            if (!$includeLegacy && $block->type() === 'legacy') {
                continue;
            }

            if ($block->type() === 'list') {
                $items[] = self::item('list-unordered', 'list', 'Bulleted list', 'basic', 'Unordered list', 'ul bullet item', ['style' => 'unordered'], '•');
                $items[] = self::item('list-ordered', 'list', 'Numbered list', 'basic', 'Ordered list', 'ol number item', ['style' => 'ordered'], '1.');
                $items[] = self::item('list-checklist', 'list', 'Checklist', 'basic', 'Interactive checklist', 'check task todo box', ['style' => 'checklist'], '☑');
            }

            if ($block instanceof Contracts\ProviderMetadataInterface) {
                $items[] = self::item(
                    $block->type(),
                    $block->editorType(),
                    $block->label(),
                    $block->group(),
                    $block->description(),
                    $block->keywords(),
                    $block->data(),
                    $block->icon()
                );
            }
        }

        if (class_exists(Hook::class)) {
            $items = Hook::applyFilters('soi_editor_block_catalog', $items);
        }

        return $items;
    }

    /**
     * Register default built-in block types.
     */
    private static function registerBuiltinDefaults(): void
    {
        // Hardcoded lists removed in favor of dynamic discovery
    }

    /**
     * Auto-discover block provider classes in subdirectories.
     */
    private static function discoverProviders(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $files = glob($directory . '/*Block.php');
        if (!$files) {
            return;
        }

        foreach ($files as $file) {
            $className = basename($file, '.php');
            $fqcn = "SOI\\Core\\Content\\Blocks\\{$className}";
            require_once $file;
            if (class_exists($fqcn) && !isset(self::$types[strtolower($className)])) {
                try {
                    $ref = new \ReflectionClass($fqcn);
                    if (!$ref->isAbstract() && ($ref->implementsInterface(BlockProviderInterface::class) || $ref->implementsInterface(BlockType::class))) {
                        /** @var BlockType|BlockProviderInterface $instance */
                        $instance = new $fqcn();
                        self::register($instance);
                    }
                } catch (\Throwable $e) {
                    // Safe skip on instantiation failure
                }
            }
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private static function item(
        string $id,
        string $editorType,
        string $label,
        string $group,
        string $description,
        string $keywords,
        array $data = [],
        string $icon = '',
        ?string $alias = null,
    ): array {
        return [
            'id' => $alias ?? $id,
            'type' => $id,
            'editorType' => $editorType,
            'label' => $label,
            'group' => $group,
            'description' => $description,
            'keywords' => $keywords,
            'icon' => $icon,
            'data' => $data,
        ];
    }
}
