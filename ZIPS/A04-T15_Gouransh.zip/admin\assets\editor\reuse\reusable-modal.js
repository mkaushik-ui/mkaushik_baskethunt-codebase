/**
 * Task T7: Reusable Block Insertion Modal.
 */
(function (global) {
  'use strict';

  class ReusableModal {
    constructor() {
      this.modalEl = null;
    }

    open(onSelect) {
      console.log('[ReusableModal] Opening reusable blocks library picker.');
      // Simple fallback UI for skeleton
      const id = prompt("Enter Reusable Block ID (e.g. 123):");
      if (id && !isNaN(parseInt(id, 10))) {
        if (typeof onSelect === 'function') {
          onSelect(parseInt(id, 10));
        }
      }
    }
  }

  global.KcReusableModal = ReusableModal;
})(typeof window !== 'undefined' ? window : this);
