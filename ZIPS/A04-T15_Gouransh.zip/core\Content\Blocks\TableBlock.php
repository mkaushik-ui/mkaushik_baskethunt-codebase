<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

final class TableBlock extends AbstractBlock
{
    private const MAX_ROWS = 80;
    private const MAX_COLS = 16;

    public function type(): string
    {
        return 'table';
    }

    public function label(): string
    {
        return 'Table';
    }

    public function sanitize(array $data): array
    {
        $rows = is_array($data['content'] ?? null) ? $data['content'] : [];
        $normalized = [];
        foreach (array_slice(array_values($rows), 0, self::MAX_ROWS) as $row) {
            if (!is_array($row)) {
                continue;
            }
            $cells = [];
            foreach (array_slice(array_values($row), 0, self::MAX_COLS) as $cell) {
                $cells[] = $this->inline(is_scalar($cell) ? (string) $cell : '', 4000);
            }
            if ($cells !== []) {
                $normalized[] = $cells;
            }
        }
        
        $alignments = is_array($data['alignments'] ?? null) ? $data['alignments'] : [];
        $validAlignments = [];
        foreach (array_slice(array_values($alignments), 0, self::MAX_COLS) as $align) {
            $validAlignments[] = $this->enum(is_scalar($align) ? (string) $align : 'left', ['left', 'center', 'right'], 'left');
        }

        return [
            'withHeadings' => !empty($data['withHeadings']),
            'content' => $normalized,
            'alignments' => $validAlignments,
        ];
    }

    public function validate(array $data): array
    {
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $rows = $block['data']['content'] ?? [];
        if (!is_array($rows) || $rows === []) {
            return '';
        }
        $withHeadings = !empty($block['data']['withHeadings']);
        $alignments = is_array($block['data']['alignments'] ?? null) ? $block['data']['alignments'] : [];
        
        $html = '<div class="kc-block kc-block-table-wrap" style="overflow-x: auto;" data-block-id="' . Html::escape($block['id']) . '">';
        $html .= '<table class="kc-block-table">';
        foreach (array_values($rows) as $i => $row) {
            if (!is_array($row)) {
                continue;
            }
            $isHead = $withHeadings && $i === 0;
            $html .= $isHead ? '<thead><tr>' : '<tr>';
            $cellTag = $isHead ? 'th' : 'td';
            
            $colIndex = 0;
            foreach ($row as $cell) {
                $align = $alignments[$colIndex] ?? 'left';
                $style = $align !== 'left' ? ' style="text-align: ' . Html::escape($align) . ';"' : '';
                $html .= '<' . $cellTag . $style . '>' . (string) $cell . '</' . $cellTag . '>';
                $colIndex++;
            }
            $html .= $isHead ? '</tr></thead><tbody>' : '</tr>';
        }
        if ($withHeadings && count($rows) > 1) {
            $html .= '</tbody>';
        }
        return $html . '</table></div>';
    }

    public function description(): string
    {
        return 'Rows and columns grid';
    }

    public function icon(): string
    {
        return '▦';
    }
    public function defaultData(): array
    {
        return [
  'withHeadings' => true,
];
    }

    public function category(): string
    {
        return 'structured';
    }
}


