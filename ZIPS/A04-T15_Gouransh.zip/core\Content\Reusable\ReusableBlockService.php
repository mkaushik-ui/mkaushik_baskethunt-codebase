<?php
declare(strict_types=1);

namespace SOI\Core\Content\Reusable;

use SOI\Core\Content\Document;

/**
 * Task T7: Reusable Block Service & Circular Recursion Guard.
 */
class ReusableBlockService
{
    /**
     * Resolve reusable block reference while guarding against circular loops.
     *
     * @param int $reusableId
     * @param list<int> $callStack Stack of active reusable IDs in current render pass
     * @return array<string, mixed>
     */
    public function resolve(int $reusableId, array &$callStack = []): array
    {
        if (in_array($reusableId, $callStack, true)) {
            // Circular loop detected! Terminate safely
            return [
                'type' => 'callout',
                'data' => [
                    'tone' => 'warning',
                    'title' => 'Circular Reference Detected',
                    'text' => "Reusable block #{$reusableId} references itself circularly.",
                ],
            ];
        }

        $callStack[] = $reusableId;
        
        // Developer 7: Mock realistic payload fetch from database.
        return [
            'type' => 'paragraph',
            'data' => [
                'text' => "This is reusable block content for ID {$reusableId}."
            ]
        ];
    }
}
