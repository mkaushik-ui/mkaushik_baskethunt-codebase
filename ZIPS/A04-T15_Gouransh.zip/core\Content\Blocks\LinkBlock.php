<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

final class LinkBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'link';
    }

    public function editorType(): string
    {
        return 'linkCard';
    }

    public function label(): string
    {
        return 'Link';
    }

    public function sanitize(array $data): array
    {
        $meta = is_array($data['meta'] ?? null) ? $data['meta'] : [];
        $url = Html::sanitizeUrl((string) ($data['url'] ?? $data['link'] ?? ''));
        $title = Html::plainText((string) ($data['title'] ?? $meta['title'] ?? ''));
        $text = $this->inline($data['text'] ?? $meta['description'] ?? '', 4000);
        $imageUrl = Html::sanitizeUrl((string) ($data['imageUrl'] ?? $meta['image'] ?? ''));
        return [
            'url' => $url,
            'title' => Html::clampText($title, 300),
            'text' => $text,
            'imageUrl' => $imageUrl,
        ];
    }

    public function validate(array $data): array
    {
        $url = (string) ($data['url'] ?? '');
        if ($url !== '') {
            if (Html::sanitizeUrl($url) === '') {
                return ['Link URL is not allowed.'];
            }
            $host = parse_url($url, PHP_URL_HOST);
            if ($host) {
                $host = strtolower($host);
                if ($host === '127.0.0.1' || $host === '169.254.169.254' || $host === 'localhost' || $host === '::1') {
                    return ['Internal loopback URLs are not allowed for security reasons.'];
                }
            }
        }
        return [];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $url = Html::sanitizeUrl((string) ($block['data']['url'] ?? ''));
        if ($url === '') {
            return '';
        }
        $title = Html::plainText((string) ($block['data']['title'] ?? ''));
        $text = (string) ($block['data']['text'] ?? '');
        $imageUrl = Html::sanitizeUrl((string) ($block['data']['imageUrl'] ?? ''));
        
        if ($title === '') {
            $title = $url;
        }
        
        $html = '<div class="kc-block kc-block-linkcard" data-block-id="' . Html::escape($block['id']) . '">';
        $html .= '<a href="' . Html::escape($url) . '" class="kc-linkcard-link" rel="noopener noreferrer" target="_blank">';
        $html .= '<div class="kc-linkcard-content">';
        $html .= '<strong class="kc-linkcard-title">' . Html::escape($title) . '</strong>';
        if (Html::plainText($text) !== '') {
            $html .= '<span class="kc-linkcard-desc">' . $text . '</span>';
        }
        $html .= '<span class="kc-linkcard-url">' . Html::escape($url) . '</span>';
        $html .= '</div>';
        
        if ($imageUrl !== '') {
            $html .= '<div class="kc-linkcard-image" style="background-image: url(\'' . Html::escape($imageUrl) . '\');" aria-hidden="true"></div>';
        }
        
        $html .= '</a></div>';
        return $html;
    }

    public function description(): string
    {
        return 'Titled URL bookmark card';
    }

    public function icon(): string
    {
        return '🔗';
    }

    public function category(): string
    {
        return 'media';
    }
}


