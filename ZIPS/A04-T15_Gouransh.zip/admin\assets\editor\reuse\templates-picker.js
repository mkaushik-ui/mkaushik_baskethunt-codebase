/**
 * Task T7: Starter Templates Picker Modal.
 */
(function (global) {
  'use strict';

  class TemplatesPicker {
    constructor() {
      this.modalEl = null;
    }

    open(onTemplateSelected) {
      console.log('[TemplatesPicker] Opening starter templates gallery.');
      // Simple fallback UI for skeleton
      const id = prompt("Enter Template ID (e.g. blank, api_spec, guide, procedure, policy, faq, architecture, release_notes):");
      if (id) {
        if (typeof onTemplateSelected === 'function') {
          onTemplateSelected(id.trim());
        }
      }
    }
  }

  global.KcTemplatesPicker = TemplatesPicker;
})(typeof window !== 'undefined' ? window : this);
