/**
 * Task T7: Non-destructive Legacy Content Converter.
 */
(function (global) {
  'use strict';

  class LegacyConverter {
    constructor() {}

    previewConversion(rawHtml) {
      // Parse HTML headings, paragraphs, lists into canonical JSON blocks
      const parser = new DOMParser();
      const doc = parser.parseFromString(rawHtml, 'text/html');
      const blocks = [];

      doc.body.childNodes.forEach(node => {
        if (node.nodeType !== Node.ELEMENT_NODE) return;

        const tag = node.tagName.toLowerCase();
        
        if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) {
          blocks.push({
            type: 'heading',
            data: {
              level: parseInt(tag.replace('h', ''), 10),
              text: node.innerHTML
            }
          });
        } else if (tag === 'p') {
          blocks.push({
            type: 'paragraph',
            data: {
              text: node.innerHTML
            }
          });
        } else if (tag === 'ul' || tag === 'ol') {
          const items = Array.from(node.children)
            .filter(li => li.tagName.toLowerCase() === 'li')
            .map(li => ({ text: li.innerHTML }));
          
          if (items.length > 0) {
            blocks.push({
              type: 'list',
              data: {
                style: tag === 'ol' ? 'ordered' : 'unordered',
                items: items
              }
            });
          }
        }
      });

      return { blocks };
    }
  }

  global.KcLegacyConverter = LegacyConverter;
})(typeof window !== 'undefined' ? window : this);
