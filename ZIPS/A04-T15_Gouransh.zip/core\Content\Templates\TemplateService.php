<?php
declare(strict_types=1);

namespace SOI\Core\Content\Templates;

use SOI\Core\Content\Document;

/**
 * Task T7: Document Starter Templates Service.
 */
class TemplateService
{
    /**
     * @return list<array{id:string,title:string,description:string,document:array<string,mixed>}>
     */
    public function getTemplates(): array
    {
        return [
            [
                'id' => 'blank',
                'title' => 'Blank Document',
                'description' => 'Start with an empty clean page.',
                'document' => Document::empty(),
            ],
            [
                'id' => 'api_spec',
                'title' => 'API Specification',
                'description' => 'Scaffold an API documentation page with endpoints and code examples.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_api', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'API Overview']],
                        ['id' => 'blk_p_api', 'type' => 'paragraph', 'data' => ['text' => 'Provide a summary of the API specification.']],
                    ],
                ],
            ],
            [
                'id' => 'guide',
                'title' => 'Guide',
                'description' => 'A structured guide with steps and tips.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_guide', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Introduction']],
                        ['id' => 'blk_p_guide1', 'type' => 'paragraph', 'data' => ['text' => 'Explain the goal of this guide.']],
                        ['id' => 'blk_callout_guide', 'type' => 'callout', 'data' => ['tone' => 'info', 'title' => 'Note', 'text' => 'Important contextual information.']],
                    ],
                ],
            ],
            [
                'id' => 'procedure',
                'title' => 'Procedure',
                'description' => 'Step-by-step instructions for a specific task.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_proc', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Prerequisites']],
                        ['id' => 'blk_list_proc1', 'type' => 'list', 'data' => ['style' => 'unordered', 'items' => [['text' => 'Requirement 1'], ['text' => 'Requirement 2']]]],
                        ['id' => 'blk_h2_proc2', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Steps']],
                        ['id' => 'blk_list_proc2', 'type' => 'list', 'data' => ['style' => 'ordered', 'items' => [['text' => 'Step 1'], ['text' => 'Step 2']]]],
                    ],
                ],
            ],
            [
                'id' => 'policy',
                'title' => 'Policy',
                'description' => 'Official policy documentation.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_policy1', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Purpose']],
                        ['id' => 'blk_p_policy1', 'type' => 'paragraph', 'data' => ['text' => 'State the purpose of the policy.']],
                        ['id' => 'blk_h2_policy2', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Scope']],
                        ['id' => 'blk_p_policy2', 'type' => 'paragraph', 'data' => ['text' => 'Who does this apply to?']],
                    ],
                ],
            ],
            [
                'id' => 'faq',
                'title' => 'FAQ',
                'description' => 'Frequently Asked Questions template.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_faq', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Frequently Asked Questions']],
                        ['id' => 'blk_acc_faq1', 'type' => 'accordion', 'data' => ['title' => 'Question 1?', 'blocks' => [['type' => 'paragraph', 'data' => ['text' => 'Answer to question 1.']]]]],
                    ],
                ],
            ],
            [
                'id' => 'architecture',
                'title' => 'Architecture',
                'description' => 'System architecture and design document.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_arch', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'System Overview']],
                        ['id' => 'blk_p_arch1', 'type' => 'paragraph', 'data' => ['text' => 'High-level description of the architecture.']],
                        ['id' => 'blk_h2_arch2', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Components']],
                    ],
                ],
            ],
            [
                'id' => 'release_notes',
                'title' => 'Release Notes',
                'description' => 'Document new features, fixes, and updates.',
                'document' => [
                    'schemaVersion' => 1,
                    'blocks' => [
                        ['id' => 'blk_h2_rn', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'What\'s New']],
                        ['id' => 'blk_list_rn1', 'type' => 'list', 'data' => ['style' => 'unordered', 'items' => [['text' => 'Feature 1'], ['text' => 'Feature 2']]]],
                        ['id' => 'blk_h2_rn2', 'type' => 'heading', 'data' => ['level' => 2, 'text' => 'Bug Fixes']],
                    ],
                ],
            ],
        ];
    }
}
