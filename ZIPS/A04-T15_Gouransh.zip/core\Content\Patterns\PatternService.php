<?php
declare(strict_types=1);

namespace SOI\Core\Content\Patterns;

/**
 * Task T7: Copy-Insert Content Patterns Service.
 */
class PatternService
{
    /**
     * @return list<array{id:string,title:string,category:string,blocks:list<array<string,mixed>>}>
     */
    public function getPatterns(): array
    {
        return [
            [
                'id' => 'callout_procedure',
                'title' => 'Important Procedure Warning',
                'category' => 'notice',
                'blocks' => [
                    ['type' => 'callout', 'data' => ['tone' => 'warning', 'title' => 'Prerequisite Required', 'text' => 'Ensure you have administrator access before proceeding.']],
                ],
            ],
            [
                'id' => 'faq_item',
                'title' => 'FAQ Item',
                'category' => 'structure',
                'blocks' => [
                    ['type' => 'accordion', 'data' => ['title' => 'Question?', 'blocks' => [['type' => 'paragraph', 'data' => ['text' => 'Answer.']]]]],
                ],
            ],
            [
                'id' => 'tabbed_code',
                'title' => 'Tabbed Code Snippet',
                'category' => 'technical',
                'blocks' => [
                    ['type' => 'codegroup', 'data' => ['tabs' => [
                        ['title' => 'JavaScript', 'language' => 'javascript', 'code' => 'console.log("Hello");'],
                        ['title' => 'PHP', 'language' => 'php', 'code' => 'echo "Hello";']
                    ]]],
                ],
            ],
        ];
    }
}
