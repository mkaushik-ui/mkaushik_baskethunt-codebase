<?php
declare(strict_types=1);

namespace SOI\Core\Content\Blocks;

use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * CardsBlock
 * Grid container for structured card items with optional icon/image and link attributes.
 */
final class CardsBlock extends AbstractBlock
{
    public function type(): string
    {
        return 'cards';
    }

    public function label(): string
    {
        return 'Cards Grid';
    }

    public function sanitize(array $data): array
    {
        $itemsIn = is_array($data['items'] ?? null) ? $data['items'] : [];
        $items = [];

        foreach ($itemsIn as $item) {
            if (!is_array($item)) {
                continue;
            }
            $items[] = [
                'title' => Html::sanitizeInline((string)($item['title'] ?? ''), 255),
                'text'  => Html::sanitizeInline((string)($item['text'] ?? ''), 1000),
                'link'  => Html::sanitizeUrl((string)($item['link'] ?? '')),
                'icon'  => Html::sanitizeInline((string)($item['icon'] ?? ''), 100),
            ];
        }

        return ['items' => $items];
    }

    public function render(array $block, RenderContext $ctx): string
    {
        $items = is_array($block['data']['items'] ?? null) ? $block['data']['items'] : [];
        $blockId = Html::escape($block['id'] ?? '');

        $html = sprintf('<div class="kc-block kc-block-cards kc-cards-grid" data-block-id="%s" data-block-type="cards">', $blockId);

        foreach ($items as $item) {
            $title = Html::escape($item['title'] ?? '');
            $text = Html::escape($item['text'] ?? '');
            $link = !empty($item['link']) ? Html::escape($item['link']) : null;
            $icon = !empty($item['icon']) ? Html::escape($item['icon']) : null;

            $iconHtml = $icon ? sprintf('<div class="kc-card-icon"><i class="%s"></i></div>', $icon) : '';
            $titleHtml = $title !== '' ? sprintf('<h4 class="kc-card-title">%s</h4>', $title) : '';
            $textHtml = $text !== '' ? sprintf('<p class="kc-card-text">%s</p>', $text) : '';

            $cardInner = $iconHtml . $titleHtml . $textHtml;

            if ($link) {
                $html .= sprintf('<a href="%s" class="kc-card-item">%s</a>', $link, $cardInner);
            } else {
                $html .= sprintf('<div class="kc-card-item">%s</div>', $cardInner);
            }
        }

        $html .= '</div>';
        return $html;
    }
}

