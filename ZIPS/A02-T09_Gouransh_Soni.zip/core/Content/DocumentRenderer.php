<?php
declare(strict_types=1);

namespace SOI\Core\Content;

use SOI\Core\Content\Contracts\RendererInterface;

/**
 * Canonical server-side document renderer and block dispatcher.
 * Independent of the client-side Editor.js DOM.
 */
final class DocumentRenderer
{
    /**
     * Render a pages/posts record using structured data when present.
     *
     * @param array<string, mixed> $record
     */
    public static function renderRecord(array $record, bool $preview = false): string
    {
        if (EditorSchema::isStructured($record)) {
            try {
                $document = Document::parse($record['body_json'] ?? '');
                return self::render($document, $preview);
            } catch (\Throwable $e) {
                $fallback = (string) ($record['content'] ?? '');
                return $fallback;
            }
        }
        return (string) ($record['content'] ?? '');
    }

    /**
     * Render a full canonical document structure into semantic HTML.
     *
     * @param array{schemaVersion?:int,blocks:list<array{id:string,type:string,data:array<string,mixed>}>} $document
     */
    public static function render(array $document, bool $preview = false): string
    {
        $ctx = new RenderContext();
        $ctx->preview = $preview;
        $html = [];

        foreach ($document['blocks'] ?? [] as $block) {
            if (!is_array($block)) {
                continue;
            }
            $type = (string) ($block['type'] ?? '');
            $handler = BlockRegistry::get($type);
            $chunk = $handler->render([
                'id' => (string) ($block['id'] ?? ''),
                'type' => $type,
                'data' => is_array($block['data'] ?? null) ? $block['data'] : [],
            ], $ctx);
            if ($chunk !== '') {
                $html[] = $chunk;
            }
        }
        $rawHtml = implode("\n", $html);
        return self::sanitizeDocumentHtml($rawHtml);
    }

    /**
     * Globally purifies final document HTML to ensure no raw scripts or inline events leak through.
     */
    private static function sanitizeDocumentHtml(string $html): string
    {
        if (trim($html) === '') {
            return '';
        }

        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument('1.0', 'UTF-8');
        $wrapped = '<?xml encoding="UTF-8"><div id="soi-doc-root">' . $html . '</div>';
        $loaded = $dom->loadHTML($wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if (!$loaded) {
            return htmlspecialchars(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        $root = $dom->getElementById('soi-doc-root');
        if (!$root) {
            return htmlspecialchars(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        self::scrubUnsafeNodes($root);

        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }
        return trim($out);
    }

    /**
     * Recursively strip out script tags and on* attributes from DOM.
     */
    private static function scrubUnsafeNodes(\DOMNode $node): void
    {
        $toRemove = [];
        foreach ($node->childNodes as $child) {
            if ($child instanceof \DOMElement) {
                $tag = strtolower($child->tagName);
                if (in_array($tag, ['script', 'iframe', 'object', 'embed', 'link', 'meta', 'style'], true)) {
                    $toRemove[] = $child;
                    continue;
                }

                $removeAttrs = [];
                foreach ($child->attributes ?? [] as $attr) {
                    $attrName = strtolower($attr->nodeName);
                    if (str_starts_with($attrName, 'on')) {
                        $removeAttrs[] = $attr->nodeName;
                    } elseif ($attrName === 'href' || $attrName === 'src') {
                        $val = strtolower(trim($attr->nodeValue));
                        if (str_starts_with($val, 'javascript:') || str_starts_with($val, 'data:text/html') || str_starts_with($val, 'vbscript:')) {
                            $removeAttrs[] = $attr->nodeName;
                        }
                    }
                }
                foreach ($removeAttrs as $attrName) {
                    $child->removeAttribute($attrName);
                }

                self::scrubUnsafeNodes($child);
            }
        }

        foreach ($toRemove as $dead) {
            if ($dead->parentNode) {
                $dead->parentNode->removeChild($dead);
            }
        }
    }

    /**
     * Headings collected during a render pass — used for Table of Contents (On this page).
     *
     * @param array{schemaVersion?:int,blocks:list<array{id:string,type:string,data:array<string,mixed>}>} $document
     * @return list<array{id:string,level:int,text:string}>
     */
    public static function extractHeadings(array $document): array
    {
        $ctx = new RenderContext();
        foreach ($document['blocks'] ?? [] as $block) {
            if (!is_array($block) || ($block['type'] ?? '') !== 'heading') {
                continue;
            }
            BlockRegistry::get('heading')->render([
                'id' => (string) ($block['id'] ?? ''),
                'type' => 'heading',
                'data' => is_array($block['data'] ?? null) ? $block['data'] : [],
            ], $ctx);
        }
        return $ctx->headings;
    }

}
