/**
 * SOI Knowledge Center — Contextual Block Inspector Shell
 * Location: admin/assets/editor/ui/inspector-shell.js
 *
 * Implements EUX-11 Contextual Block Inspector Synchronization.
 * Dynamically binds property inspection and live two-way synchronization
 * for active canvas blocks (Heading, Callout, Image, Columns, Code).
 */
(function () {
  'use strict';

  class InspectorShell {
    constructor() {
      this.container = null;
      this.titleEl = null;
      this.metaEl = null;
      this.activeBlock = null;
      this.selectedBlock = null;

      this.init();
    }

    init() {
      this.resolveDOMElements();
      this.render();
      this.bindEvents();
    }

    resolveDOMElements() {
      this.container = document.getElementById('kc-inspector-content') || document.getElementById('kc-block-fields');
      this.titleEl = document.getElementById('kc-inspector-title');
      this.metaEl = document.getElementById('kc-selected-meta');
    }

    sanitizeText(str) {
      if (typeof str !== 'string') return '';
      const temp = document.createElement('div');
      temp.textContent = str;
      return temp.innerHTML;
    }

    bindEvents() {
      // Listen for window.KcEditorRuntime event
      if (window.KcEditorRuntime && typeof window.KcEditorRuntime.on === 'function') {
        window.KcEditorRuntime.on('selectionChange', (block) => {
          this.setBlock(block);
        });
      }

      // Interoperability with custom DOM event
      document.addEventListener('kc:selectionChange', (e) => {
        if (e.detail !== undefined) {
          this.setBlock(e.detail);
        }
      });
      document.addEventListener('kc:block-selected', (e) => {
        if (e.detail && e.detail.block !== undefined) {
          this.setBlock(e.detail.block);
        }
      });

      // Canvas background click clears selection
      const canvas = document.getElementById('kc-canvas');
      if (canvas) {
        canvas.addEventListener('click', (e) => {
          if (e.target.id === 'kc-canvas' || e.target.classList.contains('kc-doc-stage') || e.target.classList.contains('kc-doc-surface')) {
            if (!e.target.closest('.ce-block')) {
              this.setBlock(null);
            }
          }
        });
      }
    }

    /**
     * Sets active block and triggers UI update
     * @param {Object|null} block - { index, type, id, data, block, holder }
     */
    setBlock(block) {
      this.activeBlock = block;
      this.selectedBlock = block;
      this.resolveDOMElements();
      this.render();
    }

    /**
     * Notify editor runtime and DOM of canvas changes
     */
    notifyDirty() {
      if (window.KcEditorRuntime && typeof window.KcEditorRuntime.emit === 'function') {
        window.KcEditorRuntime.emit('documentChange', { block: this.activeBlock });
      }
      if (typeof window.__kcMarkDirty === 'function') {
        window.__kcMarkDirty();
      } else {
        const docForm = document.getElementById('kc-editor');
        if (docForm) {
          docForm.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    }

    /**
     * Render the Inspector view (empty state or active block controls)
     */
    render() {
      if (!this.container) {
        this.resolveDOMElements();
        if (!this.container) return;
      }

      if (!this.activeBlock) {
        if (this.titleEl) {
          this.titleEl.textContent = 'DOCUMENT SETTINGS';
        }
        if (this.metaEl) {
          this.metaEl.textContent = 'Select a block on the canvas to configure properties.';
          this.metaEl.style.display = 'block';
        }
        this.container.innerHTML = '<p class="kc-empty-hint">Select a block on the canvas to configure properties.</p>';
        return;
      }

      const type = (this.activeBlock.type || 'block').toLowerCase();
      const typeLabel = type.toUpperCase();

      if (this.titleEl) {
        this.titleEl.textContent = `BLOCK: ${typeLabel}`;
      }
      if (this.metaEl) {
        this.metaEl.textContent = `Active Block: ${typeLabel} (ID: ${this.activeBlock.id || 'new'})`;
        this.metaEl.style.display = 'block';
      }

      this.renderBlockControls();
    }

    /**
     * Render block-specific controls for the active block
     */
    renderBlockControls() {
      const block = this.activeBlock;
      const type = (block.type || 'block').toLowerCase();
      const data = block.data || {};
      const holder = block.holder || (block.block ? block.block.holder : null);

      let html = '';

      if (type === 'header' || type === 'heading') {
        const curLevel = data.level || (holder ? this.detectHeadingLevel(holder) : 2);
        const curAnchor = data.anchor || (holder ? (holder.querySelector('h1,h2,h3,h4,h5,h6')?.id || '') : '');

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-hlevel">Heading Level</label>
              <select class="kc-tool-select" id="kc-insp-hlevel">
                <option value="1" ${curLevel === 1 ? 'selected' : ''}>H1 — Main Title</option>
                <option value="2" ${curLevel === 2 ? 'selected' : ''}>H2 — Section Header</option>
                <option value="3" ${curLevel === 3 ? 'selected' : ''}>H3 — Subsection Header</option>
                <option value="4" ${curLevel === 4 ? 'selected' : ''}>H4 — Minor Header</option>
                <option value="5" ${curLevel === 5 ? 'selected' : ''}>H5 — Micro Header</option>
                <option value="6" ${curLevel === 6 ? 'selected' : ''}>H6 — Smallest Header</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-anchor">Anchor ID (slug)</label>
              <input type="text" class="kc-tool-input" id="kc-insp-anchor" value="${this.sanitizeText(curAnchor)}" placeholder="e.g. section-overview">
              <small class="kc-field-hint" style="font-size:0.75rem;color:var(--kc-muted,#64748b);">Direct link anchor for table of contents.</small>
            </div>
          </div>
        `;
      } else if (type === 'callout') {
        const curTone = data.tone || (holder ? (holder.dataset.tone || 'info') : 'info');
        const curTitle = data.title || (holder ? (holder.querySelector('.kc-tool-title')?.value || '') : '');

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-tone">Tone / Variant</label>
              <select class="kc-tool-select" id="kc-insp-tone">
                <option value="info" ${curTone === 'info' ? 'selected' : ''}>Info (Blue)</option>
                <option value="warning" ${curTone === 'warning' ? 'selected' : ''}>Warning (Amber)</option>
                <option value="success" ${curTone === 'success' ? 'selected' : ''}>Success (Green)</option>
                <option value="danger" ${curTone === 'danger' ? 'selected' : ''}>Danger (Red)</option>
                <option value="note" ${curTone === 'note' ? 'selected' : ''}>Note (Slate)</option>
                <option value="tip" ${curTone === 'tip' ? 'selected' : ''}>Tip (Emerald)</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-callout-title">Notice Title</label>
              <input type="text" class="kc-tool-input" id="kc-insp-callout-title" value="${this.sanitizeText(curTitle)}" placeholder="Optional notice heading…">
            </div>
          </div>
        `;
      } else if (type === 'image') {
        const curCaption = data.caption || (holder ? (holder.querySelector('.kc-image-caption-input')?.value || '') : '');
        const curAlt = data.alt || (holder ? (holder.querySelector('.kc-image-alt-input')?.value || '') : '');
        const curWidth = data.width || 'default';
        const curAlign = data.align || 'center';

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-caption">Caption</label>
              <input type="text" class="kc-tool-input" id="kc-insp-img-caption" value="${this.sanitizeText(curCaption)}" placeholder="Figure caption text…">
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-alt">Alt Text (Accessibility)</label>
              <input type="text" class="kc-tool-input" id="kc-insp-img-alt" value="${this.sanitizeText(curAlt)}" placeholder="Screen-reader description…">
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-width">Width Layout</label>
              <select class="kc-tool-select" id="kc-insp-img-width">
                <option value="default" ${curWidth === 'default' ? 'selected' : ''}>Default (Content Width)</option>
                <option value="wide" ${curWidth === 'wide' ? 'selected' : ''}>Wide (Expanded Width)</option>
                <option value="full" ${curWidth === 'full' ? 'selected' : ''}>Full Width (Bleed)</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-img-align">Alignment</label>
              <select class="kc-tool-select" id="kc-insp-img-align">
                <option value="left" ${curAlign === 'left' ? 'selected' : ''}>Left</option>
                <option value="center" ${curAlign === 'center' ? 'selected' : ''}>Center</option>
                <option value="right" ${curAlign === 'right' ? 'selected' : ''}>Right</option>
              </select>
            </div>
          </div>
        `;
      } else if (type === 'columns') {
        const curLayout = data.layout || (holder ? (holder.dataset.layout || '50-50') : '50-50');

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-col-ratio">Layout Ratio</label>
              <select class="kc-tool-select" id="kc-insp-col-ratio">
                <option value="50-50" ${curLayout === '50-50' ? 'selected' : ''}>50 / 50 (Two Equal Columns)</option>
                <option value="33-67" ${curLayout === '33-67' ? 'selected' : ''}>33 / 67 (Narrow Left, Wide Right)</option>
                <option value="67-33" ${curLayout === '67-33' ? 'selected' : ''}>67 / 33 (Wide Left, Narrow Right)</option>
                <option value="33-33-33" ${curLayout === '33-33-33' ? 'selected' : ''}>33 / 33 / 33 (Three Equal Columns)</option>
              </select>
            </div>
          </div>
        `;
      } else if (type === 'code') {
        const curLang = data.language || (holder ? (holder.querySelector('.kc-code-lang-select')?.value || 'php') : 'php');
        const showLines = data.showLineNumbers !== undefined ? !!data.showLineNumbers : true;

        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label" for="kc-insp-code-lang">Language</label>
              <select class="kc-tool-select" id="kc-insp-code-lang">
                <option value="php" ${curLang === 'php' ? 'selected' : ''}>PHP</option>
                <option value="javascript" ${curLang === 'javascript' ? 'selected' : ''}>JavaScript (JS)</option>
                <option value="python" ${curLang === 'python' ? 'selected' : ''}>Python</option>
                <option value="bash" ${curLang === 'bash' ? 'selected' : ''}>Bash / Shell</option>
                <option value="sql" ${curLang === 'sql' ? 'selected' : ''}>SQL</option>
                <option value="html" ${curLang === 'html' ? 'selected' : ''}>HTML</option>
                <option value="css" ${curLang === 'css' ? 'selected' : ''}>CSS</option>
                <option value="json" ${curLang === 'json' ? 'selected' : ''}>JSON</option>
                <option value="typescript" ${curLang === 'typescript' ? 'selected' : ''}>TypeScript</option>
              </select>
            </div>
            <div class="kc-field">
              <label class="kc-check" style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;">
                <input type="checkbox" id="kc-insp-code-lines" ${showLines ? 'checked' : ''}>
                <span>Display Line Numbers</span>
              </label>
            </div>
          </div>
        `;
      } else {
        html = `
          <div class="kc-inspector-section">
            <div class="kc-field">
              <label class="kc-form-label">Block Identifier</label>
              <input type="text" class="kc-tool-input" value="${this.sanitizeText(block.id || 'unassigned')}" readonly style="opacity:0.75;">
            </div>
            <p class="kc-empty-hint" style="margin-top:0.75rem;">Standard properties for this block are managed inline on the canvas.</p>
          </div>
        `;
      }

      this.container.innerHTML = html;
      this.bindControlHandlers();
    }

    detectHeadingLevel(holder) {
      const h = holder.querySelector('h1,h2,h3,h4,h5,h6');
      if (h) {
        const num = parseInt(h.tagName.substring(1), 10);
        if (!isNaN(num)) return num;
      }
      return 2;
    }

    /**
     * Binds input change listeners to apply modifications directly to the canvas block
     */
    bindControlHandlers() {
      const block = this.activeBlock;
      if (!block) return;
      const holder = block.holder || (block.block ? block.block.holder : null);

      // 1. Heading Controls
      const hLevelSel = document.getElementById('kc-insp-hlevel');
      if (hLevelSel) {
        hLevelSel.addEventListener('change', () => {
          const newLevel = parseInt(hLevelSel.value, 10);
          block.data = block.data || {};
          block.data.level = newLevel;

          if (holder) {
            const hTag = holder.querySelector('h1,h2,h3,h4,h5,h6,[contenteditable]');
            if (hTag) {
              const targetTag = 'H' + newLevel;
              if (hTag.tagName !== targetTag) {
                const newEl = document.createElement(targetTag);
                newEl.contentEditable = hTag.contentEditable || 'true';
                newEl.className = hTag.className;
                newEl.innerHTML = hTag.innerHTML;
                if (hTag.id) newEl.id = hTag.id;
                hTag.parentNode.replaceChild(newEl, hTag);
              }
            }
          }
          this.notifyDirty();
        });
      }

      const hAnchorInput = document.getElementById('kc-insp-anchor');
      if (hAnchorInput) {
        hAnchorInput.addEventListener('input', () => {
          const anchor = hAnchorInput.value.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-');
          block.data = block.data || {};
          block.data.anchor = anchor;

          if (holder) {
            const hTag = holder.querySelector('h1,h2,h3,h4,h5,h6,[contenteditable]');
            if (hTag) {
              if (anchor) {
                hTag.id = anchor;
                hTag.setAttribute('data-anchor', anchor);
              } else {
                hTag.removeAttribute('id');
                hTag.removeAttribute('data-anchor');
              }
            }
          }
          this.notifyDirty();
        });
      }

      // 2. Callout Controls
      const toneSel = document.getElementById('kc-insp-tone');
      if (toneSel) {
        toneSel.addEventListener('change', () => {
          const newTone = toneSel.value;
          block.data = block.data || {};
          block.data.tone = newTone;

          if (holder) {
            const wrap = holder.querySelector('.kc-tool-callout') || holder;
            wrap.className = wrap.className.replace(/\bkc-callout-[a-z]+\b/g, '').trim();
            wrap.classList.add('kc-callout-' + newTone);
            wrap.dataset.tone = newTone;

            const inlineSelect = holder.querySelector('.kc-tool-tone');
            if (inlineSelect) inlineSelect.value = newTone;

            const badge = holder.querySelector('.kc-callout-badge-icon');
            if (badge) {
              const icons = { info: 'ℹ', note: '📝', tip: '💡', warning: '⚠️', danger: '⛔', success: '✓' };
              badge.textContent = icons[newTone] || 'ℹ';
            }
          }
          this.notifyDirty();
        });
      }

      const calloutTitleInput = document.getElementById('kc-insp-callout-title');
      if (calloutTitleInput) {
        calloutTitleInput.addEventListener('input', () => {
          const val = calloutTitleInput.value;
          block.data = block.data || {};
          block.data.title = val;

          if (holder) {
            const titleField = holder.querySelector('.kc-tool-title');
            if (titleField && titleField.value !== val) {
              titleField.value = val;
            }
          }
          this.notifyDirty();
        });
      }

      // 3. Image Controls
      const imgCaption = document.getElementById('kc-insp-img-caption');
      if (imgCaption) {
        imgCaption.addEventListener('input', () => {
          const val = imgCaption.value;
          block.data = block.data || {};
          block.data.caption = val;

          if (holder) {
            const cap = holder.querySelector('.kc-image-caption-input') || holder.querySelector('figcaption');
            if (cap) {
              if ('value' in cap) cap.value = val;
              else cap.textContent = val;
            }
          }
          this.notifyDirty();
        });
      }

      const imgAlt = document.getElementById('kc-insp-img-alt');
      if (imgAlt) {
        imgAlt.addEventListener('input', () => {
          const val = imgAlt.value;
          block.data = block.data || {};
          block.data.alt = val;

          if (holder) {
            const alt = holder.querySelector('.kc-image-alt-input') || holder.querySelector('img');
            if (alt) {
              if ('value' in alt) alt.value = val;
              else alt.alt = val;
            }
          }
          this.notifyDirty();
        });
      }

      const imgWidth = document.getElementById('kc-insp-img-width');
      if (imgWidth) {
        imgWidth.addEventListener('change', () => {
          const val = imgWidth.value;
          block.data = block.data || {};
          block.data.width = val;

          if (holder) {
            const card = holder.querySelector('.kc-image-card') || holder.querySelector('.kc-tool-image') || holder;
            card.className = card.className.replace(/\bkc-image-width-[a-z]+\b/g, '').trim();
            card.classList.add('kc-image-width-' + val);
            card.dataset.width = val;
          }
          this.notifyDirty();
        });
      }

      const imgAlign = document.getElementById('kc-insp-img-align');
      if (imgAlign) {
        imgAlign.addEventListener('change', () => {
          const val = imgAlign.value;
          block.data = block.data || {};
          block.data.align = val;

          if (holder) {
            const card = holder.querySelector('.kc-image-card') || holder.querySelector('.kc-tool-image') || holder;
            card.className = card.className.replace(/\bkc-image-align-[a-z]+\b/g, '').trim();
            card.classList.add('kc-image-align-' + val);
            card.dataset.align = val;
          }
          this.notifyDirty();
        });
      }

      // 4. Columns Controls
      const colRatio = document.getElementById('kc-insp-col-ratio');
      if (colRatio) {
        colRatio.addEventListener('change', () => {
          const val = colRatio.value;
          block.data = block.data || {};
          block.data.layout = val;

          if (holder) {
            const wrap = holder.querySelector('.kc-tool-columns') || holder;
            wrap.dataset.layout = val;

            const inlineSelect = holder.querySelector('.kc-columns-select') || holder.querySelector('select');
            if (inlineSelect) inlineSelect.value = val;
          }
          this.notifyDirty();
        });
      }

      // 5. Code Controls
      const codeLang = document.getElementById('kc-insp-code-lang');
      if (codeLang) {
        codeLang.addEventListener('change', () => {
          const val = codeLang.value;
          block.data = block.data || {};
          block.data.language = val;

          if (holder) {
            const inlineSelect = holder.querySelector('.kc-code-lang-select') || holder.querySelector('select');
            if (inlineSelect) inlineSelect.value = val;
          }
          this.notifyDirty();
        });
      }

      const codeLines = document.getElementById('kc-insp-code-lines');
      if (codeLines) {
        codeLines.addEventListener('change', () => {
          const checked = !!codeLines.checked;
          block.data = block.data || {};
          block.data.showLineNumbers = checked;

          if (holder) {
            const toggle = holder.querySelector('.kc-code-lines-toggle') || holder.querySelector('input[type="checkbox"]');
            if (toggle) toggle.checked = checked;

            const gutter = holder.querySelector('.kc-code-gutter');
            if (gutter) gutter.style.display = checked ? '' : 'none';
          }
          this.notifyDirty();
        });
      }
    }
  }

  // Self-register upon DOM ready
  function bootstrapInspector() {
    window.InspectorShell = InspectorShell;
    window.KCInspector = new InspectorShell();
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bootstrapInspector);
    } else {
      bootstrapInspector();
    }
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { InspectorShell };
  }


  // === EUX-12 Layout Presets Controller Integration ===
  const PRESET_MAP = {
    'default': 'standard',
    'standard': 'standard',
    'wide': 'wide',
    'full': 'full'
  };

  const CLASS_MAP = {
    'standard': 'kc-layout-standard',
    'wide': 'kc-layout-wide',
    'full': 'kc-layout-full'
  };

  function applyLayoutPreset(presetName) {
    const norm = PRESET_MAP[String(presetName || '').toLowerCase().trim()] || 'standard';
    const targetClass = CLASS_MAP[norm];

    const canvas = document.getElementById('kc-editorjs') || document.getElementById('kc-editor-canvas') || document.querySelector('.kc-doc-surface');
    const redactor = document.querySelector('.codex-editor__redactor');
    const workspace = document.getElementById('kc-editor') || document.querySelector('.kc-workspace');

    [canvas, redactor, workspace].filter(Boolean).forEach(function (el) {
      el.classList.remove('kc-layout-standard', 'kc-layout-wide', 'kc-layout-full', 'kc-layout-default');
      el.classList.add(targetClass);
    });

    const select = document.getElementById('kc-layout-preset-select');
    if (select) {
      select.value = (norm === 'standard' ? 'default' : norm);
    }
    return norm;
  }

  function initLayoutPresetController() {
    const select = document.getElementById('kc-layout-preset-select');
    if (select) {
      select.addEventListener('change', function () {
        applyLayoutPreset(select.value);
        if (typeof window.markDirty === 'function') window.markDirty();
      });
    }
    const stackMobile = document.getElementById('kc-stack-mobile');
    if (stackMobile) {
      stackMobile.addEventListener('change', function () {
        const canvas = document.getElementById('kc-editorjs') || document.querySelector('.kc-doc-surface');
        if (canvas) {
          canvas.classList.toggle('kc-stack-mobile-enabled', stackMobile.checked);
        }
        if (typeof window.markDirty === 'function') window.markDirty();
      });
    }
    if (select) {
      applyLayoutPreset(select.value);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLayoutPresetController);
  } else {
    initLayoutPresetController();
  }

  window.KcInspectorShell = window.KcInspectorShell || {};
  window.KcInspectorShell.applyLayoutPreset = applyLayoutPreset;

})();