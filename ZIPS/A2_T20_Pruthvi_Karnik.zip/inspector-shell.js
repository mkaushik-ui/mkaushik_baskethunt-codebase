/**
 * Task A2-T20: Layout Inspector Settings.
 *
 * Synchronizes the Right Inspector with the active Editor.js block.
 *
 * Acceptance Criterion:
 * Selecting a Columns block populates a ratio selector
 * containing 50/50 and 33/67 options.
 */
(function (global) {
  'use strict';

  class InspectorShell {
    constructor(hostEl) {
      this.host =
        typeof hostEl === 'string'
          ? document.getElementById(hostEl)
          : hostEl;

      this.currentMode = 'document';
      this.selectedBlock = null;
      this.bound = false;
    }

    init() {
      if (!this.host || this.bound) {
        return;
      }

      this.render();
      this.bindSelectionEvents();

      this.bound = true;
    }

    bindSelectionEvents() {
      const runtime = global.KcEditorRuntime;

      if (
        !runtime ||
        typeof runtime.on !== 'function'
      ) {
        return;
      }

      runtime.on(
        'selectionChange',
        (block) => {
          this.setBlock(block);
        }
      );
    }

    setBlock(block) {
      this.selectedBlock = block || null;
      this.currentMode = block
        ? 'block'
        : 'document';

      this.render();
    }

    getBlockType() {
      if (!this.selectedBlock) {
        return '';
      }

      return String(
        this.selectedBlock.name ||
        this.selectedBlock.type ||
        ''
      ).toLowerCase();
    }

    render() {
      if (!this.host) {
        return;
      }

      if (this.currentMode === 'document') {
        this.renderDocumentSettings();
        return;
      }

      this.renderBlockSettings();
    }

    renderDocumentSettings() {
      this.host.innerHTML = `
        <div class="kc-inspector-head">
          <h3>Document Settings</h3>
        </div>

        <div class="kc-inspector-body">
          <div class="kc-field">
            <label for="kc-inspector-slug">
              URL Slug
            </label>

            <input
              type="text"
              id="kc-inspector-slug"
              class="kc-title-input"
              aria-label="URL Slug"
            />
          </div>

          <div class="kc-field">
            <label for="kc-inspector-desc">
              Meta Description
            </label>

            <textarea
              id="kc-inspector-desc"
              class="kc-field"
              aria-label="Meta Description"
            ></textarea>
          </div>
        </div>
      `;
    }

    renderBlockSettings() {
      const blockType =
        this.getBlockType();

      const blockName =
        this.selectedBlock &&
          (
            this.selectedBlock.name ||
            this.selectedBlock.type
          )
          ? (
            this.selectedBlock.name ||
            this.selectedBlock.type
          )
          : 'Block';

      this.host.innerHTML = `
        <div class="kc-inspector-head">
          <h3>
            Block Properties: ${this.escapeHtml(blockName)}
          </h3>
        </div>

        <div
          class="kc-inspector-body"
          id="kc-inspector-fields"
        ></div>
      `;

      const fields =
        this.host.querySelector(
          '#kc-inspector-fields'
        );

      if (!fields) {
        return;
      }

      /*
       * T20:
       * Columns blocks expose a Layout Ratio selector.
       */
      if (blockType === 'columns') {
        this.renderColumnsSettings(fields);
        return;
      }

      fields.innerHTML = `
        <p class="kc-empty-hint">
          Standard block properties are managed
          directly on the canvas.
        </p>
      `;
    }

    renderColumnsSettings(fields) {
      const field =
        document.createElement('div');

      field.className = 'kc-field';

      field.innerHTML = `
        <label for="kc-inspector-col-layout">
          Layout Ratio
        </label>

        <select
          id="kc-inspector-col-layout"
          class="kc-tool-select"
          aria-label="Columns layout ratio"
        >
          <option value="50-50">
            50 / 50
          </option>

          <option value="33-67">
            33 / 67
          </option>
        </select>
      `;

      fields.appendChild(field);

      const selector =
        field.querySelector(
          '#kc-inspector-col-layout'
        );

      if (!selector) {
        return;
      }

      /*
       * Preserve the currently selected ratio when
       * the block exposes one in its data.
       */
      const currentRatio =
        this.getCurrentColumnsRatio();

      if (
        currentRatio === '50-50' ||
        currentRatio === '33-67'
      ) {
        selector.value = currentRatio;
      }

      /*
       * Real event listener.
       *
       * This prevents the control from being dead UI.
       */
      selector.addEventListener(
        'change',
        () => {
          this.applyColumnsRatio(
            selector.value
          );
        }
      );
    }

    getCurrentColumnsRatio() {
      const block =
        this.selectedBlock;

      if (!block) {
        return '50-50';
      }

      /*
       * Different block implementations may expose
       * their data differently. Check the common forms.
       */
      if (
        block.data &&
        typeof block.data === 'object'
      ) {
        if (
          typeof block.data.layout === 'string'
        ) {
          return block.data.layout;
        }

        if (
          typeof block.data.ratio === 'string'
        ) {
          return block.data.ratio;
        }

        if (
          typeof block.data.columns === 'string'
        ) {
          return block.data.columns;
        }
      }

      return '50-50';
    }

    applyColumnsRatio(ratio) {
      if (
        ratio !== '50-50' &&
        ratio !== '33-67'
      ) {
        return;
      }

      const block =
        this.selectedBlock;

      if (!block) {
        return;
      }

      /*
       * If the workspace already provides a layout
       * update method, use it.
       */
      const workspace =
        global.KcWorkspace;

      if (
        workspace &&
        typeof workspace.updateBlockSettings ===
        'function'
      ) {
        workspace.updateBlockSettings(
          this.getBlockIdentifier(block),
          {
            layout: ratio
          }
        );

        return;
      }

      /*
       * Otherwise update the selected block's data
       * when Editor.js exposes it directly.
       */
      if (
        block.data &&
        typeof block.data === 'object'
      ) {
        block.data.layout = ratio;
      }

      /*
       * Keep the selected ratio available for
       * integrations that inspect the shell state.
       */
      block.__kcColumnsRatio = ratio;

      /*
       * Notify an existing workspace integration if it
       * exposes a generic block-change hook.
       */
      if (
        workspace &&
        typeof workspace.onBlockSettingsChange ===
        'function'
      ) {
        workspace.onBlockSettingsChange(
          this.getBlockIdentifier(block),
          {
            layout: ratio
          }
        );
      }
    }

    getBlockIdentifier(block) {
      if (!block) {
        return null;
      }

      return (
        block.id ||
        block.index ||
        this.selectedBlock
      );
    }

    escapeHtml(value) {
      return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }
  }

  global.KcInspectorShell =
    InspectorShell;

  function initialize() {
    if (global.kcInspectorShell) {
      return;
    }

    /*
     * Try the common inspector host IDs used by
     * the editor shell.
     */
    const host =
      document.getElementById(
        'kc-inspector'
      ) ||
      document.getElementById(
        'kc-inspector-shell'
      );

    if (!host) {
      return;
    }

    global.kcInspectorShell =
      new InspectorShell(host);

    global.kcInspectorShell.init();
  }

  if (
    document.readyState === 'loading'
  ) {
    document.addEventListener(
      'DOMContentLoaded',
      initialize
    );
  } else {
    initialize();
  }
})(typeof window !== 'undefined'
  ? window
  : this);