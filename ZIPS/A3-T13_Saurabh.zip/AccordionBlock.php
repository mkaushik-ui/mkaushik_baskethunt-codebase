<?php
declare(strict_types=1);

namespace SOI\Core\Blocks\Interactive;

use SOI\Core\Content\BlockType;
use SOI\Core\Content\Blocks\AbstractBlock;
use SOI\Core\Content\Html;
use SOI\Core\Content\RenderContext;

/**
 * Task A3-T13: Accordion Block
 * 
 * Expandable accordion sections component with accessible keyboard open/close
 * toggles and aria-expanded attributes.
 * 
 * @author Saurabh
 */
final class AccordionBlock extends AbstractBlock implements BlockType
{
    public function type(): string
    {
        return 'accordion';
    }

    public function label(): string
    {
        return 'Accordion';
    }

    /**
     * Sanitize stored data payload.
     *
     * @param array<string, mixed> $data
     * @return array{items: list<array{title:string, content:string, open:bool}>}
     */
    public function sanitize(array $data): array
    {
        return ['items' => self::sanitizeItems($data['items'] ?? [])];
    }

    /**
     * Validate block data constraints.
     *
     * @param array<string, mixed> $data
     * @return list<string>
     */
    public function validate(array $data): array
    {
        $items = is_array($data['items'] ?? null) ? $data['items'] : [];
        if (count($items) > 40) {
            return ['Accordion cannot contain more than 40 items.'];
        }
        return [];
    }

    /**
     * Render semantic HTML output with accessible keyboard toggles and aria-expanded.
     *
     * @param array{id:string,type:string,data:array<string,mixed>} $block
     * @param RenderContext $ctx
     * @return string
     */
    public function render(array $block, RenderContext $ctx): string
    {
        $data = $this->sanitize(is_array($block['data'] ?? null) ? $block['data'] : []);
        $items = $data['items'];
        if ($items === []) {
            return '';
        }

        $id = isset($block['id']) ? Html::escape((string) $block['id']) : '';
        $dataAttr = $id !== '' ? ' data-block-id="' . $id . '"' : '';

        $html = '<div class="kc-block kc-block-accordion"' . $dataAttr . '>';
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = (string) ($item['title'] ?? '');
            $content = (string) ($item['content'] ?? '');

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $open = !empty($item['open']);
            $ariaExpanded = $open ? 'true' : 'false';

            $html .= '<details class="kc-accordion-item"' . ($open ? ' open' : '') . '>';
            $html .= '<summary class="kc-accordion-title" aria-expanded="' . $ariaExpanded . '">' . Html::escape($title !== '' ? $title : 'Section') . '</summary>';

            if (Html::plainText($content) !== '') {
                $html .= '<div class="kc-accordion-content">' . $content . '</div>';
            }

            $html .= '</details>';
        }
        $html .= '</div>';

        return $html;
    }

    /**
     * @param mixed $items
     * @return list<array{title:string,content:string,open:bool}>
     */
    public static function sanitizeItems(mixed $items): array
    {
        if (!is_array($items)) {
            return [];
        }

        $out = [];
        foreach (array_values($items) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = Html::plainText(Html::clampText((string) ($item['title'] ?? ''), 300));
            $content = Html::sanitizeInline((string) ($item['content'] ?? ''), 20000);

            if ($title === '' && Html::plainText($content) === '') {
                continue;
            }

            $out[] = [
                'title' => $title,
                'content' => $content,
                'open' => !empty($item['open']),
            ];

            if (count($out) >= 40) {
                break;
            }
        }

        return $out;
    }
}
