<?php
/**
 * SOI Knowledge Center — Enterprise Editor Fullscreen Host Template
 * Location: admin/partials/editor/fullscreen-host.php
 */

if (!defined('SOI_ROOT')) {
    exit('Direct access not permitted.');
}

$pageTitle = $pageTitle ?? 'Edit Document';
$csrfToken = $csrfToken ?? ($_SESSION['_csrf_token'] ?? 'token_placeholder');
$docId     = (int)($_GET['id'] ?? 0);
$docTitle  = esc($docTitle ?? 'Untitled Document');
?>
<!DOCTYPE html>
<html lang="en" class="kc-editor-active">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $docTitle ?> — SOI Enterprise Editor</title>
  <link rel="stylesheet" href="assets/editor/kc-editor.css?v=1.1.0">
</head>
<body class="kc-editor-active">

<!-- Fullscreen Authoring Shell Host -->
<div class="kc-fullscreen-host" id="kc-fullscreen-host">

  <!-- Top Document Bar -->
  <header class="kc-top-doc-bar">
    <div class="kc-top-left">
      <a href="pages.php" class="kc-exit-btn" title="Exit Editor">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
        Exit
      </a>
      <input type="text" class="kc-doc-title-input" id="kc-doc-title" value="<?= $docTitle ?>" placeholder="Enter document title…">
      <span class="kc-save-status-badge saved" id="kc-save-status">
        <svg width="8" height="8" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
        Saved
      </span>
    </div>

    <div class="kc-top-right">
      <input type="hidden" name="_csrf" id="kc-csrf-token" value="<?= esc($csrfToken) ?>">
      <button type="button" class="kc-btn kc-btn-secondary" id="kc-preview-btn">Preview</button>
      <button type="button" class="kc-btn kc-btn-success" id="kc-publish-btn">Publish</button>
      <button type="button" class="kc-btn kc-btn-primary" id="kc-save-btn">Save</button>
    </div>
  </header>

  <!-- Progressive Ribbon Toolbar -->
  <div class="kc-ribbon-bar" id="kc-ribbon-container">
    <!-- Ribbon Tabs and Toolbar Rendered by ribbon.js -->
  </div>

  <!-- Workspace Main Layout Body -->
  <div class="kc-workspace-body">

    <!-- Left Multi-Tab Panel (Components, Navigator, Patterns, Reusable) -->
    <aside class="kc-panel-left" id="kc-panel-left">
      <div class="kc-panel-header">
        <h4 class="kc-panel-title" id="kc-panel-left-title">Library</h4>
        <button type="button" class="kc-btn kc-btn-secondary" id="kc-panel-left-close" style="padding:2px 6px;font-size:0.75rem;">✕</button>
      </div>

      <div class="kc-panel-tabs">
        <button type="button" class="kc-panel-tab active" data-tab="components">Components</button>
        <button type="button" class="kc-panel-tab" data-tab="navigator">Navigator</button>
        <button type="button" class="kc-panel-tab" data-tab="patterns">Patterns</button>
        <button type="button" class="kc-panel-tab" data-tab="reusable">Reusable</button>
      </div>

      <div class="kc-panel-content" id="kc-panel-left-content">
        <!-- Content dynamically initialized by panels.js & navigator-shell.js -->
      </div>
    </aside>

    <!-- Main Editor Canvas Area -->
    <main class="kc-canvas" id="kc-canvas">
      <div class="kc-canvas-inner" id="kc-canvas-inner" contenteditable="true">
        <h1><?= $docTitle ?></h1>
        <p>Start typing your document content here or drag components from the left panel…</p>
      </div>
    </main>

    <!-- Contextual Right Inspector Panel -->
    <aside class="kc-inspector-right" id="kc-inspector-right">
      <div class="kc-panel-header">
        <h4 class="kc-panel-title" id="kc-inspector-title">Inspector</h4>
        <button type="button" class="kc-btn kc-btn-secondary" id="kc-inspector-close" style="padding:2px 6px;font-size:0.75rem;">✕</button>
      </div>

      <div class="kc-inspector-content" id="kc-inspector-content">
        <!-- Inspector properties dynamically rendered by inspector-shell.js -->
      </div>
    </aside>

  </div>

  <!-- Status Bar -->
  <footer class="kc-status-bar">
    <div class="kc-status-left">
      <span id="kc-stat-words">0 words</span>
      <span id="kc-stat-chars">0 characters</span>
      <span id="kc-stat-revision">Rev #1</span>
      <span id="kc-stat-path">Doc &gt; Paragraph</span>
    </div>

    <div class="kc-status-right">
      <button type="button" class="kc-btn kc-btn-secondary" id="kc-distraction-free-btn" style="padding:2px 8px;font-size:0.75rem;">
        Distraction-Free Mode
      </button>
    </div>
  </footer>

</div>

<!-- Scripts Execution Engine -->
<script src="assets/editor/workspace/ribbon.js?v=1.1.0"></script>
<script src="assets/editor/ui/panels.js?v=1.1.0"></script>
<script src="assets/editor/ui/inspector-shell.js?v=1.1.0"></script>
<script src="assets/editor/ui/navigator-shell.js?v=1.1.0"></script>

</body>
</html>
