<?php
/**
 * Admin — Pages & Enterprise Editor Routing Controller
 * Location: admin/pages.php
 */

if (!defined('SOI_ROOT')) {
    define('SOI_ROOT', dirname(__DIR__));
}

require_once SOI_ROOT . '/config/config.php';
require_once SOI_ROOT . '/core/helpers.php';

// Autoload core classes
spl_autoload_register(function ($class) {
    $file = SOI_ROOT . '/core/' . str_replace(['SOI\\Core\\', '\\'], ['', '/'], $class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

use SOI\Core\{Database, Auth};

// Connect Database & Authenticate
Database::connect([
    'host'   => defined('SOI_DB_HOST') ? SOI_DB_HOST : 'localhost',
    'name'   => defined('SOI_DB_NAME') ? SOI_DB_NAME : 'soi_db',
    'user'   => defined('SOI_DB_USER') ? SOI_DB_USER : 'root',
    'pass'   => defined('SOI_DB_PASS') ? SOI_DB_PASS : '',
    'port'   => defined('SOI_DB_PORT') ? SOI_DB_PORT : 3306,
    'prefix' => defined('SOI_DB_PREFIX') ? SOI_DB_PREFIX : 'soi_'
]);

Auth::init();
Auth::requireAuth('admin');

$action = $_GET['action'] ?? 'list';
$docId  = (int)($_GET['id'] ?? 0);

// CSRF Token Generation
if (empty($_SESSION['_csrf_token'])) {
    $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['_csrf_token'];

// Enterprise Fullscreen Authoring Shell Routing
if (in_array($action, ['edit', 'new', 'editor'], true)) {
    $pageTitle = ($action === 'new') ? 'Create New Document' : 'Edit Document #' . $docId;
    $docTitle  = ($action === 'new') ? 'Untitled Document' : 'Enterprise Knowledge Center Overview';

    // Load Standalone Fullscreen Host (Omits standard CMS topbar/sidebar)
    require_once __DIR__ . '/partials/editor/fullscreen-host.php';
    exit;
}

// Default CMS Admin Page Listing View
$pageTitle = 'Pages';
$activeNav = 'pages';

require_once __DIR__ . '/partials/header.php';
?>

<div class="card">
  <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
    <h3 class="card-title">All Documents &amp; Pages</h3>
    <a href="pages.php?action=new" class="btn btn-primary">+ New Document</a>
  </div>
  
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Slug</th>
          <th>Status</th>
          <th>Author</th>
          <th>Updated</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Enterprise Knowledge Center Overview</strong></td>
          <td><code>enterprise-editor-walkthrough</code></td>
          <td><span class="badge badge-success">Published</span></td>
          <td>Administrator</td>
          <td>2026-08-21</td>
          <td>
            <a href="pages.php?action=edit&id=1" class="btn btn-sm btn-secondary">Edit in Shell</a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>
