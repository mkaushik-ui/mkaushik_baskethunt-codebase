/**
 * SOI Knowledge Center — Navigator Structure Tree Controller
 * Location: admin/assets/editor/ui/navigator-shell.js
 */

(function () {
  'use strict';

  class KCNavigatorController {
    constructor() {
      this.contentPanel = document.getElementById('kc-panel-left-content');

      this.init();
    }

    init() {
      document.addEventListener('kc:left-tab-change', (e) => {
        if (e.detail && e.detail.tab === 'navigator') {
          this.renderNavigator();
        } else if (e.detail && e.detail.tab === 'components') {
          this.renderComponentsList();
        }
      });

      // Default initial view
      this.renderComponentsList();
    }

    sanitizeText(str) {
      const temp = document.createElement('div');
      temp.textContent = str || '';
      return temp.innerHTML;
    }

    renderComponentsList() {
      if (!this.contentPanel) return;

      const html = `
        <div class="kc-components-list">
          <div class="kc-inspector-section-title">Core Text</div>
          <div class="kc-component-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;">
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">¶ Paragraph</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">H2 Heading</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">• Bullet List</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">“” Quote</div>
          </div>

          <div class="kc-inspector-section-title">Knowledge Blocks</div>
          <div class="kc-component-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;">
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">💡 Callout</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">1.2. Steps</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">≡ Accordion</div>
            <div class="kc-btn kc-btn-secondary" style="justify-content:flex-start;">⧉ Tabs</div>
          </div>
        </div>
      `;
      this.contentPanel.innerHTML = html;
    }

    renderNavigator() {
      if (!this.contentPanel) return;

      const html = `
        <div class="kc-navigator-tree">
          <div class="kc-inspector-section-title">Document Structure</div>
          <ul style="list-style:none;padding-left:0;margin:0;font-size:0.84rem;">
            <li style="padding:6px 8px;background:var(--kc-bg-dark);border-radius:4px;margin-bottom:4px;cursor:pointer;">
              📄 H1: Document Title
            </li>
            <li style="padding:6px 8px 6px 20px;background:var(--kc-bg-dark);border-radius:4px;margin-bottom:4px;cursor:pointer;">
              ¶ Paragraph Block
            </li>
            <li style="padding:6px 8px 6px 20px;background:var(--kc-bg-dark);border-radius:4px;margin-bottom:4px;cursor:pointer;">
              💡 Callout (Info Variant)
            </li>
            <li style="padding:6px 8px 6px 20px;background:var(--kc-bg-dark);border-radius:4px;margin-bottom:4px;cursor:pointer;">
              ≡ Accordion Container
              <ul style="list-style:none;padding-left:14px;margin-top:4px;">
                <li style="padding:4px 6px;background:var(--kc-bg-surface-elevated);border-radius:3px;margin-bottom:2px;">Item 1</li>
                <li style="padding:4px 6px;background:var(--kc-bg-surface-elevated);border-radius:3px;">Item 2</li>
              </ul>
            </li>
          </ul>
        </div>
      `;
      this.contentPanel.innerHTML = html;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCNavigator = new KCNavigatorController();
  });
})();
