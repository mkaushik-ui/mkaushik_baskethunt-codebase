/**
 * SOI Knowledge Center — Collapsible Left & Right Panels & Distraction-Free Mode Controller
 * Location: admin/assets/editor/ui/panels.js
 */

(function () {
  'use strict';

  class KCPanelController {
    constructor() {
      this.host = document.getElementById('kc-fullscreen-host');
      this.leftPanel = document.getElementById('kc-panel-left');
      this.rightInspector = document.getElementById('kc-inspector-right');
      this.distractionBtn = document.getElementById('kc-distraction-free-btn');

      this.leftCloseBtn = document.getElementById('kc-panel-left-close');
      this.inspectorCloseBtn = document.getElementById('kc-inspector-close');

      this.activeLeftTab = 'components';
      this.isDistractionFree = false;

      this.init();
    }

    init() {
      this.bindEvents();
      this.updateStats();
    }

    bindEvents() {
      // Left Panel Tab Switching
      if (this.leftPanel) {
        this.leftPanel.addEventListener('click', (e) => {
          const tabBtn = e.target.closest('.kc-panel-tab');
          if (tabBtn) {
            const targetTab = tabBtn.dataset.tab;
            this.switchLeftTab(targetTab);
          }
        });
      }

      // Panel Close Buttons
      if (this.leftCloseBtn) {
        this.leftCloseBtn.addEventListener('click', () => this.toggleLeftPanel(false));
      }
      if (this.inspectorCloseBtn) {
        this.inspectorCloseBtn.addEventListener('click', () => this.toggleRightInspector(false));
      }

      // Distraction Free Toggle
      if (this.distractionBtn) {
        this.distractionBtn.addEventListener('click', () => this.toggleDistractionFree());
      }

      // Live Stats Listener on Canvas Input
      const canvasInner = document.getElementById('kc-canvas-inner');
      if (canvasInner) {
        canvasInner.addEventListener('input', () => this.updateStats());
      }
    }

    switchLeftTab(tabId) {
      this.activeLeftTab = tabId;
      const tabs = this.leftPanel.querySelectorAll('.kc-panel-tab');
      tabs.forEach(t => {
        if (t.dataset.tab === tabId) {
          t.classList.add('active');
        } else {
          t.classList.remove('active');
        }
      });

      const titleEl = document.getElementById('kc-panel-left-title');
      if (titleEl) {
        titleEl.textContent = tabId.toUpperCase();
      }

      // Trigger custom event for Navigator / Component handlers
      const event = new CustomEvent('kc:left-tab-change', { detail: { tab: tabId } });
      document.dispatchEvent(event);
    }

    toggleLeftPanel(show) {
      if (typeof show === 'boolean') {
        if (show) this.leftPanel.classList.remove('collapsed');
        else this.leftPanel.classList.add('collapsed');
      } else {
        this.leftPanel.classList.toggle('collapsed');
      }
    }

    toggleRightInspector(show) {
      if (typeof show === 'boolean') {
        if (show) this.rightInspector.classList.remove('collapsed');
        else this.rightInspector.classList.add('collapsed');
      } else {
        this.rightInspector.classList.toggle('collapsed');
      }
    }

    toggleDistractionFree() {
      this.isDistractionFree = !this.isDistractionFree;
      if (this.isDistractionFree) {
        this.host.classList.add('kc-distraction-free');
        this.distractionBtn.classList.add('kc-btn-primary');
        this.distractionBtn.classList.remove('kc-btn-secondary');
        this.distractionBtn.textContent = 'Exit Distraction-Free';
      } else {
        this.host.classList.remove('kc-distraction-free');
        this.distractionBtn.classList.remove('kc-btn-primary');
        this.distractionBtn.classList.add('kc-btn-secondary');
        this.distractionBtn.textContent = 'Distraction-Free Mode';
      }
    }

    updateStats() {
      const canvasInner = document.getElementById('kc-canvas-inner');
      if (!canvasInner) return;

      const text = canvasInner.innerText || '';
      const words = text.trim() ? text.trim().split(/\s+/).length : 0;
      const chars = text.length;

      const wordsEl = document.getElementById('kc-stat-words');
      const charsEl = document.getElementById('kc-stat-chars');

      if (wordsEl) wordsEl.textContent = `${words} words`;
      if (charsEl) charsEl.textContent = `${chars} characters`;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCPanels = new KCPanelController();
  });
})();
