/**
 * SOI Knowledge Center — Contextual Inspector Shell Controller
 * Location: admin/assets/editor/ui/inspector-shell.js
 */

(function () {
  'use strict';

  class KCInspectorController {
    constructor() {
      this.container = document.getElementById('kc-inspector-content');
      this.titleEl = document.getElementById('kc-inspector-title');
      this.selectedBlock = null;

      this.init();
    }

    init() {
      if (!this.container) return;
      this.renderDocumentInspector();
      this.bindEvents();
    }

    sanitizeText(str) {
      const temp = document.createElement('div');
      temp.textContent = str || '';
      return temp.innerHTML;
    }

    bindEvents() {
      // Listen for block selection events in canvas
      document.addEventListener('kc:block-selected', (e) => {
        this.selectedBlock = e.detail ? e.detail.block : null;
        if (this.selectedBlock) {
          this.renderBlockInspector(this.selectedBlock);
        } else {
          this.renderDocumentInspector();
        }
      });

      // Clear selection when clicking canvas background
      const canvas = document.getElementById('kc-canvas');
      if (canvas) {
        canvas.addEventListener('click', (e) => {
          if (e.target.id === 'kc-canvas') {
            this.selectedBlock = null;
            this.renderDocumentInspector();
          }
        });
      }
    }

    renderDocumentInspector() {
      if (this.titleEl) {
        this.titleEl.textContent = 'DOCUMENT SETTINGS';
      }

      const html = `
        <div class="kc-inspector-section">
          <div class="kc-inspector-section-title">General Document Settings</div>
          
          <div class="kc-form-group">
            <label class="kc-form-label">URL Slug</label>
            <input type="text" class="kc-form-control" id="kc-insp-slug" value="enterprise-editor-walkthrough" placeholder="page-slug">
          </div>

          <div class="kc-form-group">
            <label class="kc-form-label">Document Status</label>
            <select class="kc-form-control" id="kc-insp-status">
              <option value="draft" selected>Draft</option>
              <option value="in_review">In Review</option>
              <option value="published">Published</option>
              <option value="archived">Archived</option>
            </select>
          </div>

          <div class="kc-form-group">
            <label class="kc-form-label">Knowledge Context / Space</label>
            <select class="kc-form-control" id="kc-insp-space">
              <option value="docs">General Docs (/docs)</option>
              <option value="library">Library (/library)</option>
              <option value="tech">Tech Documentation (/tech)</option>
            </select>
          </div>
        </div>

        <div class="kc-inspector-section">
          <div class="kc-inspector-section-title">SEO & Metadata</div>
          
          <div class="kc-form-group">
            <label class="kc-form-label">Meta Title</label>
            <input type="text" class="kc-form-control" placeholder="Meta title for search engines...">
          </div>

          <div class="kc-form-group">
            <label class="kc-form-label">Meta Description</label>
            <textarea class="kc-form-control" rows="3" placeholder="Brief summary of document..."></textarea>
          </div>
        </div>
      `;

      this.container.innerHTML = html;
    }

    renderBlockInspector(block) {
      if (this.titleEl) {
        this.titleEl.textContent = `BLOCK: ${this.sanitizeText(block.type).toUpperCase()}`;
      }

      const html = `
        <div class="kc-inspector-section">
          <div class="kc-inspector-section-title">Block Settings</div>
          
          <div class="kc-form-group">
            <label class="kc-form-label">Block ID</label>
            <input type="text" class="kc-form-control" value="${this.sanitizeText(block.id)}" readonly style="opacity:0.7;">
          </div>

          <div class="kc-form-group">
            <label class="kc-form-label">Callout Tone / Variant</label>
            <select class="kc-form-control">
              <option value="info">Info (Blue)</option>
              <option value="warning">Warning (Amber)</option>
              <option value="success">Success (Green)</option>
              <option value="error">Error (Red)</option>
              <option value="note">Note (Purple)</option>
            </select>
          </div>
        </div>
      `;

      this.container.innerHTML = html;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    window.KCInspector = new KCInspectorController();
  });
})();
