/**
 * SOI Knowledge Center — Editor Runtime Bootstrap
 * Location: admin/assets/editor/runtime/bootstrap.js
 *
 * Provides the central event bus and runtime state for the authoring environment.
 * Coordinates block selection, inspector synchronization, and editor lifecycle events.
 */
(function () {
  'use strict';

  class KcEditorRuntimeEmitter {
    constructor() {
      this.events = {};
      this.activeBlock = null;
      this.version = '1.3.0';
    }

    /**
     * Subscribe to a runtime event
     * @param {string} event - Event name (e.g. 'selectionChange', 'documentChange')
     * @param {Function} callback - Event handler
     */
    on(event, callback) {
      if (typeof callback !== 'function') return;
      if (!this.events[event]) {
        this.events[event] = [];
      }
      this.events[event].push(callback);
    }

    /**
     * Unsubscribe from a runtime event
     * @param {string} event - Event name
     * @param {Function} callback - Event handler to remove
     */
    off(event, callback) {
      if (!this.events[event]) return;
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    }

    /**
     * Emit a runtime event to all subscribers and dispatch DOM CustomEvents
     * @param {string} event - Event name
     * @param {*} data - Event payload
     */
    emit(event, data) {
      if (event === 'selectionChange') {
        this.activeBlock = data;
      }

      if (this.events[event]) {
        const listeners = this.events[event].slice();
        listeners.forEach(cb => {
          try {
            cb(data);
          } catch (err) {
            console.error('[KcEditorRuntime] Handler error for event "' + event + '":', err);
          }
        });
      }

      // Dispatch DOM CustomEvent for shell/hybrid interoperability
      try {
        if (typeof document !== 'undefined' && document.dispatchEvent) {
          document.dispatchEvent(new CustomEvent('kc:' + event, { detail: data }));
          if (event === 'selectionChange') {
            document.dispatchEvent(new CustomEvent('kc:block-selected', { detail: { block: data } }));
          }
        }
      } catch (domErr) {
        // Safe ignore in non-browser/headless environments
      }
    }

    /**
     * Helper to set and broadcast active block
     * @param {Object|null} block - Active block descriptor { index, type, id, data, block, holder }
     */
    updateActiveBlock(block) {
      this.emit('selectionChange', block);
    }

    /**
     * Returns currently active block descriptor
     * @returns {Object|null}
     */
    getActiveBlock() {
      return this.activeBlock;
    }
  }

  const runtime = new KcEditorRuntimeEmitter();

  if (typeof window !== 'undefined') {
    window.KcEditorRuntime = runtime;
    window.__KC_EDITOR_RUNTIME_VERSION = runtime.version;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { KcEditorRuntimeEmitter, runtime };
  }
})();
